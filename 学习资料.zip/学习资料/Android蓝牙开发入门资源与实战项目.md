# Android 蓝牙开发入门 — 推荐资源与实战项目

## 一、BLE 数据传输

### 核心概念

- **GATT（Generic Attribute Profile）**：BLE 通信基础协议，基于 Service → Characteristic → Descriptor 层级结构
- **Central / Peripheral**：手机通常作为 Central（主设备），传感器/手环等作为 Peripheral（从设备）
- **MTU 协商**：默认 20 字节有效载荷，大数据传输需先协商 MTU（最大 517 字节）

### 推荐资源

| 类型 | 资源 | 说明 |
|------|------|------|
| 📖 官方文档 | [Android BLE 官方指南](https://developer.android.com/develop/connectivity/bluetooth/ble/ble-overview) | 最权威的起点 |
| 📖 教程 | [Nordic Semiconductor BLE 教程系列](https://devzone.nordicsemi.com/guides) | 业界最佳 BLE 入门教程，从协议栈到实战 |
| 📖 博客 | [Punch Through - The Ultimate Guide to Android BLE](https://punchthrough.com/android-ble-guide/) | 非常实用的系列博客 |
| 📺 视频 | [Philipp Lackner - Bluetooth Low Energy on Android](https://www.youtube.com/watch?v=qyG-SDfYNBE) | YouTube 高质量 Android BLE 实战视频 |

### 实战项目

| 项目 | 说明 |
|------|------|
| [Android-BLE-Library](https://github.com/NordicSemiconductor/Android-BLE-Library) | Nordic 官方 BLE 封装库，生产级代码，操作队列化、自动重连、日志完善 |
| [RxAndroidBle](https://github.com/dariuszseber/RxAndroidBle) | 基于 RxJava 的 BLE 库，链式调用处理扫描/连接/读写 |
| [nRF Connect for Android](https://github.com/NordicSemiconductor/Android-nRF-Connect) | Nordic 调试工具源码，学习如何构建完整 BLE 调试 APP |
| [BLE-starter-android](https://github.com/niclasmora/ble-starter-android) | 极简 BLE Demo，适合入门参考 |

---

## 二、蓝牙配对

### 核心概念

- **配对（Pairing）vs 绑定（Bonding）**：配对是交换密钥的过程，绑定是持久化密钥以便下次自动重连
- **配对方式**：
  - **Just Works** — 无需用户交互（安全性最低）
  - **Numeric Comparison** — 双方显示 6 位数字确认
  - **Passkey Entry** — 用户输入 PIN 码
  - **OOB（Out of Band）** — 通过 NFC 等其他通道交换密钥

### 推荐资源

| 类型 | 资源 | 说明 |
|------|------|------|
| 📖 官方文档 | [Android Companion Device Pairing](https://developer.android.com/develop/connectivity/bluetooth/companion-device-pairing) | Android 8.0+ 伴侣设备配对 API |
| 📖 协议解析 | [Bluetooth Pairing Deep Dive - Bluetooth SIG](https://www.bluetooth.com/blog/bluetooth-pairing-part-1/) | 蓝牙 SIG 官方配对机制解析（共 4 篇） |
| 📖 源码分析 | [AOSP Settings 蓝牙配对源码](https://cs.android.com/android/platform/superproject/+/master:packages/apps/Settings/src/com/android/settings/bluetooth/) | 系统设置中蓝牙配对的完整实现 |

### 实战项目

| 项目 | 说明 |
|------|------|
| [BluetoothChat](https://github.com/android/connectivity-samples/tree/main/BluetoothChat) | Google 官方蓝牙聊天示例，包含完整的配对、连接、通信流程 |
| [connectivity-samples](https://github.com/android/connectivity-samples) | Google 官方连接示例集合，含 CompanionDeviceManager 用法 |

---

## 三、蓝牙打印

### 核心概念

- **ESC/POS 协议**：热敏打印机的标准指令集，几乎所有小票打印机都支持
- **SPP（Serial Port Profile）**：经典蓝牙串口通信，大多数蓝牙打印机使用此协议
- **工作流程**：扫描 → 配对 → SPP 连接 → 发送 ESC/POS 指令 → 打印

### 推荐资源

| 类型 | 资源 | 说明 |
|------|------|------|
| 📖 协议文档 | [ESC/POS 指令参考手册（Epson）](https://reference.epson-biz.com/modules/ref_escpos/index.php) | ESC/POS 协议官方文档 |
| 📖 教程 | [Android 蓝牙打印 - Medium](https://medium.com/@paborji/android-bluetooth-thermal-printer-aab0c3b72988) | 从零实现蓝牙热敏打印 |
| 📺 视频 | [YouTube: Android Bluetooth Printer](https://www.youtube.com/results?search_query=android+bluetooth+printer+esc+pos) | 大量实战教程 |

### 实战项目

| 项目 | 说明 |
|------|------|
| [ESCPOS-ThermalPrinter-Android](https://github.com/DantSu/ESCPOS-ThermalPrinter-Android) | ⭐ 最流行的 Android ESC/POS 打印库，支持文本/图片/二维码/条形码 |
| [android-bluetooth-serial](https://github.com/niclasmora/android-bluetooth-serial) | 蓝牙 SPP 通信封装，可用于打印机通信 |
| [PrinterThermal](https://github.com/niclasmora/PrinterThermal) | 热敏打印机完整 Demo，支持蓝牙和 USB |

---

## 四、通用基础资源

### 官方文档

- [Android Bluetooth Overview](https://developer.android.com/develop/connectivity/bluetooth)
- [Android BLE Guide](https://developer.android.com/develop/connectivity/bluetooth/ble/ble-overview)
- [Bluetooth SIG 官网](https://www.bluetooth.com/)

### 推荐开源工具

| 工具 | 用途 |
|------|------|
| [nRF Connect（APP）](https://play.google.com/store/apps/details?id=no.nordicsemi.android.mcp) | BLE 调试神器，扫描/连接/读写/抓包 |
| [Wireshark + Android HCI Snoop Log](https://developer.android.com/studio/debug/dev-options#enable-bluetooth-hci-snoop-log) | 蓝牙协议抓包分析 |

---

## 五、学习路线

```
1. 跑通官方 BluetoothChat 示例 → 理解经典蓝牙全流程
       ↓
2. 用 nRF Connect APP 调试 BLE → 熟悉 GATT 结构
       ↓
3. 基于 Android-BLE-Library 写 BLE 传感器数据读取 Demo
       ↓
4. 接入真实蓝牙打印机 → 用 ESCPOS-ThermalPrinter-Android 库
       ↓
5. 深入：自定义 BLE 外设（用另一台手机模拟 Peripheral）
```
