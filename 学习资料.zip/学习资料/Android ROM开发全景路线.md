# Android ROM 开发全景路线

> 适用对象:已具备 Android 应用开发经验、希望从入门到精通系统定制/ROM 开发的开发者
> 总周期:约 24 周(每天 2-3 小时),选修内核与进阶专题可延长
> 配套文档:
> - 《AOSP Framework核心机制阶段学习计划.md》—— 阶段二核心内容
> - 《Android Binder源码阅读路线.md》—— 阶段二首个模块(Binder 专项)
> 适用版本:Android 13/14(路径以 AOSP main 分支为准,不同版本略有差异)

---

## 一、先厘清概念:ROM 开发包含什么

"ROM 开发"是个宽泛词,实际上分四个层次,不同岗位侧重不同:

| 层次 | 工作内容 | 典型岗位 |
|------|---------|---------|
| 系统定制 | 改 SystemUI/Settings/Launcher、预装应用、开机动画、主题 | 定制 ROM 工程师(MIUI/ColorOS 类) |
| Framework 开发 | 改 AMS/WMS/PMS、系统服务、新增 API | 厂商 framework 工程师 |
| Native/HAL | JNI、HAL 接口、音视频/相机/传感器抽象层 | 底层开发工程师 |
| 内核/驱动 | kernel 定制、设备树、驱动移植 | 内核工程师 |

**精通的标准**:四层都能看懂,前两层能独立修改并落地,并具备独立定位系统级问题的能力。

---

## 二、全景路线总览

| 阶段 | 周期 | 内容 | 配套文档 |
|------|------|------|---------|
| 一、环境与全貌 | 第 1-4 周 | 编译刷机闭环、源码结构、最小定制 | 本文档第三章 |
| 二、Framework 核心机制 | 第 5-16 周 | Binder、Handler、AMS、WMS、PMS、图形 | 已有两份文档 |
| 三、系统定制实践 | 第 8-16 周(与二并行) | SystemUI/Settings、自定义服务 | 本文档第五章 |
| 四、Native/HAL 层 | 第 17-24 周 | C++ 基础设施、HAL 演进、方向深入 | 本文档第六章 |
| 五、内核(选修) | 第 25 周起 | 编译内核、调度、内存管理 | 本文档第八章 |
| 问题定位训练 | 第 12 周起贯穿 | 崩溃/卡顿/内存/启动/功耗 | 本文档第七章 |
| 进阶专题 | 按需 | 启动链路、安全、OTA、图形、性能 | 本文档第九章 |

---

## 三、阶段一:环境与全貌(第 1-4 周)

> 本阶段是《AOSP Framework核心机制阶段学习计划.md》的前置条件,务必先夯实。

### 3.1 编译环境与刷机闭环

- 完整跑通:`repo init/sync` → `source build/envsetup.sh` → `lunch` → `m` → `emulator` 或刷真机
- 使用 **eng/userdebug** 版本(可 root、可 `adb remount`,方便后续加日志验证)
- 掌握增量编译:`m`(全量)、`mm`、`mmm`、`mma` 的区别

```bash
source build/envsetup.sh
lunch aosp_x86_64-eng      # 模拟器 eng 版本
m -j16                      # 全量编译
# 增量:cd 到模块目录后 mm;或 mmm <模块路径>
```

### 3.2 吃透 AOSP 源码目录结构

| 目录 | 作用 |
|------|------|
| `frameworks/base` | Java Framework 核心(本仓库已有,路径对应 `platform_frameworks_base`) |
| `frameworks/native` | Native 层(SurfaceFlinger、libbinder、libgui) |
| `system/core` | init、libutils、adb、logcat |
| `packages/apps` | 系统应用(SystemUI、Settings、Launcher3) |
| `hardware/interfaces` | HIDL/AIDL HAL 接口定义 |
| `vendor/`、`device/` | 厂商驱动与设备配置 |
| `build/soong` | 编译系统(Android.bp) |
| `kernel/` | 内核源码 |

### 3.3 工具链

| 工具 | 用途 |
|------|------|
| Gerrit / repopick | 提 patch、拉他人提交,掌握 git 多仓库补丁管理 |
| adb / fastboot | 调试、刷机 |
| `dumpsys` / `logcat` / `bugreport` | 系统状态与日志 |
| Systrace / Perfetto | 系统级 trace 分析 |
| cs.android.com / aospxref.com | 在线源码交叉索引 |

### 3.4 第一个实战:最小 ROM 定制

按难度递增做一遍,建立"改代码→编译→刷机→验证"的完整肌肉记忆:

1. 改 `build.prop`(设备名、系统属性)
2. 换开机动画(`bootanimation.zip`)
3. 替换默认壁纸、铃声
4. 预装/删除系统 APK(改 `PRODUCT_PACKAGES`)
5. 改 Launcher3 一个按钮、改 SystemUI 一个图标,编译刷机验证

> 本阶段的价值不是"会改这些",而是建立改代码→编译→刷机→验证的完整闭环,
> 后续所有学习都依赖这个闭环。

**验收标准**:能独立完成"修改任意一个系统 APK → 增量编译 → 刷机 → 看到效果"的全流程,并能在 Gerrit 上提交一个 patch。

---

## 四、阶段二:Framework 核心机制(第 5-16 周)

**本阶段直接执行已有的两份文档,无需另起炉灶**:

1. 《Android Binder源码阅读路线.md》(3 周)—— Binder 是 ROM 开发的"地基",所有系统服务通信都基于它
2. 《AOSP Framework核心机制阶段学习计划.md》(10-12 周)—— Handler、AMS/ATMS、WMS、PMS、图形系统

执行时严格遵循计划中的"五步闭环"方法论:API 使用 → 源码跟读 → 画时序图 → 加日志验证 → 输出总结。

### 4.1 补充:两份文档未展开但 ROM 开发必会的机制

**属性系统(system property)**:
- `SystemProperties` API、property 分区、`persist.` 前缀
- 属性读写权限与 SELinux 的关系
- 用属性做功能开关的工程实践

**init 进程与 init.rc**:
- `init.rc` 服务声明语法(`service`/`oneshot`/`user` 等选项)
- `on boot` / `on property` 触发时机
- boot 动画的启动时机、服务崩溃重启机制
- 核心文件:`system/core/init/init.cpp`、`system/core/init/README.md`

### 4.2 向 ROM 开发转化的配套实践

每学一个模块,配套做一个系统定制,让理论直接落地:

| 学完的模块 | 配套定制实践 |
|-----------|-------------|
| Binder | 用 AIDL 写一个跨进程服务并加日志验证调用链路 |
| AMS | 统计 Activity 冷启动耗时;实现"限制某应用后台启动" |
| WMS | 自定义悬浮窗权限管控 |
| PMS | 实现静默安装 APK 工具 |
| 图形系统 | 用 Systrace 分析一次列表滑动掉帧 |

---

## 五、阶段三:系统定制实践(第 8-16 周,与阶段二并行)

Framework 理论学到一半时开始真正的 ROM 定制,二者互相印证。

### 5.1 SystemUI / Settings / Launcher

- **SystemUI**:状态栏、下拉通知面板、锁屏、导航栏 —— 定制 ROM 的核心战场
  - 核心目录:`frameworks/base/packages/SystemUI/`
- **Settings**:添加自定义设置项、隐藏系统设置
  - 核心目录:`packages/apps/Settings/`
- **Launcher3**:桌面布局、负一屏
  - 核心目录:`packages/apps/Launcher3/`

### 5.2 自定义系统服务

- 用 AIDL 写一个自己的 `system_server` 服务(Binder 学到此时正好能落地)
- 给它编写 SELinux 策略(`sepolicy` 编写是 ROM 工程师的基本功)
- 在 `SystemServer` 中注册,实现开机自启动
- 核心文件:`frameworks/base/services/java/com/android/server/SystemServer.java`

### 5.3 属性系统与 init.rc 定制

- 添加自定义系统属性、用属性控制功能开关
- 在 init.rc 中注册原生服务(`oneshot` / 持续运行)

**验收标准**:独立完成一个完整定制功能 —— 例如"在 SystemUI 下拉面板添加一个快捷开关,通过系统属性控制,配置 SELinux 规则,应用层通过 Settings 项修改开关状态"。

---

## 六、阶段四:Native/HAL 层(第 17-24 周)

学完 Framework 后向下突破,这是"普通定制工程师"与"系统底层工程师"的分水岭。

### 6.1 C++ 与 Android 基础设施

- `sp`/`wp` 智能指针、`RefBase` 引用计数(读 Binder 时已接触,系统化补一遍)
  - 核心文件:`system/core/libutils/include/utils/RefBase.h`、`StrongPointer.h`
- `libutils` 常用工具类、Native 版 `Thread`/`Looper`
- JNI 熟练编写(以《Android Binder源码阅读路线.md》L2 层为引子,系统掌握)

### 6.2 HAL 演进主线(必懂)

```
HAL 1.0(so 库) → HIDL(.hal, binderized) → AIDL HAL(Android 11+ 主流) → Stable AIDL
```

- 理解 **Treble** 架构:framework 与 vendor 解耦,`/system` 与 `/vendor` 分区的意义
- 理解 **VNDK**(vendor 可用库集合)与 **GSI**(通用系统镜像)
- 动手:写一个 HIDL 或 AIDL HAL 服务,从应用层一路调到 vendor 实现

### 6.3 选一个方向深入

| 方向 | 切入点 | 备注 |
|------|--------|------|
| 音视频 | AudioFlinger、AudioPolicy、MediaCodec、ffmpeg | 可与本地 fdk-aac/x264/ijkplayer 结合 |
| 图形 | SurfaceFlinger、BufferQueue、HWComposer、HWUI | - |
| 相机 | Camera HAL、Camera2 框架 | - |
| 传感器 | Sensors HAL、SensorService | - |

**音视频路线建议**:读 AudioFlinger 音频流链路 → 研究 MediaCodec 如何调用厂商 codec → 用 x264/fdk-aac 做软编解码实验。

**验收标准**:写一个 HAL 服务并成功在 eng 镜像中运行,能从 `adb shell service list` 看到它,应用层能调通。

---

## 七、贯穿全程:问题定位能力(第 12 周起刻意训练)

**这是精通与否的真正分水岭** —— 能看懂源码的人很多,能定位线上问题的人很少。

| 问题类型 | 分析方法 | 核心工具/文件 |
|---------|---------|--------------|
| 崩溃类 | Java 栈分析、native tombstone 解读(backtrace、寄存器)、debuggerd 原理 | `/data/tombstones/` |
| 卡顿类 | ANR 日志、Watchdog 原理、掉帧分析 | `/data/anr/`、Systrace/Perfetto |
| 内存类 | OOM/低内存杀进程、`lmkd` 与 `oom_adj`(计划模块三已覆盖)、泄漏定位 | hprof、`showmap` |
| 启动类 | `boot_progress` 打点、启动耗时拆解 | logcat 过滤 boot |
| 功耗类 | Doze/AppStandby、wakelock 分析 | `batterystats` |

**训练方法**:从第 12 周开始,每周抽半天**只做问题定位练习** —— 自己制造一个 bug(比如改坏一处 WMS 代码),然后走完整排查流程:复现 → 日志分析 → 定位根因 → 修复验证。

---

## 八、阶段五:内核(选修,第 25 周起)

《Android Binder源码阅读路线.md》L4 层已经进过内核,若要再深入:

- 自己编译一次内核、写/改一个 `.dts` 设备树节点
- 重点读:进程调度(EAS)、内存管理(zram、kswapd、cgroup)、低内存杀进程
- 对 ROM 工程师来说,内核**了解为主、能编译能移植即可**,不必精通驱动开发

---

## 九、精通阶段的进阶专题(按需选修)

| 专题 | 核心内容 | 何时学 |
|------|---------|--------|
| 启动全链路 | bootloader → kernel → init → zygote → system_server → 桌面 | 入门后期即可 |
| 安全体系 | AVB/dm-verity、SELinux 策略编写、Keystore、APK 签名 | 做正式 ROM 前必学 |
| OTA 升级 | A/B 分区、VABC、payload 生成与差分 | 需要升级机制时 |
| 图形进阶 | SurfaceFlinger 合成流程、HWUI 渲染管线、HWComposer | 想做显示优化时 |
| 性能优化 | 开机速度、应用启动、内存、流畅度专项 | 有优化需求时 |

---

## 十、推荐资源

**书籍**(按阅读顺序):
1. 罗升阳《Android 系统源代码情景分析》—— 老但深入,Binder 和图形讲得最好
2. 邓凡平《深入理解 Android》系列(卷 I/II)—— 覆盖广
3. 刘望舒《Android 进阶解密》—— 入门到 Framework 的桥梁
4. 林学森《深入理解 Android 内核设计思想》—— 内核向

**在线**:
- https://source.android.com —— 官方文档,Treble/HAL/AVB 等概念的第一来源
- Gityuan 博客(gityuan.com)—— Framework 源码解读质量最高
- XDA Developers —— 定制 ROM 社区,学 SystemUI 改法

---

## 十一、常见误区(提前避坑)

| 误区 | 对策 |
|------|------|
| 只看不写 | 读一百遍 AMS 不如改一次代码刷机验证,坚持"五步闭环" |
| 版本漂移 | 固定一个版本(建议 Android 13/14),笔记标注版本号 |
| 贪多求全 | 驱动层、内核细节第一遍果断跳过,主线优先 |
| 忽视调试能力 | 从第 12 周起每周半天问题定位练习 |
| 不碰 SELinux | 早期图省事全放 permissive,正式 ROM 必踩坑,早学早受益 |

---

## 十二、总路线图与文档衔接

```
第 1~4 周   阶段一:环境搭建 + 源码结构 + 最小定制          ← 本文档第三章
第 5~7 周   阶段二:Binder 路线(3 周)                      ← 《Android Binder源码阅读路线.md》
第 8~16 周  阶段二:Framework 核心机制(10-12 周)           ← 《AOSP Framework核心机制阶段学习计划.md》
            ＋ 每模块配套一个 ROM 定制实践                  ← 本文档 4.2 节
第 8~16 周  阶段三:系统定制实践(与阶段二并行)              ← 本文档第五章
第 12 周起   问题定位能力持续训练                          ← 本文档第七章
第 17~24 周 阶段四:Native/HAL + 方向深入                  ← 本文档第六章
第 25 周起   阶段五:内核 + 进阶专题(按需)                  ← 本文档第八、九章
```

三份文档的关系:

- **本路线** = 全景地图,定义学什么、何时学、各阶段如何衔接
- **Framework 学习计划** = 阶段二的详细执行手册(模块拆分、周计划、验收标准)
- **Binder 路线** = 阶段二首个模块的专项精读手册

---

## 十三、总验收清单

完成全部路线后,用以下清单自测:

- [ ] 能独立完成"改代码 → 编译 → 刷机 → 验证"全流程,并在 Gerrit 提交 patch
- [ ] 脱稿画出 Binder 一次跨进程调用的全链路图(验收标准见 Binder 路线附录 20 问)
- [ ] 脱稿画出 Activity 冷启动时序图(≥20 个节点,标注 Binder 调用点)
- [ ] 独立完成一个完整定制功能(UI 入口 + 属性开关 + SELinux 策略)
- [ ] 写一个 HAL 服务并在 eng 镜像中运行,应用层能调通
- [ ] 熟练解读 tombstone、ANR、Watchdog 三类日志并定位根因
- [ ] 能基于 Systrace/Perfetto 分析一次掉帧/卡顿发生在哪个阶段
- [ ] 输出 ≥10 篇总结文档(模块总结 + 问题定位复盘)
- [ ] 能向他人讲清楚 Treble 架构与 HAL 演进主线
