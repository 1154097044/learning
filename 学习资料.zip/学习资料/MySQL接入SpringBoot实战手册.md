# MySQL 接入 Spring Boot 实战手册

> **适用对象**：有 Android（Java）开发经验、正在执行《SpringBoot学习实战教程》第 3 周「数据访问」的读者。
> **配套关系**：主教程 4.3 节给知识点与验收，本手册给**可照做的操作配方**（环境检查 → 依赖配置 → JPA / MyBatis-Plus 双版本迁移 → 事务 → Flyway → 坑表 → 资料清单）。
> **技术基线**（已联网核实，2026-11）：Spring Boot 3.5.6 + JDK 21 + Maven；MySQL 8.4（Docker 容器，本机已就绪）；MyBatis-Plus 3.5.x（Spring Boot 3 专用 starter）；Flyway 由 Boot BOM 管理版本（需额外引入 `flyway-mysql` 模块）。
> **配套代码**：`springboot-learning-demo/week3-data` 模块（按本手册新建）；第 2 周 Todo 内存版代码在 `week2-web/src/main/java/com/example/learn/week2/todo/`。

---

## 0. 前置：确认 MySQL 容器就绪

本机 Docker Desktop 已起 MySQL 8.4 容器（`--name mysql`，root 密码 `root`，端口 3306，数据卷 `mysql-data`）。开工前逐条确认：

```bash
docker ps | grep mysql            # 1. 容器在跑，STATUS 是 Up
docker exec -it mysql mysql -uroot -proot   # 2. 能进 MySQL 客户端（exit 退出）
```

在 MySQL 客户端里建好第 3 周用的库：

```sql
CREATE DATABASE IF NOT EXISTS learn CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
SHOW DATABASES;
```

**图形客户端（强烈建议装一个，肉眼确认建表结果）**：DBeaver Community（免费，支持 MySQL/JDBC）或 DataGrip（IDEA 用户直接用 IDEA 自带的 Database 工具窗口即可，零安装）。连接参数：`localhost:3306`，用户 `root`，密码 `root`，库 `learn`。

---

## 1. Android → 数据访问概念映射（先建立模型）

动手前先对一遍概念，这是你迁移最快的路径：

| Android（Room/SQLite） | Spring Boot 服务端 | 关键差异 |
|---|---|---|
| `@Entity` + `@ColumnInfo` | JPA `@Entity` + `@Column` | 注解几乎同名，但服务端实体是**可变 POJO**（Hibernate 需要无参构造器） |
| `@Dao` 接口 | `JpaRepository<T, ID>` 接口 | Spring 同样"只写接口不写实现"，运行时动态生成 |
| `RoomDatabase`（数据库句柄） | `EntityManager` / `SessionFactory` | 你基本不直接操作它，Repository 替你管 |
| `@Query("SELECT ...")` SQL 字符串 | `@Query` JPQL（面向对象）/ 原生 SQL | JPQL 操作的是**实体和字段**，不是表和列 |
| `PagingSource` / `PagingData` | `Pageable` / `Page<T>` | 服务端分页必须同时返回 total 与 content |
| `Flow<List<T>>` 观察查询 | `@Query` 返回 `Stream` / 流式游标 | 服务端不需要"数据变化推送"，每次请求查一次 |
| `db.withTransaction { }` | `@Transactional` 注解 | 服务端事务是**声明式 AOP**，比 Room 的事务语义复杂得多（见第 5 节） |
| SQLiteOpenHelper + 手写 SQL | MyBatis / MyBatis-Plus | 你熟悉的"手写 SQL"在这条路线里继续适用 |
| 客户端几乎无多线程共享写 | 每个请求一个线程，单例 Bean 被并发访问 | 连接池、事务隔离级别都是新课题（见第 2.3、5 节） |

> **核心认知**：服务端没有"本地缓存优先、网络同步"这一层——**数据库就是唯一事实源（Single Source of Truth）**。你在 Room 里习以为常的"先查本地缓存再决定是否发请求"，在服务端对应的思想是"先查缓存（Redis，第 4 周）再查库"，但数据本身永远以 MySQL 为准。

---

## 2. 依赖与数据源配置

### 2.1 新建 week3-data 模块

> ✅ 本手册配套的 **week3-data 模块已创建并编译+实跑验证**，作为新手入门 Demo（最小可运行版：User 实体 + JpaRepository + CRUD 接口 + Flyway 建表），文件清单与运行步骤见**附录 B**。建议先跑通附录 B 的入门 Demo，再按本节往下做主线练习（Todo 双版本迁移建议基于入门 Demo 新建 Git 分支展开）。

模块结构（已就位）：

```xml
<modules>
    <module>week1-ioc</module>
    <module>week2-web</module>
    <module>week3-data</module>
</modules>
```

### 2.2 pom 依赖

```xml
<dependencies>
    <!-- Web 层复用第 2 周的写法：Result/校验/全局异常 -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-validation</artifactId>
    </dependency>

    <!-- 路线 A：Spring Data JPA（Hibernate 由 Boot BOM 管理版本） -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>

    <!-- MySQL 驱动：Boot 3.x 坐标是 com.mysql:mysql-connector-j（注意！不是 2.x 时代的 mysql:mysql-connector-java） -->
    <dependency>
        <groupId>com.mysql</groupId>
        <artifactId>mysql-connector-j</artifactId>
        <scope>runtime</scope>
    </dependency>

    <!-- 路线 B：MyBatis-Plus（Spring Boot 3 必须用 boot3 专用 starter，3.5.16 为 2026-01 发布，以 baomidou.com 最新为准） -->
    <dependency>
        <groupId>com.baomidou</groupId>
        <artifactId>mybatis-plus-spring-boot3-starter</artifactId>
        <version>3.5.16</version>
    </dependency>

    <!-- Flyway：MySQL 支持是独立模块，必须两个都加 -->
    <dependency>
        <groupId>org.flywaydb</groupId>
        <artifactId>flyway-core</artifactId>
    </dependency>
    <dependency>
        <groupId>org.flywaydb</groupId>
        <artifactId>flyway-mysql</artifactId>
    </dependency>

    <!-- 测试：沿用第 2 周 MockMvc -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>
```

**注意**：教程要求「JPA 版」和「MyBatis-Plus 版」各实现一遍，建议**两个 Git 分支分别做**（如 `feature/.../week3-jpa` 与 `feature/.../week3-mybatisplus`），不要把两个 ORM 同时塞进一个模块——JPA 的 `EntityManagerFactory` 与 MyBatis 的 `SqlSessionFactory` 自动配置并存时需要额外的 `@Primary` 处理，初学没必要给自己加难度。

### 2.3 application.yml 数据源与 HikariCP

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/learn?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai
    username: root
    password: root
    driver-class-name: com.mysql.cj.jdbc.Driver
    hikari:
      maximum-pool-size: 10        # 最大连接数：单机小项目 5~20 足够，太大 MySQL 扛不住
      minimum-idle: 5              # 空闲保底连接，避免突发流量冷启动
      connection-timeout: 30000    # 拿不到连接的等待上限(ms)，超时报 PoolTimeoutException
      max-lifetime: 1800000        # 连接最大存活 30min，须小于 MySQL wait_timeout(默认8h)
      idle-timeout: 600000         # 空闲 10min 回收（不小于 minimum-idle）
      pool-name: LearnHikariPool   # 给池命名，日志里好认
  jpa:
    hibernate:
      ddl-auto: validate            # 见 2.4：表结构交给 Flyway，JPA 只校验
    open-in-view: false             # 关闭 OSIV，逼自己在事务边界内加载数据（见坑 8.6）
    properties:
      hibernate:
        format_sql: true            # 开发期打开 SQL 日志
  flyway:
    enabled: true
    locations: classpath:db/migration
```

HikariCP 关键参数速查（对标 OkHttp 连接池，思想一模一样）：

| 参数 | 默认 | 说明 | OkHttp 类比 |
|---|---|---|---|
| `maximum-pool-size` | 10 | 池上限 | `ConnectionPool` 的最大空闲连接数 |
| `connection-timeout` | 30s | 拿连接超时 | 连接超时（拿不到连接，不是建连接慢） |
| `max-lifetime` | 30min | 连接最长存活 | 连接复用上限，防止被 MySQL 单方面断开后池里全是死连接 |
| `idle-timeout` | 10min | 空闲回收 | 空闲连接回收策略 |

### 2.4 ddl-auto 与 Flyway 的配合原则

- `ddl-auto` 可选值：`none`（不动表）、`validate`（只校验实体与表结构是否一致，**推荐**）、`update`（自动改表）、`create-drop`/`create`（重建，**生产禁用**）。
- 第 3 周起养成习惯：**表结构变更一律写 Flyway 迁移脚本，`ddl-auto` 设为 `validate`**。这样"数据库长什么样"是版本化的、可审计的，而不是 Hibernate 悄悄改出来的。

---

## 3. 路线 A：Spring Data JPA 版（Demo 3-1 分支一）

### 3.1 实体映射

把第 2 周的 `Todo` 从纯 POJO 改成 JPA 实体（对标 Room 加 `@Entity` 的过程）：

```java
@Entity
@Table(name = "todo")                       // 表名；Room 里是 @Entity(tableName=...)
public class Todo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // MySQL 自增，Room 的 autoGenerate=true
    private Long id;

    @Column(nullable = false, length = 100)
    private String title;

    @Column(length = 500)
    private String description;

    @Column(nullable = false)
    private boolean done;

    @Column(nullable = false, updatable = false)   // 创建后不可改
    private LocalDateTime createdAt;

    protected Todo() {}                     // JPA 必须有无参构造器（Hibernate 反射用）
    // getter/setter 略，沿用第 2 周代码
}
```

要点：

1. **必须有无参构造器**（`protected` 即可，Room 没这个硬要求，这是 Hibernate 的）。
2. `@GeneratedValue(strategy = IDENTITY)` 对应 MySQL `AUTO_INCREMENT`；自增主键是**插入后才回填**到实体里的。
3. `LocalDateTime` 直接映射 MySQL `datetime` 列，无需转换器（比 Room 的 TypeConverter 省事）。

### 3.2 Repository：接口即实现

删掉第 2 周手写的内存 `TodoRepository` 实现类，换成接口：

```java
public interface TodoRepository extends JpaRepository<Todo, Long> {

    // 方法名派生查询：Spring 解析方法名生成 SQL，Room 的 @Query 注释都省了
    List<Todo> findByDone(boolean done);
    List<Todo> findByTitleContaining(String keyword);          // LIKE %keyword%
    List<Todo> findByCreatedAtBetween(LocalDateTime from, LocalDateTime to);
    long countByDone(boolean done);
    boolean existsByTitle(String title);

    // @Query：方法名表达不了时手写 JPQL（面向实体，不是表）
    @Query("SELECT t FROM Todo t WHERE t.done = :done ORDER BY t.createdAt DESC")
    List<Todo> findDoneTodos(@Param("done") boolean done);

    // 原生 SQL：实在要写 SQL 时加 nativeQuery
    @Query(value = "SELECT * FROM todo WHERE title LIKE CONCAT('%', :kw, '%')",
           nativeQuery = true)
    List<Todo> searchByTitleNative(@Param("kw") String keyword);

    // 分页：返回值换 Page<T>，参数加 Pageable，Spring 自动做 count 查询
    Page<Todo> findByDone(boolean done, Pageable pageable);
}
```

方法名派生规则速查：

| 方法名片段 | 生成的 SQL 语义 |
|---|---|
| `findByTitle` | `WHERE title = ?` |
| `findByTitleContaining` | `WHERE title LIKE %?%` |
| `findByDoneTrue` / `findByDoneFalse` | `WHERE done = TRUE / FALSE` |
| `findByCreatedAtAfter` | `WHERE created_at > ?` |
| `findTop5ByOrderByCreatedAtDesc` | 前 5 条按创建时间倒序 |
| `findFirstByTitleOrderByIdAsc` | 第一条 |

分页用法（Service 层）：

```java
Page<Todo> page = todoRepository.findByDone(false,
        PageRequest.of(pageNum, pageSize, Sort.by(Sort.Direction.DESC, "createdAt")));
PageResult<Todo> result = new PageResult<>(
        page.getTotalElements(),           // 总数（第二句 count SQL 自动发出）
        page.getContent());                // 当前页数据
```

### 3.3 一对多：用户与 Todo（懒加载陷阱 + N+1）

```java
@Entity
@Table(name = "app_user")                  // user 是 MySQL 保留字，别用表名 user
public class User {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)   // 默认就是 LAZY
    private List<Todo> todos = new ArrayList<>();
}

@Entity
@Table(name = "todo")
public class Todo {
    // ...
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")          // todo 表外键列
    private User user;
}
```

两个必踩的坑，先打预防针：

1. **懒加载 + JSON 序列化 = `LazyInitializationException`**：Controller 返回 `User` 时，Jackson 序列化 `todos` 字段时事务已结束、Session 已关闭，懒加载拿不到数据直接炸。**正确做法是永远不让 Controller 直接返回实体**——写 DTO 投影（第 2 周你已经在用 DTO 做入参，出参同理），或查什么就把什么放进事务里。这也是 2.3 配置 `open-in-view: false` 的意义：逼你养成"事务边界内加载完整数据"的习惯。
2. **N+1 查询**：循环里每个用户各查一次 todos。解法：`@EntityGraph(attributePaths = "todos")` 或 `JOIN FETCH`：

```java
@EntityGraph(attributePaths = "todos")
@Query("SELECT u FROM User u WHERE u.id IN :ids")
List<User> findUsersWithTodos(@Param("ids") List<Long> ids);
```

### 3.4 Service 迁移对照

第 2 周内存版 → JPA 版，`TodoService` 的差异点：

| 操作 | 第 2 周（内存 Repository） | 第 3 周（JPA） |
|---|---|---|
| 新增 | 手动 `idSeq.incrementAndGet()`、手动塞 `createdAt` | `repository.save(todo)` 一条搞定，id 回填 |
| 更新 | `store.put(id, todo)` 整体覆盖 | 先 `findById` 取出**受管实体**，改字段即可——**事务提交时 Hibernate 自动发 UPDATE**（脏检查，这就是 ORM 与手写存储的本质区别） |
| 查询 | 手写排序分页 | 方法名派生 / `@Query` / `Pageable` |
| 删除 | `store.remove(id)` | `repository.deleteById(id)` |
| 事务 | 无（并发靠 ConcurrentHashMap） | 写操作加 `@Transactional`（见第 5 节） |

---

## 4. 路线 B：MyBatis-Plus 版（Demo 3-1 分支二）

### 4.1 启动类加 Mapper 扫描

```java
@SpringBootApplication
@MapperScan("com.example.learn.week3.mapper")
public class Week3DataApplication {
    public static void main(String[] args) {
        SpringApplication.run(Week3DataApplication.class, args);
    }
}
```

### 4.2 实体注解

```java
@TableName("todo")                        // 默认实体名→表名，不一致时显式声明
public class Todo {
    @TableId(type = IdType.AUTO)          // 数据库自增
    private Long id;

    private String title;                 // 驼峰 title → 列 title（下划线列名自动映射 user_id ↔ userId）
    private String description;
    private Boolean done;
    private LocalDateTime createdAt;      // LocalDateTime 直接映射，无需转换器
}
```

### 4.3 Mapper 接口：BaseMapper 通用 CRUD

```java
public interface TodoMapper extends BaseMapper<Todo> {
    // 复杂查询写在这里 + XML，或直接在 Service 用 Wrapper
    List<Todo> selectByKeyword(@Param("kw") String keyword);   // 对应 resources/mapper/TodoMapper.xml
}
```

`BaseMapper<Todo>` 自带：`insert` / `deleteById` / `updateById` / `selectById` / `selectList` / `selectPage`……零 SQL 完成单表 CRUD（对标 Room 的 `@Insert/@Update/@Delete` 自动生成）。

### 4.4 LambdaQueryWrapper 条件构造

```java
// 传统写法（字符串列名，重构易漏）：new QueryWrapper<Todo>().eq("done", false)
List<Todo> list = todoMapper.selectList(new LambdaQueryWrapper<Todo>()
        .eq(Todo::getDone, false)                     // 方法引用，列名重构安全
        .like(StringUtils.hasText(kw), Todo::getTitle, kw)  // 条件为 true 才拼 SQL
        .orderByDesc(Todo::getCreatedAt));
```

### 4.5 分页插件（必须手动配，否则分页不生效）

```java
@Configuration
public class MybatisPlusConfig {
    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.MYSQL));
        return interceptor;
    }
}
```

```java
Page<Todo> page = todoMapper.selectPage(
        new Page<>(pageNum, pageSize),              // 第几页、每页多少
        new LambdaQueryWrapper<Todo>().orderByDesc(Todo::getCreatedAt));
page.getTotal();     // 总数（插件自动发 count）
page.getRecords();   // 当前页数据
```

### 4.6 XML 映射文件（复杂 SQL 才需要）

`src/main/resources/mapper/TodoMapper.xml`：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.example.learn.week3.mapper.TodoMapper">
    <select id="selectByKeyword" resultType="com.example.learn.week3.entity.Todo">
        SELECT * FROM todo
        WHERE title LIKE CONCAT('%', #{kw}, '%')
        ORDER BY created_at DESC
    </select>
</mapper>
```

`application.yml` 配 XML 位置：

```yaml
mybatis-plus:
  mapper-locations: classpath:mapper/*.xml
  configuration:
    log-impl: org.apache.ibatis.logging.stdout.StdOutImpl   # 开发期打印 SQL
```

---

## 5. 事务实战（Demo 3-2）

### 5.1 @Transactional 默认规则（面试高频）

```java
@Service
public class AccountService {

    @Transactional
    public void transfer(Long fromId, Long toId, BigDecimal amount) {
        accountRepository.decrease(fromId, amount);   // UPDATE 1
        accountRepository.increase(toId, amount);     // UPDATE 2
    }                                                  // 方法正常返回 → 提交
}                                                      // 抛 RuntimeException → 回滚
```

必须背下来的默认行为：

1. **回滚条件**：默认只回滚 **RuntimeException 与 Error**；抛受检异常（Checked Exception）**不回滚**——需要时加 `rollbackFor = Exception.class`。
2. **传播行为默认 REQUIRED**：外层有事务就加入，没有就新建。`REQUIRES_NEW`（挂起外层、独立新事务）在"记账失败也要记录日志"场景用。
3. **只读优化**：纯查询方法加 `@Transactional(readOnly = true)`，Hibernate 跳过脏检查、数据库层也能优化。
4. **Spring 事务 = AOP 代理**，`@Transactional` 只有**从外部经代理调用**时才生效（见 5.2）。

### 5.2 自调用失效：先复现，再修（主教程点名要演示）

```java
@Service
public class AccountService {

    public void doTransfer() {
        this.reallyTransfer();   // 自调用！事务注解被绕过
    }

    @Transactional
    public void reallyTransfer() {
        // 这里的事务不生效——因为调用绕过了 Spring 生成的代理对象
    }
}
```

**原因**：`@Transactional` 是代理在入口处"开启事务→调用你→提交/回滚"。`this.xxx()` 直接调用目标对象自己的方法，压根没经过代理，事务逻辑无从执行。**这也解释了为什么 private 方法上加 @Transactional 永远无效**（代理根本拦不到 private 方法）。

三种解法（任选其一）：

1. **注入自己**（学习用最快）：`@Autowired private AccountService self;` 然后 `self.reallyTransfer()`。
2. **拆到另一个 Service**（工程上最干净）：把事务方法挪到独立的 `TransferService`，`AccountService` 注入它调用。
3. `AopContext.currentProxy()`（需要 `@EnableAspectJAutoProxy(exposeProxy = true)`，少用，可读性差）。

验证方式：转账故意在第二条 UPDATE 后抛 `RuntimeException`，观察第一条是否回滚；再把调用改成自调用，观察**没有**回滚（钱少了）——亲眼看一次 bug，比读十遍文档记得牢。

---

## 6. Flyway 版本化建表（Demo 3-3）

### 6.1 脚本位置与命名

`src/main/resources/db/migration/V1__init.sql`：

```sql
CREATE TABLE app_user (
    id   BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE todo (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id     BIGINT,
    title       VARCHAR(100) NOT NULL,
    description VARCHAR(500),
    done        TINYINT(1) NOT NULL DEFAULT 0,
    created_at  DATETIME NOT NULL,
    CONSTRAINT fk_todo_user FOREIGN KEY (user_id) REFERENCES app_user (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

命名规则：`V<版本号>__<描述>.sql`（两个下划线）。版本号递增：`V1__init.sql`、`V2__add_xxx.sql`……**已执行的脚本一个字都不能改**，改动要新建 `V2/V3`。

### 6.2 验证：全新容器一键重建

```bash
docker exec -it mysql mysql -uroot -proot -e "DROP DATABASE learn; CREATE DATABASE learn CHARACTER SET utf8mb4;"
# 重启应用，Flyway 自动按序执行迁移脚本，日志出现 Migrating schema ... Successfully applied
```

### 6.3 两个高频问题

| 现象 | 原因与解法 |
|---|---|
| `Migration checksum mismatch` | 改动了已执行的脚本。**不要回改旧脚本**，新建下一个版本；若学习期想重置，删库重来即可 |
| 已有表但无 flyway 历史 | 学习期直接删库重来；生产环境才用 `baseline-on-migrate: true` 打基线 |

---

## 7. 验收清单（对照第 2 周测试脚本）

- [ ] JPA 分支与 MyBatis-Plus 分支的 Todo API 全部通过 `week2-web/src/main/resources/todo-api-test.http`（改端口/路径适配后逐条跑）。
- [ ] 重启应用后数据仍在（真的落库了，而不是内存假象）；`docker rm` 容器后重启，数据卷恢复数据（验证持久化）。
- [ ] 转账 Demo：异常回滚正常；自调用版本**成功复现**"没回滚"。
- [ ] 能一句话说清：`@Transactional` 为什么对 private 方法无效、为什么自调用无效。
- [ ] 删除 `learn` 库后重启应用，Flyway 一键重建全部表结构。
- [ ] 能解释 `open-in-view: false` 配与不配的区别（返回实体 vs 返回 DTO）。

---

## 8. 常见坑排查表

| # | 现象 | 原因 | 解法 |
|---|---|---|---|
| 8.1 | 启动报 `Communications link failure` / `Connection refused` | MySQL 容器没起，或端口不对 | `docker ps` 确认容器 Up；`lsof -i :3306` 查端口占用 |
| 8.2 | `Public Key Retrieval is not allowed` | MySQL 8 默认 `caching_sha2_password`，驱动需允许取公钥 | URL 加 `allowPublicKeyRetrieval=true&useSSL=false`（本机学习用；生产建议正经配 SSL） |
| 8.3 | 中文乱码 / `Incorrect string value` | 库/表不是 utf8mb4 | 建库带 `CHARACTER SET utf8mb4`；URL 带 `characterEncoding=utf8`；容器已加 `--character-set-server=utf8mb4` |
| 8.4 | `The server time zone value 'CST' is unrecognized` | URL 未指定时区 | URL 加 `serverTimezone=Asia/Shanghai` |
| 8.5 | `Cannot resolve reference to bean 'jpaMappingContext'` / 找不到 `mysql-connector-java` | Boot 3.x 坐标变了 | 用 `com.mysql:mysql-connector-j`，不是 2.x 的 `mysql:mysql-connector-java` |
| 8.6 | Controller 返回实体报 `LazyInitializationException` | 懒加载关联在事务外被序列化 | 返回 DTO 投影；或 `@EntityGraph`/JOIN FETCH 在事务内加载完整 |
| 8.7 | 一对多查询日志刷屏 N 条 SELECT | N+1 查询 | `@EntityGraph(attributePaths=...)` 或 JOIN FETCH |
| 8.8 | `updateById` 后数据库没变 | 实体字段为 null 时 MyBatis-Plus 默认跳过更新 | 允许置 null 用 `@TableField(updateStrategy = FieldStrategy.IGNORED)`，或先查再改 |
| 8.9 | MyBatis-Plus 分页返回全部数据 | 没配分页插件 | 注册 `PaginationInnerInterceptor`（见 4.5） |
| 8.10 | 事务"没生效"，数据部分提交 | 自调用绕过代理 / 抛了受检异常 | 见 5.2；受检异常加 `rollbackFor = Exception.class` |
| 8.11 | `HikariPool-1 - Connection is not available` | 连接池耗尽（连接泄漏：开了连接没还） | 查 `maximum-pool-size`；排查长事务/未关闭的 `EntityManager` |
| 8.12 | Flyway 报 `Unsupported Database: MySQL 8.4` | 只加了 `flyway-core`，缺 MySQL 模块 | 补 `flyway-mysql` 依赖（Boot 3 起必须） |
| 8.13 | JPA 建表语句与 Flyway 脚本互相覆盖/冲突 | `ddl-auto: update` 与 Flyway 同时管表结构 | `ddl-auto: validate`，表结构只交给 Flyway |

---

## 9. 学习资料清单（按阅读顺序）

| 顺序 | 资源 | 类型 | 说明 |
|---|---|---|---|
| 1 | [Spring 官方 Guide: Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/) | 官方 Guide | ⭐ 30 分钟跟做，先建立"实体+Repository 自动 CRUD"的第一印象 |
| 2 | [Spring Data JPA Reference](https://docs.spring.io/spring-data/jpa/reference/jpa.html) | 官方文档 | ⭐ 重点读 Repository 方法名派生、`@Query`、分页三章；有 Room 底子读得很快 |
| 3 | [Baeldung: Transactions with Spring](https://www.baeldung.com/transaction-configuration-with-jpa-and-spring) | 图文教程 | 事务配置与 `@Transactional` 基础 |
| 4 | [Baeldung: @Transactional Self-Invocation](https://www.baeldung.com/spring-self-invocation) | 图文教程 | ⭐ 自调用失效官方级讲解，面试与生产双重高频，必读 |
| 5 | [Baeldung: N+1 Problem 与 EntityGraph 系列](https://www.baeldung.com/spring-data-jpa-named-entity-graphs) | 图文教程 | 懒加载与 N+1 实战解法 |
| 6 | [MyBatis-Plus 官方文档（中文）](https://baomidou.com) | 官方文档 | ⭐ 读「快速开始 + CRUD 接口 + 条件构造器 + 分页插件」四章即可 |
| 7 | [MyBatis 官方中文文档](https://mybatis.org/mybatis-3/zh_CN/) | 官方文档 | XML 映射语法速查（`#{}` 与 `${}` 区别、resultType/resultMap） |
| 8 | [Flyway 官方文档 Getting Started](https://documentation.red-gate.com/flyway) | 官方文档 | 10 分钟；重点看命名约定与 checksum 机制 |
| 9 | [spring-projects/spring-petclinic](https://github.com/spring-projects/spring-petclinic) | 开源项目 | 看官方怎么写实体分层、Repository 与 DTO；**只读 spring-petclinic-data-jpa 相关类，不要全量读** |
| 10 | [macrozheng/mall](https://github.com/macrozheng/mall) | 开源项目 | 国内 MyBatis-Plus 工程化实践，看 `mbg`（代码生成器）与分页封装；**只抄结构，不要全量读** |
| 11 | [MySQL 8.4 Reference Manual](https://dev.mysql.com/doc/refman/8.4/en/) | 官方文档 | 只查：字符集/排序规则、DATETIME 类型、连接管理三节 |

> 链接失效说明：spring.io 系列需带尾斜杠访问；baeldung.com 对脚本反爬、浏览器访问正常；均以浏览器实测为准。

---

## 附录：本手册对应的主教程检查点

- 主教程 4.3 节「第 3 周：数据访问」的知识点、实战任务、验收与本手册一一对应。
- 完成后回到主教程勾选验收清单，进入第 4 周（Spring Security + Redis）前，确保 Demo 3-1 ~ 3-3 全部交付。

---

## 附录 B：新手入门 Demo 源码（week3-data 最小可运行版）

> 状态：已编译 + 实跑验证（2026-11-09，本机 Docker MySQL 8.4 容器）。源码位置：`springboot-learning-demo/week3-data/`（已注册进父 pom）。

### B.1 文件清单（7 个源码 + 2 个资源文件，照着读）

| 文件 | 作用 | 学习重点 |
|---|---|---|
| `pom.xml` | 最小依赖：web + data-jpa + mysql-connector-j + flyway(core+mysql) | 每个依赖为什么加，注释里都写了 |
| `Week3DataApplication.java` | 启动类 | 启动时自动发生三件事：Flyway 建表、插演示数据、打印 SQL |
| `entity/User.java` | 实体映射 | `@Entity/@Id/@GeneratedValue/@Column` 全套注解，注释对标 Room |
| `repository/UserRepository.java` | 数据访问接口 | 继承 `JpaRepository` 白拿 CRUD + 4 个方法名派生查询 |
| `web/UserController.java` | REST 接口 | 查全部/按 id 查/模糊搜索/新增/删除，共 5 个 |
| `DataInitRunner.java` | 启动自动演示 | `CommandLineRunner`：首次启动插 3 条数据 + 打印查询结果 |
| `resources/application.yml` | 数据源与 JPA 配置 | 连接参数、`ddl-auto: validate`、`show-sql: true` |
| `resources/db/migration/V1__init.sql` | Flyway 建表脚本 | 版本化建表，文件名两个下划线 |
| `resources/user-api-test.http` | 7 步 REST 测试脚本 | 用 IDEA / VS Code REST Client 逐条跑 |

### B.2 运行三步

```bash
cd /Users/xy/workfile/springboot-learning-demo
export JAVA_HOME=/Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home
MVN="mvn -Dmaven.repo.local=/Users/xy/workfile/.cache/m2repo"

# 1. 确认 MySQL 容器在跑
docker ps | grep mysql

# 2. 启动（首次启动自动建表 + 插演示数据）
$MVN -pl week3-data spring-boot:run

# 3. 另开一个终端验证
curl http://localhost:8083/api/users
curl "http://localhost:8083/api/users/search?keyword=%E5%BC%A0"   # "张"的 URL 编码
```

### B.3 启动日志你将看到（实测原文）

```text
Migrating schema `learn` to version "1 - init"
Successfully applied 1 migration to schema `learn`, now at version v1
>>> 表是空的，已自动插入 3 条演示数据
>>> app_user 表当前总条数: 3
>>> 模糊查询到用户: id=1, name=张三, email=zhangsan@example.com
```

### B.4 建议玩法（由浅入深）

1. **读 SQL**：`show-sql: true` 会在控制台打印 Hibernate 发出的每句 SQL——对照接口调用顺序，看 `save` 时 INSERT 的参数、`findByNameContaining` 生成的 LIKE 语句。
2. **两侧对照**：`docker exec -it mysql mysql -uroot -proot -e "SELECT * FROM learn.app_user;"`，确认接口返回的数据与 MySQL 里一致。
3. **改着玩**：在 `DataInitRunner` 里加删除、更新、按邮箱查询等代码，重启看日志。
4. **体验 Flyway**：给 User 加 `age` 字段，不要改 V1，新建 `V2__add_age.sql`（`ALTER TABLE app_user ADD COLUMN age INT;`），重启观察只执行 V2。
5. **回到主线**：入门 Demo 玩熟后，按本手册 3.4 节把第 2 周的 Todo 迁到数据库（Demo 3-1 主线）。

### B.5 两个实测小坑（都是假象，不是 bug）

| 现象 | 真相 |
|---|---|
| curl 带中文参数报 400 | curl 不自动做 URL 编码，中文要编码后传（`张` = `%E5%BC%A0`）；浏览器和 IDEA REST Client 会自动处理，无此问题 |
| `docker exec` 里 SELECT 中文显示 `??` | 终端字符集显示问题，存储完全正确（可用 `HEX(name)` 验证）；加 `--default-character-set=utf8mb4` 或用 DBeaver/IDEA 查看 |

---

## 附录 C：MyBatis-Plus 对照版入门 Demo（week3-data-mp）

> 状态：已编译 + 实跑验证（2026-11-09）。源码位置：`springboot-learning-demo/week3-data-mp/`，与 JPA 版（week3-data）**同一套 User CRUD，两个模块并列对照**。

### C.1 与 JPA 版的一一对照（读代码时两边开窗口）

| 对照点 | JPA 版（week3-data） | MP 版（week3-data-mp） |
|---|---|---|
| 类↔表映射 | `@Entity` + `@Table(name="app_user")` | `@TableName("app_user")` |
| 主键自增 | `@Id` + `@GeneratedValue(IDENTITY)` | `@TableId(type = IdType.AUTO)` |
| 数据访问接口 | `JpaRepository<User, Long>`（方法名派生查询） | `BaseMapper<User>`（固定方法 + 条件构造器） |
| 模糊查询 | `findByNameContaining("张")` | `selectList(wrapper.like(User::getName, "张"))` |
| 计数 | `count()` | `selectCount(null)` |
| 分页 | `Pageable` 参数，零配置 | `selectPage` + **手动注册分页插件** |
| 启动类 | 无需额外注解 | 需 `@MapperScan("...mapper")` |
| SQL 日志 | `spring.jpa.show-sql: true` | `mybatis-plus.configuration.log-impl` |
| 版本 | Boot BOM 管理，不写版本号 | `mybatis-plus-spring-boot3-starter` 3.5.16 + `mybatis-plus-jsqlparser` 3.5.16 |

### C.2 依赖与运行

```bash
# 1. 建独立库（MP 版与 JPA 版用不同的库，Flyway 版本历史互不干扰）
docker exec -it mysql mysql -uroot -proot \
  -e "CREATE DATABASE IF NOT EXISTS learn_mp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# 2. 启动（默认端口 8084，可与 JPA 版 8083 同时跑着对照）
cd /Users/xy/workfile/springboot-learning-demo
export JAVA_HOME=/Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home
mvn -Dmaven.repo.local=/Users/xy/workfile/.cache/m2repo -pl week3-data-mp spring-boot:run
```

MP 版多了一个接口：`GET /api/users/page?page=1&size=2`（分页，实测返回 `records/total/size/current/pages` 结构）。测试脚本：`week3-data-mp/src/main/resources/user-api-test.http`（8 步）。

### C.3 MP 版的三个版本坑（2026-11 实测，手册 8.x 坑表对应项）

1. **boot3 starter 坐标**：Spring Boot 3 必须用 `mybatis-plus-spring-boot3-starter`，用错成 `mybatis-plus-boot-starter` 会直接启动失败（对应坑 8.5 思路）。
2. **分页插件依赖拆分**：3.5.9 起 `PaginationInnerInterceptor` 拆到 `mybatis-plus-jsqlparser` 模块，只引 starter 会编译报"找不到符号 PaginationInnerInterceptor"，必须额外引 `mybatis-plus-jsqlparser`（版本与主库一致）——这是本 Demo 首次编译实测撞上的坑。
3. **不配分页插件 selectPage 不生效**：配了插件但没注册拦截器时，分页会返回全量数据（对应坑 8.9，本模块已配好，可故意注释掉 MybatisPlusConfig 里的 Bean 复现）。
