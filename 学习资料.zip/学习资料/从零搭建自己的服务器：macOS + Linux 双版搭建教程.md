# 从零搭建自己的服务器：macOS + Linux 双版搭建教程

> 面向学习用途的家用服务器完整搭建指南：从硬件选型、系统安装（macOS / Linux 各一版）、基础配置，到从易到难的服务部署与架构升级。
>
> 适用读者：有一定命令行基础、想拥有一台"自己的服务器"并持续玩下去的开发者。

---

## 〇、本文导读

### 你将得到什么

按照本文档走完全部流程，你将拥有：

1. 一台（或两台）7×24 小时运行的家用服务器；
2. 一套 macOS 服务器环境 + 一套 Linux 服务器环境；
3. SSH 远程管理、文件共享、Web 服务、Docker 应用、内网穿透、监控告警等完整能力；
4. 一条清晰的"从易到难"架构升级路线，可以持续进阶到虚拟化平台与自动化运维。

### 阅读顺序建议

| 你的情况 | 建议路径 |
|---------|---------|
| 完全没接触过服务器 | 按章节顺序从头读到尾 |
| 已有闲置电脑 | 跳过第二章选型，直接读第三/四章装系统 |
| 只想先玩 Linux | 第一章 → 2.1 → 第四章 → 第五章 |
| 已有 Mac，想玩 macOS 服务器 | 第一章 → 第三章 → 第五章 |

### 重要提醒（先读这三条）

1. **数据安全**：折腾服务器一定会经历"重装系统"，重要数据永远不要只放在服务器上，学习期就要养成备份习惯。
2. **电费与噪音**：7×24 开机的设备，功耗每高 10W，一年约多 87 度电；企业级二手机架服务器噪音可达 60 分贝以上，放卧室会崩溃。
3. **公网暴露要谨慎**：把服务暴露到公网之前，务必先读完第七章"安全加固"。

---

## 一、总体规划：目标与方案

### 1.1 学习目标定位

本文档以**学习**为第一目标，按四个阶段递进：

```
阶段一：硬件 + 系统     → 学会选型、装系统、让机器跑起来
阶段二：基础管理        → 学会远程管理、网络配置、无人值守
阶段三：服务搭建        → 学会部署文件/Web/应用服务，解决真实需求
阶段四：架构升级        → 学会虚拟化、容器编排、监控、自动化运维
```

### 1.2 双系统（macOS + Linux）的三种组合方案

macOS 受苹果许可限制只能合法运行在 Apple 硬件上，因此"macOS 服务器 + Linux 服务器"有三种组合方式：

| 方案 | 做法 | 成本 | 优点 | 缺点 |
|------|------|------|------|------|
| **A. 双机方案** | Mac mini 跑 macOS + 迷你主机/旧电脑跑 Linux | 高（两台设备） | 两台独立物理机，互不影响，可分别折腾 | 占地方、功耗双倍 |
| **B. Mac 虚拟化方案（推荐入门）** | 一台 Mac mini，macOS 宿主机 + UTM/Parallels 虚拟机跑 Linux | 中（一台设备） | 一台机器同时拥有两个系统；Apple Silicon 虚拟化 Linux 性能极好；静音省电 | Linux 不是物理机环境，网卡直通等高级玩法受限 |
| **C. x86 虚拟化方案** | 一台 x86 机器装 Proxmox VE，虚拟出多台 Linux；macOS 另用现有 Mac | 中 | 学习企业级虚拟化，Linux 可开多台 | 无法合法虚拟 macOS（黑苹果违反许可且不稳定，不推荐） |

**本文档推荐路线**：

- 预算有限 / 先试水：**方案 B**（一台 Mac mini 全搞定，也最容易上手）
- 想深入学习虚拟化与运维：先 **方案 B** 入门，后期加一台 x86 迷你主机升级到 **方案 A + C** 混合（Mac mini 跑 macOS，x86 机器装 Proxmox VE 跑多台 Linux）

### 1.3 总体路线图（L0 ~ L8 难度分级）

```
L0 硬件选型与组装          ── 第 2 章
L1 系统安装与首次配置       ── 第 3、4 章
L2 远程管理（SSH/密钥）     ── 第 5 章
L3 文件服务（Samba/NFS）    ── 第 5 章
L4 Web 服务（Nginx）        ── 第 5 章
L5 Docker 应用服务          ── 第 5 章
L6 远程访问（内网穿透/DDNS） ── 第 6 章
L7 虚拟化与监控             ── 第 6 章
L8 自动化运维与备份          ── 第 6 章
```

每一级都**可独立验收**：做完 L2 你就有一台能远程管理的机器，做完 L5 你就有一台能跑真实应用的服务器，不必一口气走完。

---

## 二、阶段一：机器选型（硬件）

### 2.1 五条硬件路线对比

| 路线 | 典型设备 | 参考预算 | 功耗 | 噪音 | 适合谁 |
|------|---------|---------|------|------|--------|
| **A. 闲置旧电脑改造** | 旧笔记本/旧台式机 | ≈ 0 元 | 15~65W | 取决于风扇 | 零基础试水，验证兴趣 |
| **B. 迷你主机（x86）** | 零刻/铭凡/极摩客、华硕 NUC | 1000~3500 元 | 10~35W | 几乎静音 | Linux 服务器主力，性价比之选 |
| **C. Mac mini** | Mac mini（M4 或更新款） | 3000~5000 元 | 5~15W | 完全静音 | macOS 服务器唯一正经选择，也最适合方案 B（虚拟化 Linux） |
| **D. 二手企业级服务器** | Dell R730 / HP DL380 Gen9 | 800~3000 元 | 100~300W | **很吵（>50dB）** | 想学 IPMI、RAID、ECC 内存等企业级特性；只推荐有独立空间（阳台/储藏室）的玩家 |
| **E. 开发板** | 树莓派 5 / 香橙派 | 400~800 元 | 5~10W | 无风扇静音 | 低功耗入门、ARM 架构学习；性能与生态受限 |

**选型决策树**：

```
有闲置电脑吗？ ──有──→ 先用旧电脑装 Linux 试水（路线 A）
      │无
      ▼
必须要 macOS 服务器吗？ ──是──→ Mac mini（路线 C，可虚拟化 Linux）
      │否/不确定
      ▼
预算 <1500 元？ ──是──→ 二手迷你主机或开发板（路线 B/E）
      │否
      ▼
全新 x86 迷你主机（路线 B）：16GB 内存 + 512GB SSD 起步
```

### 2.2 针对"macOS + Linux 双版"的推荐配置

**推荐组合一（一台搞定，约 3500~5000 元）**：

| 部件 | 推荐 | 说明 |
|------|------|------|
| 主机 | Mac mini（M4 入门款 16GB+256GB，预算够上 24GB+512GB） | Apple Silicon 能效比极高，7×24 开机一年电费仅几十元 |
| 虚拟机 | UTM（免费开源）或 Parallels Desktop（付费） | 虚拟化 ARM 版 Ubuntu/Debian，性能损耗 <10% |
| 存储 | 外接 USB4/雷电硬盘盒 + NVMe SSD（1~2TB） | 内置 256GB 不够存数据，外置盘做数据盘 |

**推荐组合二（双机进阶，约 5000~8000 元）**：

| 机器 | 推荐 | 用途 |
|------|------|------|
| macOS 服务器 | Mac mini（M4 入门款） | macOS 服务、Apple 开发构建机 |
| Linux 服务器 | 零刻/铭凡/极摩客（R7 / Ultra5 级别，32GB+1TB） | 装 Ubuntu Server 或 Proxmox VE，跑 Docker、虚拟化 |

> 价格随时间波动，购买前请以电商实时价格为准。二手 Mac mini M2/M4 也是高性价比选择。

**避坑提示**：

1. 迷你主机尽量选**双网口**型号——后期玩软路由/虚拟化网络会用上；
2. 内存**至少 16GB**，玩虚拟化建议 32GB 起步（迷你主机内存多为板载或双槽，买前确认可扩展性）；
3. 不要买来历不明的"洋垃圾"主板套装，翻车率高且无保修；
4. Mac mini 做服务器无需高配芯片，M4 基础款性能已过剩，把钱加在内存上更值。

### 2.3 网络环境准备

服务器体验好坏，一半取决于网络：

| 项目 | 建议 |
|------|------|
| 连接方式 | **务必用网线**直连路由器/交换机，不要用 Wi-Fi 当服务器 |
| 路由器 | 能设置"IP 地址绑定（DHCP 静态分配）"即可，家用路由器都支持 |
| 交换机（可选） | 设备多于 4 台时加一个千兆/2.5G 交换机（百元级即可） |
| UPS（可选） | 数据重要后，配一个后备式 UPS（300~500 元），防止断电伤盘 |

---

## 三、阶段二（A）：macOS 服务器搭建

> 对应方案：Mac mini 作为 macOS 服务器。macOS 做服务器的优势：图形化易管理、Homebrew 生态、Apple 开发构建机；劣势：闭源、部分服务管理不如 Linux 标准化。

### 3.1 系统初始化设置

新机开机后按向导完成初始化，然后做以下服务器化设置（均在 `系统设置` 中操作）：

| 设置项 | 路径 | 推荐值 |
|--------|------|--------|
| 电脑名称 | 通用 → 关于本机 → 名称 | 起个固定主机名，如 `mac-server` |
| 自动登录 | 用户与群组 → 自动登录 | 开启（断电重启后无需人工输密码） |
| 关闭睡眠 | 显示器/电池（或节能） → 防止自动睡眠 | 开启；硬盘睡眠关闭 |
| 断电后来电自启 | 节能 → 断电后自动重新启动 | 开启 |
| 自动更新 | 通用 → 软件更新 | 安全响应开启，系统大版本更新改手动 |

命令行等价操作（管理员执行）：

```bash
# 设置主机名（三个都要设）
sudo scutil --set HostName mac-server
sudo scutil --set LocalHostName mac-server
sudo scutil --set ComputerName mac-server

# 禁止系统睡眠（接电源时）
sudo pmset -c sleep 0
# 禁止硬盘睡眠
sudo pmset -c disksleep 0
# 断电后来电自动开机
sudo pmset -c autorestart 1
# 显示器 10 分钟后关闭（省电且不影响服务）
sudo pmset -c displaysleep 10
```

### 3.2 开启远程管理

| 功能 | 设置路径 | 说明 |
|------|---------|------|
| **远程登录（SSH）** | 系统设置 → 通用 → 共享 → 远程登录 | 必开，这是服务器管理的命根子 |
| 屏幕共享（VNC） | 同上 → 屏幕共享 | 图形化远程桌面，家里网络内调试好用 |
| 文件共享（SMB） | 同上 → 文件共享 | 可先不开，L3 阶段再配置 |

命令行开启 SSH：

```bash
sudo systemsetup -setremotelogin on
# 验证
sudo systemsetup -getremotelogin
```

在另一台电脑上测试：

```bash
ssh 你的用户名@mac-server.local    # macOS 支持 mDNS，局域网内可用主机名.local
```

### 3.3 安装 Homebrew 与服务管理

macOS 上装服务的标准方式是 Homebrew + `brew services`：

```bash
# 安装 Homebrew（按提示操作）
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# 装几个服务器必备工具
brew install wget git htop tmux tree

# 示例：安装 nginx 并注册为开机自启服务
brew install nginx
brew services start nginx    # 底层是 launchd，开机自动拉起
```

`brew services` 就是 macOS 版的"系统服务管理器"，相当于 Linux 的 systemd，用它管理的服务开机自启、崩溃自动重启。

### 3.4 在 macOS 上虚拟化运行 Linux（方案 B 核心）

以 **UTM**（免费开源）为例：

1. 安装 UTM：`brew install --cask utm`
2. 下载 ARM64 版 Ubuntu Server 镜像：到 ubuntu.com 下载 `ubuntu-24.04.x-live-server-arm64.iso`（或更新 LTS 版本）
3. UTM 中新建虚拟机：
   - 选择 `Virtualize`（虚拟化，非模拟——ARM 宿主机跑 ARM 系统，性能接近原生）
   - 内存分配 4~8GB，CPU 4 核，磁盘 60GB+
   - 网络选 `Shared Network`（NAT，最省心）或 `Bridged`（桥接，虚拟机在局域网有独立 IP，推荐）
4. 启动后按第四章的 Linux 安装流程安装即可。

> 提示：虚拟机网络选 **Bridged（桥接）** 时，Linux 虚拟机会获得局域网独立 IP，可以和物理服务器一样被其他设备访问——强烈建议选桥接。

---

## 四、阶段二（B）：Linux 服务器搭建

> 对应方案：x86 迷你主机/旧电脑物理安装 Linux，或 Mac 虚拟化安装 ARM 版 Linux。安装流程两者完全一致。

### 4.1 发行版选择

| 发行版 | 特点 | 推荐人群 |
|--------|------|---------|
| **Ubuntu Server LTS（推荐）** | 文档最多、社区最大、教程随手可查 | 新手首选，本文档以它为例 |
| Debian Stable | 极其稳定、软件略旧 | 追求稳定的进阶用户 |
| Rocky Linux / AlmaLinux | RHEL 兼容系，企业环境同款 | 目标进企业运维岗 |
| openSUSE Leap | YaST 管理工具强大 | 想换口味的玩家 |
| Arch Linux | 滚动更新、一切自己配 | 想深入理解系统组成（不建议第一台服务器就用） |

**结论：第一台 Linux 服务器就选 Ubuntu Server LTS**，学透之后再玩别的。

### 4.2 制作启动 U 盘（物理机安装时）

准备一个 8GB 以上 U 盘（数据会被清空）：

**方式一：图形化工具（推荐）**

下载 [balenaEtcher](https://etcher.balena.io/)（免费、跨平台）→ 选择 ISO → 选择 U 盘 → Flash，三步完成。

**方式二：macOS 命令行**

```bash
# 1. 查看 U 盘设备号（比如 /dev/disk4），务必确认清楚，写错盘会丢数据！
diskutil list

# 2. 卸载 U 盘（不弹出）
diskutil unmountDisk /dev/diskN

# 3. 下载 Ubuntu Server ISO 后写入（把 diskN 换成实际编号，if= 换成实际 ISO 路径）
sudo dd if=~/Downloads/ubuntu-24.04-live-server-amd64.iso of=/dev/rdiskN bs=4m status=progress

# 4. 完成后弹出
diskutil eject /dev/diskN
```

### 4.3 安装 Ubuntu Server 全流程

1. 插入 U 盘开机，按启动键进启动菜单（常见：华硕 F8、技嘉 F12、微星 F11、Intel NUC F10，开机画面有提示）；
2. 选择 U 盘启动，进入安装器（`Try or Install Ubuntu Server`）；
3. 安装向导关键步骤：
   - **语言**：建议 English（服务器日志/报错都是英文，避免乱码）
   - **网络**：确认网卡获取到 IP，记下这个 IP
   - **存储**：新手直接选 `Use an entire disk` 全盘安装（勾不勾 LVM 都行，默认勾选即可）
   - **用户**：创建你的管理用户（**不要**用 root 当日常用户）
   - **SSH Setup**：**务必勾选 `Install OpenSSH server`**
   - **Featured Snaps**：新手可全不选，保持干净，软件后面自己装
4. 安装完成重启，拔掉 U 盘。

### 4.4 首次启动必做配置

```bash
# 1. 更新系统
sudo apt update && sudo apt upgrade -y

# 2. 安装基础工具
sudo apt install -y vim git curl wget htop tmux net-tools ufw

# 3. 设置固定 IP（推荐在路由器上做"IP/MAC 绑定"：
#    登录路由器管理页 → DHCP 静态分配 → 把服务器 MAC 绑定到固定 IP，如 192.168.1.10）
#    查看本机 MAC 与 IP：
ip addr

# 4. 设置主机名
sudo hostnamectl set-hostname linux-server

# 5. 配置时区与时间同步
sudo timedatectl set-timezone Asia/Shanghai
timedatectl status

# 6. 从另一台电脑测试 SSH 登录
ssh 你的用户名@192.168.1.10
```

**无人值守设置（物理机）**：

- 进 BIOS 开启 `Restore on AC Power Loss`（来电自启）——各品牌 BIOS 位置不同，搜"主板型号 + 来电自启"；
- 笔记本当服务器：合盖不睡眠 → `sudo nano /etc/systemd/logind.conf`，设置 `HandleLidSwitch=ignore`，然后 `sudo systemctl restart systemd-logind`（注意：会注销当前会话）。

---

## 五、阶段三：基础服务搭建（L2 → L5，从易到难）

> 以下服务在 macOS 和 Linux 上都能搭，命令以 Linux（Ubuntu）为主，macOS 差异处单独标注。每完成一级都有明确的"验收标准"。

### L2：SSH 密钥登录与远程管理

**目标**：免密码安全登录，禁用密码登录。

```bash
# —— 在你的日常电脑（客户端）上执行 ——
# 1. 生成密钥对（已有可跳过）
ssh-keygen -t ed25519 -C "your_email@example.com"

# 2. 把公钥推送到服务器
ssh-copy-id 用户名@服务器IP

# 3. 测试免密登录
ssh 用户名@服务器IP
```

```bash
# —— 在服务器上执行：加固 SSH ——
sudo nano /etc/ssh/sshd_config
# 修改/确认以下三项：
#   PasswordAuthentication no      # 禁用密码登录（只认密钥）
#   PermitRootLogin no             # 禁止 root 直接登录
#   Port 22                        # 可改为非常用端口如 2222（可选，减少扫描骚扰）

# macOS 注意：配置文件同样是 /etc/ssh/sshd_config，
# 但重启服务的命令不同：
#   Linux:  sudo systemctl restart ssh
#   macOS:  sudo launchctl kickstart -k system/com.openssh.sshd
```

**验收**：新开终端 `ssh 用户@IP` 不需要输密码；用错误密码登录会被拒绝。

**加分项**：给 SSH 配置别名，在客户端的 `~/.ssh/config` 中：

```
Host myserver
    HostName 192.168.1.10
    User 你的用户名
    Port 22
```

之后只需 `ssh myserver` 即可登录。

### L3：文件共享服务

**目标**：家里所有设备都能访问服务器的共享文件夹；Mac 能把服务器当 Time Machine 备份盘。

**Linux 上搭建 Samba**（兼容 Windows/Mac 访问）：

```bash
sudo apt install -y samba

# 建共享目录
sudo mkdir -p /srv/share
sudo chown -R $USER:$USER /srv/share

# 配置 Samba
sudo tee -a /etc/samba/smb.conf <<'EOF'

[share]
   path = /srv/share
   browseable = yes
   read only = no
   guest ok = no
EOF

# 添加 Samba 用户（密码独立设置）
sudo smbpasswd -a $USER
sudo systemctl restart smbd
```

**macOS 上共享**：`系统设置 → 通用 → 共享 → 文件共享`，添加共享文件夹并勾选"通过 SMB 共享"即可，无需命令行。

**访问方式**：

- Mac：`访达 → 前往 → 连接服务器（⌘K）` → 输入 `smb://192.168.1.10/share`
- Windows：资源管理器地址栏输入 `\\192.168.1.10\share`

**验收**：从手机（如 iPhone 的"文件"App）也能连上共享并读写文件。

### L4：Web 服务（Nginx）

**目标**：服务器能提供网页访问，理解 Web 服务基本原理。

```bash
# Linux
sudo apt install -y nginx
sudo systemctl enable --now nginx

# macOS
brew install nginx
brew services start nginx
```

浏览器访问 `http://服务器IP`，看到 Nginx 欢迎页即成功。

写一个自己的首页：

```bash
# Linux 默认站点目录
echo '<h1>My Home Server</h1>' | sudo tee /var/www/html/index.html

# macOS (Homebrew nginx) 默认站点目录
echo '<h1>My Home Server</h1>' > /opt/homebrew/var/www/index.html   # Apple Silicon
# Intel Mac 路径为 /usr/local/var/www/index.html
```

**进阶练习**：学习 Nginx 反向代理——这是后面所有 Web 应用的入口，核心配置就一段：

```nginx
location /app/ {
    proxy_pass http://127.0.0.1:8080/;   # 把 /app/ 转发给本机 8080 端口的应用
}
```

**验收**：局域网任意设备浏览器打开 `http://服务器IP` 能看到你的首页。

### L5：Docker 应用服务（重头戏）

**目标**：用容器化方式部署真实应用，这是现代服务器的标准玩法。

```bash
# 1. 安装 Docker（Ubuntu 官方一键脚本）
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER    # 加入 docker 组，免 sudo
newgrp docker                    # 立即生效（或重新登录）

# 2. 验证
docker run hello-world
```

> macOS 上装 Docker Desktop（`brew install --cask docker`）即可，但学习服务器更建议把 Docker 跑在 Linux（物理机或虚拟机）里——生产环境服务器全是 Linux。

**部署三个经典自用应用**（每个都是几行命令的事）：

**① Gitea —— 私有 Git 服务（给自己的代码找个家）**

```bash
mkdir -p ~/docker/gitea && cd ~/docker/gitea
cat > docker-compose.yml <<'EOF'
services:
  gitea:
    image: gitea/gitea:latest
    container_name: gitea
    restart: unless-stopped
    ports:
      - "3000:3000"     # Web 界面
      - "2222:22"       # SSH 克隆
    volumes:
      - ./data:/data
EOF
docker compose up -d
```

访问 `http://服务器IP:3000` 完成初始化，你就有了自己的 GitHub。

**② Nextcloud —— 私有网盘**

```bash
mkdir -p ~/docker/nextcloud && cd ~/docker/nextcloud
cat > docker-compose.yml <<'EOF'
services:
  nextcloud:
    image: nextcloud:latest
    container_name: nextcloud
    restart: unless-stopped
    ports:
      - "8080:80"
    volumes:
      - ./data:/var/www/html
EOF
docker compose up -d
```

**③ Vaultwarden —— 自托管密码管理器（Bitwarden 兼容）**

```bash
docker run -d --name vaultwarden --restart unless-stopped \
  -p 8081:80 -v ~/docker/vaultwarden/data:/data vaultwarden/server:latest
```

**验收**：三个服务都能在浏览器打开；`docker ps` 查看运行状态；重启服务器后服务自动拉起（`restart: unless-stopped` 的功劳）。

**docker 常用命令速查**：

```bash
docker ps                 # 看运行中的容器
docker logs -f 容器名      # 看日志
docker compose up -d      # 启动（在 compose 文件目录）
docker compose down       # 停止并删除
docker compose pull && docker compose up -d   # 升级到最新镜像
```

---

## 六、阶段四：进阶架构（L6 → L8）

### L6：远程访问——在外面也能连回家里服务器

家里宽带通常没有公网 IPv4，三种方案按推荐程度排序：

**方案一：Tailscale（强烈推荐，最简单最安全）**

Tailscale 基于 WireGuard，把服务器、手机、笔记本组成一个虚拟内网，无论身在何处都像在同一个局域网：

```bash
# Linux 安装
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up        # 浏览器扫码登录一次即可

# macOS 安装
brew install --cask tailscale    # 或 App Store 下载
```

装完后服务器会获得一个 `100.x.x.x` 的固定虚拟 IP，手机/电脑装上 Tailscale 登录同一账号，随时随地 `ssh`、访问 Gitea/Nextcloud，**无需公网 IP、无需端口转发、流量端到端加密**。

**方案二：DDNS + 端口转发（有公网 IPv4 或 IPv6 时）**

1. 确认有公网 IP：路由器 WAN 口 IP 与 `curl ifconfig.me` 的结果一致则有公网 IPv4；或运营商普遍已下发公网 IPv6；
2. 路由器上配置端口转发：外网端口 → 服务器内网 IP:端口；
3. 用 DDNS 把动态 IP 绑定到域名（如阿里云/腾讯云域名 + 路由器自带 DDNS 或 `ddns-go` 容器）；
4. **必须配合第七章安全措施**，暴露公网等于接受全网扫描。

**方案三：frp 内网穿透（无公网 IP 且需要域名访问时）**

租一台最便宜的云 VPS（有公网 IP），在 VPS 上跑 frps，家里服务器跑 frpc，把内网服务映射出去。适合要给他人提供访问的场景（如给朋友分享一个链接）。

**验收**：关闭手机 Wi-Fi 用 5G，能 SSH 登录服务器、能打开 Nextcloud。

### L7：虚拟化平台与监控告警

**虚拟化：Proxmox VE（x86 机器专属，方案 C）**

当一台 Linux 不够玩时，把 x86 迷你主机刷成 Proxmox VE（PVE）——开源企业级虚拟化平台：

1. 到 proxmox.com 下载 PVE ISO，用 balenaEtcher 写 U 盘安装（和装 Ubuntu 一样简单）；
2. 装完浏览器访问 `https://服务器IP:8006` 进入 Web 管理台；
3. 之后创建 VM（完整虚拟机）或 LXC 容器（轻量，秒级创建）都在网页上点几下完成；
4. 典型玩法：一个 LXC 跑 Docker、一个 VM 跑 Ubuntu 桌面版练手、一个 VM 专门做破坏性实验随便折腾。

> 这是从"玩服务器"到"玩数据中心"的分水岭：快照、克隆、热迁移、备份计划，全是企业运维的真实技能。

**监控告警：Uptime Kuma（10 分钟上手）**

```bash
docker run -d --name uptime-kuma --restart unless-stopped \
  -p 3001:3001 -v ~/docker/uptime-kuma:/app/data louislam/uptime-kuma:latest
```

访问 `http://服务器IP:3001`，把你的 Gitea、Nextcloud、Nginx 都加进去，服务挂了立刻推送通知（支持企业微信/Telegram/邮件等几十种渠道）。

**进阶监控：Prometheus + Grafana**

想看 CPU/内存/磁盘/网络曲线时，部署 `node_exporter` 采集指标 + Prometheus 存数据 + Grafana 画大盘。这是生产环境标准监控栈，值得作为 L7 的毕业项目。

### L8：自动化运维与备份

**自动化：Ansible**

当你有两台以上服务器，手动敲命令就是重复劳动。Ansible 用 YAML 描述"服务器应该长什么样"，一条命令批量配置：

```yaml
# playbook.yml 示例：一条命令给所有服务器装好基础环境
- hosts: all
  become: yes
  tasks:
    - name: 安装基础工具
      apt:
        name: [vim, git, htop, tmux, ufw]
        state: present
    - name: 确保 Docker 已安装
      apt:
        name: docker.io
        state: present
```

```bash
ansible-playbook -i inventory.ini playbook.yml
```

**备份策略（3-2-1 原则）**

- **3** 份副本：原始数据 + 2 份备份；
- **2** 种介质：服务器硬盘 + 外接硬盘/NAS；
- **1** 份异地：加密后传云盘（对象存储/网盘）。

落地工具：

```bash
# rsync 增量备份到外接硬盘（简单可靠）
rsync -avh --delete /srv/share/ /mnt/backup/share/

# 或用 restic（加密、去重、版本快照，推荐）
restic -r /mnt/backup/restic-repo backup /srv/share ~/docker
```

写个 cron 定时任务每天凌晨自动备份：

```bash
crontab -e
# 添加：
# 0 3 * * * /home/你的用户名/scripts/backup.sh >> /var/log/backup.log 2>&1
```

**验收标准（L8 毕业）**：故意 `docker stop gitea`，5 分钟内收到 Uptime Kuma 告警；格式化服务器重装后，能用 Ansible + 备份在 1 小时内恢复全部服务。

---

## 七、安全加固清单（暴露公网前必做）

按重要性排序，做完前 5 项再考虑开放任何公网端口：

- [ ] **1. SSH 禁用密码登录**，只用密钥（见 L2）
- [ ] **2. 开启防火墙**，默认拒绝所有入站，只放行需要的端口：

```bash
# Linux (ufw)
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 22/tcp        # SSH（如改端口则放行新端口）
sudo ufw allow 80,443/tcp    # Web
sudo ufw enable

# macOS：系统设置 → 网络 → 防火墙 → 打开
```

- [ ] **3. 安装 fail2ban**，自动封禁暴力破解 IP：

```bash
sudo apt install -y fail2ban
sudo systemctl enable --now fail2ban
```

- [ ] **4. 系统与容器定期更新**：

```bash
# 开启 Ubuntu 安全更新自动安装
sudo apt install -y unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades
```

- [ ] **5. Web 服务上 HTTPS**：用 Caddy（自动申请 Let's Encrypt 证书，配置仅两行）或 Nginx + certbot：

```bash
# Caddy 的 Caddyfile 示例（自动 HTTPS，强烈推荐新手）
git.example.com {
    reverse_proxy 127.0.0.1:3000
}
```

- [ ] 6. 数据库、管理后台**不要直接暴露公网**，前面必须套 Nginx/Caddy 反代 + HTTPS；
- [ ] 7. 定期检查谁在登录：`last`、`journalctl -u ssh --since today`；
- [ ] 8. 容器镜像只用官方源，不用来路不明的第三方镜像。

---

## 八、架构升级路线图

```
┌─────────────────────────────────────────────────────────────┐
│ 第一阶段：单机裸装                                            │
│   旧电脑/迷你主机 → 装 Ubuntu Server → SSH → Samba → Nginx   │
│   能力：远程管理、文件共享、网页服务                            │
└───────────────────────┬─────────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────────┐
│ 第二阶段：容器化                                              │
│   Docker + docker-compose → Gitea / Nextcloud / Vaultwarden  │
│   + Tailscale 远程访问 + Uptime Kuma 监控                     │
│   能力：随时随地的私有云服务                                   │
└───────────────────────┬─────────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────────┐
│ 第三阶段：双系统/多机                                         │
│   Mac mini（macOS 服务器 + Apple 开发构建机）                 │
│   + x86 主机（Linux 主力服务器）                              │
│   能力：双平台服务、跨平台开发与测试                           │
└───────────────────────┬─────────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────────┐
│ 第四阶段：虚拟化平台                                          │
│   x86 主机刷 Proxmox VE → 一机虚拟多台 Linux/LXC 容器         │
│   快照、克隆、备份计划、资源隔离                               │
│   能力：企业级虚拟化运维                                      │
└───────────────────────┬─────────────────────────────────────┘
                        ▼
┌─────────────────────────────────────────────────────────────┐
│ 第五阶段：自动化与高可用                                      │
│   Ansible 批量管理 + restic 自动备份 + Prometheus/Grafana     │
│   可选：K3s 轻量 Kubernetes 集群（多台机器组成集群）           │
│   能力：基础设施即代码、可观测性、容器编排                      │
└─────────────────────────────────────────────────────────────┘
```

每个阶段稳定运行 2~4 周再进阶，期间把遇到的问题和解决方法记成笔记——这些笔记就是你自己的运维知识库。

---

## 九、推荐学习资源

### 系统与运维

| 资源 | 说明 |
|------|------|
| 《鸟哥的 Linux 私房菜（基础学习篇）》 | Linux 入门经典，免费在线版：linux.vbird.org |
| Ubuntu Server 官方文档 | ubuntu.com/server/docs，权威且更新及时 |
| Linux Journey | linuxjourney.com，交互式免费教程 |
| 《UNIX/Linux 系统管理技术手册》 | 运维案头书，查概念必备 |

### Docker 与虚拟化

| 资源 | 说明 |
|------|------|
| Docker 官方 Get Started | docs.docker.com/get-started，半天跑完 |
| docker-compose 官方文档 | 学会写 compose 文件就掌握了 80% 自用部署 |
| Proxmox VE 官方 Wiki | pve.proxmox.com/wiki |
| 《Docker 技术入门与实战》 | 中文入门书，适合快速过一遍 |

### 网络与安全

| 资源 | 说明 |
|------|------|
| 《图解 TCP/IP》 | 轻松读懂网络协议 |
| Tailscale 官方文档 | tailscale.com/kb，顺便学 WireGuard 原理 |
| Mozilla SSL Configuration Generator | ssl-config.mozilla.org，生成安全的 Web 服务器配置 |
| fail2ban 官方文档 | 理解入侵防护基本原理 |

### 宝藏清单（持续发现可自托管的应用）

| 资源 | 说明 |
|------|------|
| awesome-selfhosted | github.com/awesome-selfhosted/awesome-selfhosted，自托管应用大全，挑应用先逛这里 |
| linuxserver.io | 高质量 Docker 镜像团队，文档详尽 |

---

## 十、常见问题 FAQ

**Q1：我没有公网 IP，服务器白搭了吗？**
不白搭。局域网内的文件共享、Git、网盘照常可用；出门在外用 Tailscale（L6 方案一）即可获得与局域网完全一致的访问体验，而且更安全。只有"需要给不特定的人提供公开访问"时才真正需要公网 IP。

**Q2：macOS 服务器和 Linux 服务器该把服务部署在哪边？**
建议：**macOS 侧**放 Apple 生态相关的（Xcode 构建、Time Machine、文件共享）；**Linux 侧**放所有 Docker 应用（Gitea/Nextcloud/监控等）。Linux 的容器生态和稳定性更适合 7×24 跑服务。

**Q3：二手企业级服务器（如 Dell R730）很便宜，值得买吗？**
只推荐给有独立隔音空间、明确想学企业级硬件（IPMI 带外管理、硬件 RAID、ECC 内存）的玩家。它的电费和噪音成本一年就超过一台迷你主机，家用学习性价比很低。

**Q4：虚拟机和 Docker 容器有什么区别，服务该放哪？**
虚拟机隔离一整个操作系统，容器共享宿主机内核。自用服务（Gitea 等）一律用 Docker，轻量好管理；需要隔离环境做实验（如测试不同发行版、破坏性操作）才开虚拟机。

**Q5：服务器被我从 SSH 锁在外面了（改错配置/防火墙误封）怎么办？**
物理机：接显示器键盘本地登录修复（这就是为什么学习服务器最好放在手边）。这也是为什么改防火墙和 SSH 配置时，要保留一个已登录的会话做"保险绳"，确认新会话能登录再关旧的。

**Q6：玩服务器一个月电费多少？**
迷你主机/Mac mini 平均功耗约 10~15W，一个月约 7~11 度电，不到 10 元；旧笔记本约 30W，一个月约 22 度；企业级机架服务器 150W+，一个月 100 度以上。

**Q7：想往职业运维/SRE 方向发展，应该重点深入哪部分？**
L7~L8：Proxmox/虚拟化、Prometheus 监控体系、Ansible 自动化，之后继续学 Kubernetes（可先用 K3s 在家搭建集群）——这条线就是企业基础设施的标准技术栈。

---

## 附录 A：本文档推荐购物清单速查

| 物品 | 推荐 | 预算 |
|------|------|------|
| macOS 服务器主机 | Mac mini M4（16GB+256GB） | ~3500 元起 |
| Linux 服务器主机 | 零刻/铭凡 R7 级迷你主机（32GB+1TB，双网口） | ~2500~3500 元 |
| 数据盘 | USB4/雷电硬盘盒 + 1TB NVMe SSD | ~500 元 |
| U 盘（装系统用） | 任意 8GB+ | ~30 元 |
| 网线 | 六类线 × 2 | ~20 元 |
| UPS（可选，数据重要后配） | 后备式 600VA | ~350 元 |
| **入门总计（单机方案 B）** | | **~4000 元** |
| **双机方案总计** | | **~7000 元** |

## 附录 B：验收自检表

每完成一个阶段，勾选确认：

- [ ] L1：服务器装好系统，能通过 SSH 登录
- [ ] L2：SSH 密钥免密登录，已禁用密码登录
- [ ] L3：局域网设备能访问共享文件夹
- [ ] L4：浏览器能打开服务器上的网页
- [ ] L5：Gitea/Nextcloud 等 Docker 应用正常运行且开机自启
- [ ] L6：外出用 5G 能连回服务器
- [ ] L7：服务挂掉能收到告警通知
- [ ] L8：重装系统后能在 1 小时内恢复全部服务
