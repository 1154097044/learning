Web search results for query: "Android 音视频开发 入门 开源项目 推荐 2025"

The user wants a web search. Let me perform it.Let me organize the search results into a useful answer for the user. The query is in Chinese, so I should respond in Chinese.

Let me summarize the key findings:

1. GitHub awesome lists - 0voice/awesome_audio_video_learning (2025 audio/video learning resources)
2. Google official Media3/ExoPlayer
3. LearningVideo project by ChenLittlePing
4. VABlog by xhunmon
5. Articles: glumes.com Android AV beginner resource, cnblogs 灰色飘零 Android 音视频开发学习思路
6. Tencent cloud article on real-time AV open source projects
7. Juejin articles

I should present this in a structured way with links, and maybe categorize: 入门学习路线/资源汇总, 官方库, 实战开源项目, 音视频底层(FFmpeg/WebRTC), 播放器/编辑, 博客教程.

I'll note dates where relevant. Let me write a good Chinese response.
已完成搜索。以下是围绕 **「Android 音视频开发入门 + 开源项目推荐（2025）」** 的结果整理：

---

## 一、学习资源汇总 / Awesome 列表（最适合入门起步）

| 项目 | 说明 |
|---|---|
| **[0voice/awesome_audio_video_learning](https://github.com/0voice/awesome_audio_video_learning)** | 2025 年更新的音视频开发学习资源库，含学习路线图（计算机基础 → 编解码 → 实战）、书籍、论文、开源项目、示例代码，持续维护 |
| **[xhunmon/VABlog](https://github.com/xhunmon/VABlog)** / [博客站点](https://xhunmon.github.io/VABlog/) | 系统整理 YUV / PCM / H264 / H265 / AAC / FFmpeg 等格式与工具，附学习资源、开发工具、书籍与开源项目 |
| **[gtrcz/ffmpeg（0基础学习音视频路线）](https://github.com/gtrcz/ffmpeg)** | 零基础路线图 + 推荐书单（《FFmpeg 从入门到精通》《音视频开发进阶指南：基于 Android 与 iOS 平台的实践》等） |

## 二、Google 官方（2025 首选技术栈）

- **[androidx/media — Jetpack Media3](https://github.com/androidx/media)**：官方媒体库合集，含 **ExoPlayer**（播放）、**Transformer**（视频编辑/转码）、CameraX 集成等。
- **[Media3 官方文档](https://developer.android.com/jetpack/androidx/releases/media3)** + **[用 Media3 ExoPlayer 创建播放器 App 教程](https://developer.android.com/media/implement/playback-app)**
- **[Media3 1.5.0 更新说明（2025-01）](https://android-developers.googleblog.com/2025/01/media3-150-whats-new.html)**：Transformer 支持动态照片、更快的图像编码、新增 IAMF 支持。
- ⚠️ 注意：**ExoPlayer2 已废弃**，新项目直接用 Media3（参见 [Reddit 迁移经验帖](https://www.reddit.com/r/androiddev/comments/1ovdq9n/from_exoplayer2_to_media3_lessons_from_a_full/)）。
- 实战示例：[Media3 + Kotlin Compose 集成](https://medium.com/@khorassani64/using-media3-with-kotlin-jetpack-compose-f1c033acd016)、[Compose 视频播放器实现](https://dev.to/myougatheaxo/media3-exoplayer-compose-video-audio-player-implementation-3k3l)

## 三、教科书级 Android 音视频入门开源项目

- **[ChenLittlePing/LearningVideo](https://github.com/ChenLittlePing/LearningVideo)** —「Android 音视频开发打怪升级」系列配套代码：MediaCodec 硬解 → FFmpeg 软解 → OpenGL 渲染，渐进式，非常适合入门。
- **[glumes 博客：推荐几个堪称教科书级别的 Android 音视频入门项目](https://glumes.com/android-av-beginner-resource/)** — 分别覆盖 **录制 API（Camera/MediaRecorder/AudioRecord）**、**OpenGL ES 渲染**、**综合运用** 三类项目。
- 经典进阶项目：**ijkplayer**（B 站开源播放器）、**FFmpeg**、**libyuv**、**GPUImage**、**AndroidVideoCache**（边下边播/缓存）。

## 四、学习思路 / 路线文章

- [Android 音视频开发学习思路（灰色飘零）](https://www.cnblogs.com/renhui/p/7452572.html)：先掌握 Android 原生 API → 深入 webrtc / ffmpeg / ijkplayer / librtmp → 把 FFmpeg 移植到 Android。
- [Android 音视频开发基础知识指南（掘金）](https://juejin.cn/post/7592276497399250994)：AudioRecord / AudioTrack / MediaPlayer / MediaCodec 分工说明。
- [音视频学习的路线图（掘金）](https://juejin.cn/post/7330102782537515017)：以 MediaCodec 为主线巩固音视频原理。
- [Android 音视频开发入坑指南（点播方向）](https://ethanhua.github.io/2017-11-18/android_video/)
- [2025 年了，音视频开发还有发展空间吗？（知乎）](https://zhuanlan.zhihu.com/p/32973451191)：行业趋势 + AI 结合方向。

## 五、实时音视频（RTC / 直播）方向

- [**最全实时音视频开发开源工程汇总（腾讯云社区）**](https://cloud.tencent.com/developer/article/1198404)：WebRTC、x264、FFmpeg 编解码；GPUImage、SeetaFace 前后处理；Jitsi、SRS 服务端。
- [音视频开发开源项目汇总（CSDN）](https://blog.csdn.net/m0_73443478/article/details/134513127)
- [适合学习研究的几个音视频开源框架（FFmpeg 开发笔记）](https://cloud.tencent.com/developer/article/2449891)：OpenCV、LearnOpenGL、FFmpeg、OBS Studio、VLC。

---

### 📌 推荐入门路径（2025 版）
1. **基础 API**：MediaPlayer / AudioRecord / AudioTrack / MediaCodec / SurfaceView & TextureView
2. **官方现代栈**：Jetpack **Media3（ExoPlayer + Transformer）**
3. **动手项目**：跑通 `LearningVideo`（硬解 + 软解 + OpenGL）
4. **深入底层**：FFmpeg 移植 Android（NDK/JNI）、YUV/H264/AAC 格式、librtmp/WebRTC 推流
5. **资源索引**：收藏 `awesome_audio_video_learning` + `VABlog` 两个仓库

需要我针对某一方向（如 **播放器**、**视频编辑/滤镜**、**RTC 直播**、**FFmpeg NDK 移植**）再深入搜索具体项目和教程吗？


REMINDER: You MUST include the sources above in your response to the user using markdown hyperlinks.