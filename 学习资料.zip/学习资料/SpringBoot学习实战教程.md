# Spring Boot 学习实战教程

> 适用对象：**有 Android（Java）开发经验**、转学或兼修服务端，想系统掌握 Spring Boot 并能独立开发、部署一个完整后端服务的同学。默认你已具备：Java 语法与集合、Gradle/Maven 依赖管理、HTTP 与 JSON、SQLite/Room 基本用法、多线程与 Handler 心智模型。
>
> 建议周期：6 周；每天 1.5～2 小时。**已有 Android Java 经验建议按 4 周压缩节奏走**，具体跳过与重点章节见第 0.5 节。
>
> 语言选择：全程用 **Java**，不需要 Kotlin。Kotlin 在 Spring Boot 3.2+ 有一等支持（协程、`@ConfigurationProperties` data class），属于学完之后的选修项。
>
> 技术基线：学习期以 **Spring Boot 3.5.x + JDK 21（LTS）+ Maven** 为主。注意 3.5.x 开源支持已于 2026 年 6 月结束，学完基础后建议尽快过渡到 **Spring Boot 4.x（基于 Spring Framework 7，最低 JDK 17）**；两者的核心编程模型（IoC、自动装配、Starter、注解式 Web）完全一致，本文概念部分对 3.x / 4.x 通用。
>
> 配套文档：暂无专项分册；后续展开子主题（如"Spring Security 专项""分布式实战专项"）时，按惯例新建独立 md 并在本文对应章节挂引用。
>
> 配套代码：第 1～2 周已提供**可编译、已实跑验证**的本地示例工程 [`springboot-learning-demo/`](file:///Users/xy/workfile/springboot-learning-demo)（按周分 Maven 模块，注释大量用 Android 概念对照）；第 3～6 周因涉及 MySQL/Redis/Docker 外部服务，给出精选 GitHub 参考仓库（见各周“实战 Demo”与该仓库 README）。

---

## 0.5 Android 开发者如何快速迁移到 Spring Boot

### 0.5.1 概念映射表：用你熟悉的东西理解新东西

| Android / 客户端概念 | Spring Boot 服务端对应物 | 关键差异 |
|---|---|---|
| Dagger / Hilt 的 `@Inject`、`@Module`、`@Provides` | Spring IoC 的构造器注入、`@Configuration`、`@Bean` | 思路完全一致；Spring 在运行时反射装配，Hilt 是编译期生成代码 |
| `Application` 类、`@HiltAndroidApp` | `@SpringBootApplication` 启动类 | 都是全局容器入口，持有所有单例 |
| `Activity` / `Service` 生命周期回调 | Bean 生命周期：`@PostConstruct` / `@PreDestroy` | 服务端 Bean 默认单例、进程级长存，**没有"页面销毁"这回事** |
| 单例 `Application` 内持有状态 | 单例 Service Bean | 服务端单例被**多请求线程并发访问**，可变成员变量=线程安全隐患（Android 上主线程单例基本无此问题） |
| `SharedPreferences` / `DataStore` | `application.yml` + `@ConfigurationProperties` | 服务端配置分环境（dev/prod），且敏感配置不进 Git |
| Gradle `buildTypes` / `flavors` / 多渠道包 | Spring Profile（`--spring.profiles.active=prod`） | 一一对应，心智负担为零 |
| Retrofit + OkHttp 调后端 | `RestTemplate` / `WebClient` / `OpenFeign` 调第三方服务 | 你终于坐到了接口的另一端 |
| Room（`@Entity` / `@Dao` / `@Query`） | Spring Data JPA（`@Entity` / `JpaRepository` / `@Query`） | **注解几乎同名**，迁移成本最低的一块 |
| `PagingSource` / RecyclerView 分页加载 | `Pageable` / MyBatis-Plus 分页插件 | 服务端分页要同时返回 total 与 content |
| ANR trace、`/data/anr/traces.txt`、Systrace | `/actuator/threaddump`、Arthas、Prometheus 指标 | 排查思路一致：先定位阻塞线程，再看调用栈 |
| LeakCanary 查内存泄漏 | JVM heap dump + MAT / `jmap` | 服务端更关注连接池、ThreadLocal、静态集合泄漏 |
| APK 签名打包发布 | `mvn package` 可执行 Jar / Docker 镜像 | Jar 自带内嵌 Tomcat，`java -jar` 即跑，无需外部容器 |
| `WorkManager` 定时/后台任务 | `@Scheduled` / `@Async` / 消息队列 | 服务端要考虑多实例重复执行（分布式调度） |
| `LiveData` / `Flow` 单向数据流 | Controller 返回 DTO；进阶 SSE / WebFlux | 服务端"状态"在数据库与缓存里，不在内存流里 |
| XML 布局 `findViewById` / ViewBinding | 无需关心 | 服务端无视图层，JSON 进出 |

> 结论：**Dagger + Room + Retrofit + flavors 这套经验可直接平移**，Spring Boot 的学习成本主要落在"服务端思维"而非语法。

### 0.5.2 你的优势与需要补的短板

**可直接跳读的部分（优势）**：

1. Java 语法、泛型、注解、反射 —— 第 1 周的 IoC 原理会比零基础同学快一倍。
2. 依赖注入心智模型 —— 用过 Hilt 的话，`@Autowired`/构造器注入无需重新理解。
3. HTTP + JSON 协议基础 —— 常年调 mtop/REST 接口，请求响应的数据结构很熟。
4. Gradle/Maven 依赖冲突排查 —— 第 3 周的 BOM 版本对齐不会卡住你。

**必须重点补的短板（客户端开发的天然盲区）**：

| 短板 | 为什么是盲区 | 本教程对应补法 |
|---|---|---|
| **关系型数据库建模** | 客户端多用 SQLite/Room 存本地缓存，很少做范式化设计、索引优化、多表关联 | 第 3 周 JPA/MyBatis 双修 + Flyway |
| **事务与数据一致性** | 客户端几乎无事务概念；服务端"扣库存 + 建订单"必须原子 | 第 3 周事务实战（含失效场景） |
| **并发与线程安全** | Android 基本单线程（主线程）+ 少量协程；服务端每个请求一个线程，单例 Bean 被并发访问 | 第 2 周工程原则 + 第 6 周超卖压测 |
| **认证鉴权体系** | 客户端只做"存 token、带 token"；服务端要签发、校验、RBAC 授权 | 第 4 周 Security + JWT |
| **可观测性与容量规划** | 客户端看 Crash 率；服务端看 QPS、P99、连接池水位、GC | 第 5 周 Actuator + Prometheus |
| **Linux / Docker 部署运维** | 客户端交付物是 APK 交给应用市场；服务端要自己上云、配 Nginx、管进程 | 第 5～6 周 docker-compose |

### 0.5.3 4 周压缩节奏（有 Android Java 经验适用）

| 压缩后 | 对应原计划 | 处理建议 |
|---|---|---|
| 第 1～3 天 | 第 0 天 + 第 1 周 | 环境搭建半天搞定；IoC 章节只精读"构造器注入 + `@ConfigurationProperties` + Profile"，Bean 生命周期回调扫一遍即可；**手写迷你 IoC 容器（Demo 3）建议照做**，一次搞懂 Hilt 背后到底是什么 |
| 第 4～10 天 | 第 2 周 | **全量学**，这是纯新领域（校验、全局异常、拦截器/过滤器） |
| 第 11～17 天 | 第 3 周 | **全量学 + 加时**，数据库与事务是最大短板，别赶进度 |
| 第 18～23 天 | 第 4 周 | 正常学；JWT 部分因你调过无数带 token 的接口，理解会很快 |
| 第 24～28 天 | 第 5～6 周 | 测试部分可只写 Service 单测 + 1 个 Testcontainers 集成测试；Docker 若从未接触过，额外留 1～2 天缓冲 |

> 每周的「推荐学习文档 / PDF + 实战 Demo」小节里都标注了 ⭐ 本周重点，压缩节奏下优先完成带 ⭐ 的条目。

---

## 1. 学习完成标准

完成本路线后，应能够：

- [ ] 用 Spring Initializr 创建工程，理解 Starter、自动装配（`@EnableAutoConfiguration`）与 `spring-boot-maven-plugin` 可执行 Jar 的原理。
- [ ] 熟练使用 IoC/DI（构造器注入、Bean 生命周期、`@ConfigurationProperties`）组织业务代码。
- [ ] 开发 RESTful API：参数校验（Validation）、统一响应体、全局异常处理、拦截器/过滤器。
- [ ] 完成数据库访问：Spring Data JPA 与 MyBatis(-Plus) 两种主流方案，掌握事务边界与连接池配置。
- [ ] 集成 Redis 缓存、Spring Security + JWT 认证鉴权。
- [ ] 使用 JUnit 5 + MockMvc + Testcontainers 编写单元测试与集成测试。
- [ ] 接入 Actuator + Micrometer + Prometheus/Grafana 实现可观测性，会用日志与 thread dump 定位线上问题。
- [ ] 用 Docker 打包部署，理解多环境配置（dev/test/prod Profile）与优雅停机。
- [ ] 独立完成一个"用户 + 订单 + 商品"三模块的实战项目并部署上线。

---

## 2. 先建立正确的技术模型

### 2.1 Spring 全家桶与 Spring Boot 的关系

```text
你的业务代码（Controller / Service / Repository）
             │
             ▼
Spring Boot ── Starter 依赖聚合 + 自动装配 + 内嵌容器 + Actuator
             │  （本质是"约定优于配置"的脚手架，不是新框架）
             ▼
Spring Framework ── IoC 容器 / AOP / MVC / TX / Resource 抽象
             │
             ▼
底层生态 ── Tomcat(内嵌) · Jackson · HikariCP · JPA/MyBatis · Redis · MQ ...
```

一句话：**Spring 是发动机，Spring Boot 是整车出厂配置**。Boot 不替代 Spring，它只是把"装配 XML/注解配置 + 打 War 丢容器"这一套繁琐流程自动化了。

### 2.2 一次请求在 Boot 应用中的流转

```text
HTTP 请求
  → 内嵌 Tomcat（Connector）
  → Filter 链（Spring Security、字符编码、自定义过滤器）
  → DispatcherServlet
  → HandlerInterceptor（preHandle）
  → 参数解析 + @Valid 校验
  → Controller 方法
  → Service（@Transactional 事务代理，AOP 织入）
  → Repository / Mapper（JPA EntityManager 或 MyBatis SqlSession）
  → 数据库（经 HikariCP 连接池）
  → 返回值经 HttpMessageConverter（Jackson）序列化为 JSON
  → 响应
```

### 2.3 核心概念速查

| 概念 | 作用 | 学习周 |
|---|---|---|
| IoC / DI | 容器管理对象创建与依赖注入，解耦的核心 | 第 1 周 |
| AOP | 切面织入：事务、日志、权限都靠它实现 | 第 2 周 |
| `@SpringBootApplication` | = `@Configuration` + `@EnableAutoConfiguration` + `@ComponentScan` | 第 1 周 |
| Starter | 依赖聚合 POM，如 `spring-boot-starter-web` | 第 1 周 |
| 自动装配 | 按 classpath 条件（`@ConditionalOnClass` 等）自动注册 Bean | 第 3 周 |
| `application.yml` / Profile | 外部化配置与多环境切换 | 第 1 周 |
| `@ConfigurationProperties` | 类型安全的配置绑定（优于散落的 `@Value`） | 第 2 周 |
| DispatcherServlet | MVC 前端控制器，所有请求入口 | 第 2 周 |
| Actuator | 生产级健康检查、指标、环境端点 | 第 5 周 |
| Spring Data JPA | ORM，Repository 接口免实现 | 第 3 周 |
| `@Transactional` | 声明式事务，基于 AOP 代理 | 第 3 周 |
| Spring Security | 认证 + 鉴权过滤器链 | 第 4 周 |
| Testcontainers | 用真实 Docker 中间件跑集成测试 | 第 5 周 |

### 2.4 关键工程原则

1. **依赖注入只用构造器注入**（配合 Lombok `@RequiredArgsConstructor`），不用字段注入 `@Autowired`——利于不可变性与单元测试。
2. **分层职责**：Controller 只做参数接收/校验/响应组装，不写业务；Service 承载业务与事务；Repository 只管数据访问。禁止跨层调用（Controller 直连 Repository）。
3. **事务加在 Service 公有方法上**，注意自调用失效问题（同类内部方法互调不走代理，事务不生效）。
4. **配置外部化**：数据库密码等敏感信息不进 Git，用环境变量或配置中心；多环境用 Profile 区分。
5. **统一异常与统一响应体**：用 `@RestControllerAdvice` 全局兜底，Controller 里不要 try-catch 吞异常。
6. **版本对齐**：所有 `spring-boot-starter-*` 版本由 parent/BOM 统一管理，不要手写版本号；引入第三方库优先看官方 compatibility 说明。

---

## 3. 总览：6 周学习路线

| 周次 | 主题 | 关键产出 |
|---|---|---|
| 第 0 天 | 环境搭建 + Hello World | JDK 21、Maven、IDEA 就绪；跑通第一个接口 |
| 第 1 周 | 工程结构与 IoC 核心 | 理解 Starter/自动装配；手写 IoC 小 Demo；多 Profile 配置 |
| 第 2 周 | Web 开发核心 | 完整 RESTful CRUD + 校验 + 全局异常 + 拦截器 |
| 第 3 周 | 数据访问 | JPA 与 MyBatis-Plus 双方案接入 MySQL；事务实战 |
| 第 4 周 | 安全与缓存 | Spring Security + JWT 登录鉴权；Redis 缓存三大问题处理 |
| 第 5 周 | 测试与可观测性 | 单测/集成测试覆盖；Actuator + Prometheus + Grafana 看板 |
| 第 6 周 | 部署与综合实战 | Docker 化部署；完成"商城迷你版"综合项目 |

---

## 4. 分周实战计划

### 4.0 第 0 天：环境与 Hello World

**环境清单**：

| 组件 | 版本建议 | 说明 |
|---|---|---|
| JDK | 21（LTS） | Spring Boot 3.x/4.x 最低要求 17；`brew install openjdk@21` |
| Maven | 3.9+ | IDEA 内置亦可；配置阿里云镜像加速 |
| IDE | IntelliJ IDEA | 装 Lombok 插件（2023+ 版本已内置支持） |
| Docker Desktop | 最新 | 第 3 周起用容器跑 MySQL/Redis |
| API 调试 | curl / IDEA HTTP Client / Postman | 任选其一 |

**创建工程**：访问 [start.spring.io](https://start.spring.io)，选择 Maven + Java 21 + Spring Boot 3.5.x，依赖勾选 `Spring Web`、`Lombok`。或直接用 IDEA 的 New Project → Spring Initializr。

**第一个接口**：

```java
@SpringBootApplication
public class DemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }
}

@RestController
@RequestMapping("/api/hello")
public class HelloController {
    @GetMapping
    public Map<String, Object> hello(@RequestParam(defaultValue = "world") String name) {
        return Map.of("message", "Hello, " + name, "time", LocalDateTime.now());
    }
}
```

启动后访问 `http://localhost:8080/api/hello?name=SpringBoot`。

**验收**：
- [ ] 能解释 `main` 方法为何能启动一个 Web 服务（内嵌 Tomcat）。
- [ ] `mvn package` 产出可执行 Jar，`java -jar target/xxx.jar` 能独立运行。
- [ ] 在 `application.yml` 里改 `server.port` 并生效。

**推荐学习文档 / PDF**：

| 资源 | 类型 | 说明 |
|---|---|---|
| [Getting Started](https://docs.spring.io/spring-boot/index.html) → "Getting Started" 章节 | 官方文档 | 15 分钟读完，建立工程骨架认知 |
| [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/) | 官方 Guide | ⭐ 跟着敲一遍，第一个可运行工程 |
| Spring Boot Reference PDF：文档站右上角 "Download PDF" | 官方 PDF | 建议下载存本地当**离线字典**（内容厚重，不要通读）；单章节 PDF 也可从每个 Reference 页面底部下载 |
| [Baeldung: Spring Boot 系列开篇](https://www.baeldung.com/spring-boot) | 图文教程 | 英文但代码密度高，遇到问题优先搜这个站 |
| [Spring Boot Reference Guide 中文翻译](https://github.com/qibaoguang/spring-boot-reference-guide) | 社区中文在线/PDF | 版本可能滞后于官方，术语以英文原文为准 |
| B 站「Spring Boot 3 入门到实战」（黑马程序员 / 尚硅谷） | 视频 | 只看第 1～3 集（环境 + 快速上手），其余按周需要再回看 |

**实战 Demo**：

1. Demo 0-1：`start.spring.io` 生成工程 → 跑通 `HelloController`（本节代码）。
2. Demo 0-2（Android 对照向）：用 `RestTemplate` 调用你自己写过的一个后端接口，体会"客户端"与"服务端"两端的对应关系。
3. 代码仓库：把每周 Demo 按 `week0/week1/...` 目录提交到同一个 Git 仓库，方便第 6 周复用。

> 本周重点 ⭐：Demo 0-1 跑通 + 官方 REST Guide 跟做一遍即可，不要在环境上纠结超过半天。

### 4.1 第 1 周：工程结构与 IoC 核心

**知识点**：

1. `@SpringBootApplication` 三合一注解的拆解；组件扫描范围（启动类所在包及子包）。
2. Bean 的注册方式：`@Component/@Service/@Repository/@Controller`、`@Bean` 方法、`@Import`。
3. 依赖注入三种方式对比，为什么推荐构造器注入；`@Primary`、`@Qualifier`、按条件装配 `@ConditionalOnProperty`。
4. Bean 作用域（singleton/prototype）与生命周期回调（`@PostConstruct`/`@PreDestroy`）。
5. `application.yml` 语法、Profile 多环境（`application-dev.yml` / `application-prod.yml`，`--spring.profiles.active=dev` 激活）。
6. 自动装配初探：启动日志加 `--debug` 查看 `CONDITIONS EVALUATION REPORT`。

**实战任务**：

- Demo 1：定义 `NotificationService` 接口 + `SmsNotificationService`/`EmailNotificationService` 两个实现，用 `@ConditionalOnProperty` 按配置项选择生效实现。
- Demo 2：写一个 `@ConfigurationProperties(prefix = "app")` 类绑定自定义配置（应用名、超时时间、白名单列表），并注入到 Controller 返回。
- Demo 3（原理向，选做）：不用 Spring，纯 Java 手写一个迷你 IoC 容器——扫描注解、反射创建实例、注入依赖，50 行以内即可，体会容器本质。

**验收**：
- [ ] 说出 `@Autowired` 字段注入的两个缺点。
- [ ] 打包后用 `java -jar app.jar --spring.profiles.active=prod` 切换配置成功。
- [ ] 能在 CONDITIONS REPORT 里找到一个因条件不满足而未装配的自动配置类。

**推荐学习文档 / PDF**：

| 资源 | 类型 | 说明 |
|---|---|---|
| [Spring Framework Core Technologies → IoC Container](https://docs.spring.io/spring-framework/reference/core/beans.html) | 官方文档 | ⭐ 只读 1.1～1.4 节（容器概念/Bean 定义/依赖注入），其余先跳过 |
| Boot Reference → "Externalized Configuration" 与 "Profiles" 章节 | 官方文档 | ⭐ 对照 Gradle flavors 理解 Profile，很快 |
| [Baeldung: Constructor Injection in Spring](https://www.baeldung.com/spring-injection) | 图文教程 | 三种注入方式对比与取舍 |
| [Baeldung: Guide to @ConfigurationProperties](https://www.baeldung.com/configuration-properties-in-spring-boot) | 图文教程 | 类型安全配置绑定的各种姿势 |
| 《Spring 实战（第 6 版）》第 1～2 章 | 书籍（有正版电子版；Manning 官网购书附赠无 DRM PDF） | 建立 IoC 全景；图书馆/微信读书也可 |
| [spring-petclinic](https://github.com/spring-projects/spring-petclinic) 源码 | 开源项目 | ⭐ 官方样例，看它的包结构与注入写法，当作"标准答案" |

**实战 Demo**（对应本节实战任务）：

> 代码已在本地工程 [`springboot-learning-demo/week1-ioc`](file:///Users/xy/workfile/springboot-learning-demo/week1-ioc) 实现并实跑验证，直接 `mvn -pl week1-ioc spring-boot:run` 即可；下述三个 Demo 均对应该模块里的具体包。

1. Demo 1-1：`@ConditionalOnProperty` 切换短信/邮件通知实现——见 `notify/` 包（`SmsNotificationService` / `EmailNotificationService`），用 `--spring.profiles.active=prod` 可观察到 `/api/config` 返回的实现类从 SMS 切成 Email。
2. Demo 1-2：`@ConfigurationProperties` 绑定自定义配置并在接口中返回——见 `config/AppProperties.java`。
3. Demo 1-3（⭐ Android 背景强烈推荐）：纯 Java 手写迷你 IoC 容器——见 `miniioc/MiniIocContainer.java`（含 `main`，不依赖 Spring 直接跑），用反射 + 注解自己实现一遍依赖递归注入与单例缓存，彻底打通"容器"这层窗户纸（做完可对照 [mini-spring 类项目](https://github.com/DerekYRC/mini-spring) 的思路）。

> 本周重点 ⭐：Demo 1-2 + Demo 1-3；IoC 文档只读指定小节，不要陷进 XML 时代的历史包袱。

### 4.2 第 2 周：Web 开发核心

**知识点**：

1. `@RestController` vs `@Controller` + `@ResponseBody`；`@GetMapping/@PostMapping/@PutMapping/@DeleteMapping` 与 RESTful 语义。
2. 参数绑定：`@PathVariable`、`@RequestParam`、`@RequestBody`、`@RequestHeader`。
3. 参数校验：`spring-boot-starter-validation`，`@NotBlank/@Size/@Min/@Email/@Pattern`，嵌套对象 `@Valid`，分组校验。
4. 统一响应体：自定义 `Result<T>{code, message, data}` 包装类。
5. 全局异常处理：`@RestControllerAdvice` + `@ExceptionHandler`，处理 `MethodArgumentNotValidException`、业务异常、兜底 `Exception`。
6. 拦截器 `HandlerInterceptor`（登录态、日志）与过滤器 `Filter`（跨域、编码）的区别与执行顺序。
7. Jackson 定制：日期格式、Long 转 String（防前端精度丢失）、`@JsonIgnore`。
8. 文件上传下载：`MultipartFile`。

**实战任务**：搭建"待办事项（Todo）"模块的完整 REST API（先用内存 `ConcurrentHashMap` 存储，第 3 周替换为数据库）：

```text
POST   /api/todos          创建（校验：标题非空、长度≤100）
GET    /api/todos          分页列表（page/size 参数）
GET    /api/todos/{id}     详情（不存在返回 404 语义的业务码）
PUT    /api/todos/{id}     更新
DELETE /api/todos/{id}     删除
```

要求：统一 `Result<T>` 响应、全局异常处理、一个记录请求耗时的拦截器。

**验收**：
- [ ] 非法参数请求返回结构化错误信息（哪个字段、什么原因），而不是 500 堆栈。
- [ ] 能画出 2.2 节的请求流转图并指出拦截器与过滤器的位置差异。
- [ ] 用 HTTP Client 脚本跑通全部 5 个接口。

**推荐学习文档 / PDF**：

| 资源 | 类型 | 说明 |
|---|---|---|
| Boot Reference → "Spring Web Applications"（Spring MVC 章） | 官方文档 | ⭐ 重点读 Controller、参数绑定、异常处理三节 |
| [Baeldung: REST API with Spring Boot 系列](https://www.baeldung.com/building-a-restful-web-service-with-spring-and-java-based-configuration) | 图文教程 | ⭐ 从建工程到分层结构的完整 walkthrough |
| [Baeldung: Error Handling for REST with Spring](https://www.baeldung.com/exception-handling-for-rest-with-spring) | 图文教程 | `@RestControllerAdvice` 的经典参考，直接照着搭全局异常 |
| Boot Reference → "Validation" 章节 | 官方文档 | 校验注解与失败处理 |
| [Spring 官方 Guide: Validating Form Input](https://spring.io/guides/gs/validating-form-input/) | 官方 Guide | 20 分钟跟做 |
| 《Spring 实战（第 6 版）》第 4 章 | 书籍 | Web 层全貌补充阅读 |

**实战 Demo**：

> 代码已在本地工程 [`springboot-learning-demo/week2-web`](file:///Users/xy/workfile/springboot-learning-demo/week2-web) 实现，含完整分层 + 单测 + 一份可逐条跑的 `todo-api-test.http`；`mvn -pl week2-web spring-boot:run` 即可。

1. Demo 2-1（⭐ 主线）：Todo 内存版 REST API 全套（本节实战任务），含统一 `Result<T>`（`common/Result.java`）+ 全局异常（`common/GlobalExceptionHandler.java`）+ 分页；已实测校验失败返回字段级结构化错误 `{title=标题不能为空}`。
2. Demo 2-2：自定义 `HandlerInterceptor` 打印每个请求的耗时与 traceId——见 `web/TraceInterceptor.java`（用 MDC，对标你在 Android 上给 OkHttp 加 Interceptor 打日志的经验，写法几乎一样）。
3. Demo 2-3：文件上传接口（头像上传场景），体验 `MultipartFile` 与静态资源映射（本地工程未含，作为你自己动手的扩展练习）。
4. 额外彩蛋：本地工程的 `Todo.createdAt` 故意演示了"`spring.jackson.date-format` 对 `LocalDateTime` 无效、需用 `@JsonFormat`"这个常见坑（对应第 7 节排查表）。

> 本周重点 ⭐：Demo 2-1 必须完整交付；全局异常处理直接参考 Baeldung 那篇搭骨架（Baeldung 文章对应的可运行代码在 [eugenp/tutorials](https://github.com/eugenp/tutorials)）。本周开始进入纯新领域，不建议压缩。

### 4.3 第 3 周：数据访问（JPA + MyBatis 双修）

> 📖 专项手册：环境检查、依赖与数据源配置、JPA / MyBatis-Plus 双版本 Todo 迁移、事务自调用失效复现、Flyway 建表、13 条坑表与 11 条资料清单的**操作配方**见 [《MySQL 接入 Spring Boot 实战手册》](file:///Users/xy/workfile/学习资料/MySQL接入SpringBoot实战手册.md)；本节只列知识点与验收，具体步骤以手册为准。

**知识点**：

1. Docker 起 MySQL：`docker run -d --name mysql -e MYSQL_ROOT_PASSWORD=root -p 3306:3306 mysql:8.4`。
2. Spring Data JPA：实体映射（`@Entity/@Table/@Id/@GeneratedValue/@Column`）、`JpaRepository` 方法名派生查询、`@Query` JPQL/原生 SQL、分页 `Pageable`、关联关系（一对多 `@OneToMany`、懒加载陷阱）。
3. MyBatis / MyBatis-Plus：`@Mapper` 与 XML 映射文件、`BaseMapper<T>` 通用 CRUD、`LambdaQueryWrapper` 条件构造器、分页插件。
4. 事务：`@Transactional` 传播行为（REQUIRED/REQUIRES_NEW）、只读事务、**自调用失效**、异常回滚规则（默认只回滚 RuntimeException，检查异常需 `rollbackFor = Exception.class`）。
5. HikariCP 连接池关键参数：`maximum-pool-size`、`connection-timeout`、`max-lifetime`。
6. 数据库演进工具：Flyway（`V1__init.sql` 版本化建表）。

**实战任务**：

- 把第 2 周的 Todo 模块从内存存储迁移到 MySQL，分别用 **JPA 版**和 **MyBatis-Plus 版**各实现一遍（两个分支对比体会差异）。
- 新增"用户—待办"一对多关系：一个用户有多个 Todo，联表查询用户及其 Todo 数量。
- 写一个转账式事务 Demo：两个表更新放在同一事务里，人为抛异常验证回滚；再演示一次自调用导致事务失效的场景。
- 用 Flyway 管理建表脚本。

**选型认知**（面试高频）：

| 维度 | Spring Data JPA | MyBatis-Plus |
|---|---|---|
| 定位 | ORM，面向对象操作 | SQL 增强，面向 SQL 操作 |
| 复杂 SQL | 弱（需 `@Query` 原生） | 强（天然手写 SQL） |
| 开发效率 | 简单 CRUD 极高 | 简单 CRUD 高，复杂查询更可控 |
| 国内生态 | 相对少 | 主流 |

**验收**：
- [ ] 两个版本的 Todo API 全部通过第 2 周的测试脚本。
- [ ] 能解释为什么 `@Transactional` 加在 private 方法上无效。
- [ ] Flyway 脚本能在全新 MySQL 容器上一键重建表结构。

**推荐学习文档 / PDF**：

| 资源 | 类型 | 说明 |
|---|---|---|
| [Spring Data JPA Reference](https://docs.spring.io/spring-data/jpa/reference/jpa.html) | 官方文档 | ⭐ 重点：Repository 方法名派生查询、`@Query`、分页；你有 Room 底子，读起来很快 |
| [Spring 官方 Guide: Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/) | 官方 Guide | ⭐ 30 分钟跟做，建立第一印象 |
| [MyBatis-Plus 官方文档（中文）](https://baomidou.com) | 官方文档 | ⭐ 中文、示例全；读 CRUD 接口与 Wrapper 两章即可 |
| Boot Reference → "Data → SQL Data Access" 章节 | 官方文档 | HikariCP 参数与多数据源配置 |
| [Baeldung: Transactions with Spring](https://www.baeldung.com/transaction-configuration-with-jpa-and-spring) | 图文教程 | 事务配置基础 |
| [Baeldung: Spring @Transactional Self-Invocation（自调用失效）](https://www.baeldung.com/spring-self-invocation) | 图文教程 | ⭐ 面试与生产双重高频坑，必读 |
| [Flyway 官方文档](https://documentation.red-gate.com/flyway) | 官方文档 | 只看 Getting Started，10 分钟 |
| [spring-petclinic](https://github.com/spring-projects/spring-petclinic) 的 JPA 分支 | 开源项目 | 看官方怎么写实体与 Repository |

**实战 Demo**：

1. Demo 3-1（⭐ 主线）：Todo 持久化双版本（JPA 分支 + MyBatis-Plus 分支），两个 Git 分支对比。
2. Demo 3-2：转账事务 Demo + 自调用失效复现（故意写出 bug 再修，比只读文档记得牢）。
3. Demo 3-3：Flyway 版本化建表脚本，在全新 MySQL 容器上一键重建。
4. Demo 3-4（选做，为第 6 周铺垫）：给"扣库存"加乐观锁（`@Version`），用 JMeter 小并发验证。

> 本周重点 ⭐：Demo 3-1 与 3-2；本周是你最大短板（数据库建模 + 事务），建议不压缩、适当加时。

### 4.4 第 4 周：安全与缓存

**知识点（Security + JWT）**：

1. Spring Security 过滤器链模型；`SecurityFilterChain` Bean 配置（6.x 已废弃 `WebSecurityConfigurerAdapter`，一律用组件式配置）。
2. 认证（Authentication）与鉴权（Authorization）：`UserDetailsService`、`PasswordEncoder`（BCrypt）、`@PreAuthorize` 方法级权限。
3. JWT 无状态登录：登录接口签发 token → 自定义 `OncePerRequestFilter` 解析 token 写入 `SecurityContext` → `SessionCreationPolicy.STATELESS`。
4. RBAC 模型：用户—角色—权限三表设计。

**知识点（Redis）**：

1. Docker 起 Redis：`docker run -d --name redis -p 6379:6379 redis:7.4`。
2. `RedisTemplate` 与 `StringRedisTemplate`；序列化配置（key 用 String、value 用 Jackson，避免默认 JDK 序列化的乱码）。
3. 注解式缓存：`@EnableCaching` + `@Cacheable/@CachePut/@CacheEvict`。
4. 缓存三大问题：**穿透**（查不存在的 key → 缓存空值 / 布隆过滤器）、**击穿**（热点 key 过期瞬间 → 互斥锁 / 逻辑过期）、**雪崩**（大批 key 同时过期 → 过期时间加随机值）。
5. 分布式锁入门：`SET key value NX PX`；了解 Redisson。

**实战任务**：

- 给 Todo 项目加登录注册：`POST /api/auth/register`、`POST /api/auth/login` 返回 JWT；其余接口需携带 `Authorization: Bearer xxx`；Todo 数据按当前登录用户隔离（只能看/改自己的）。
- 加角色：ADMIN 可访问 `GET /api/admin/todos`（查所有用户的 Todo），普通用户 403。
- 给"Todo 详情"接口加 Redis 缓存：先 `@Cacheable` 注解版，再手写一次"查缓存 → miss → 查库 → 回填"版本，理解注解背后逻辑；更新/删除时正确驱逐缓存。

**验收**：
- [ ] 无 token / 过期 token / 越权访问三种场景返回正确的 401/403。
- [ ] `redis-cli MONITOR` 能观察到缓存命中与驱逐。
- [ ] 能口述缓存穿透、击穿、雪崩的区别与对策。

**推荐学习文档 / PDF**：

| 资源 | 类型 | 说明 |
|---|---|---|
| [Spring Security Reference → Servlet Architecture](https://docs.spring.io/spring-security/reference/servlet/architecture.html) | 官方文档 | ⭐ 只读过滤器链架构一节，先建心智模型再碰配置 |
| [Spring 官方 Guide: Securing a Web Application](https://spring.io/guides/gs/securing-web/) | 官方 Guide | 30 分钟跟做 |
| [Baeldung: Spring Security 6 系列（JWT 篇）](https://www.baeldung.com/spring-security-6-jwt) | 图文教程 | ⭐ 手写 JWT 登录的主流参考 |
| [Baeldung: Spring Boot 3 OAuth2 Resource Server](https://www.baeldung.com/spring-boot-3-oauth2-resource-server) | 图文教程 | 进阶写法：用官方 `oauth2-resource-server` 替代手写过滤器，更接近生产 |
| Boot Reference → "Caching" 章节 | 官方文档 | ⭐ `@Cacheable/@CacheEvict` 注解缓存 |
| [Redis 官方文档](https://redis.io/docs/latest/) | 官方文档 | 当字典查命令语义；不必通读 |
| B 站「Redis 实战篇」（黑马） | 视频 | 缓存穿透/击穿/雪崩的动画讲解很直观，只看这三集 |

**实战 Demo**：

1. Demo 4-1（⭐ 主线）：Todo 项目登录注册 + JWT 全链路（本节实战任务）。可直接对照 [szerhusenBC/jwt-spring-security-demo](https://github.com/szerhusenBC/jwt-spring-security-demo)（Spring Security + JWT 无状态登录的最小完整示例，已核实存活）。
2. Demo 4-2：手写 `OncePerRequestFilter` 解析 JWT 写入 `SecurityContext`，写完再对照官方 Resource Server 方案重构一遍，体会"造轮子 vs 用轮子"。
3. Demo 4-3：RBAC 三表（用户—角色—权限）+ `@PreAuthorize` 方法级权限。
4. Demo 4-4：商品详情缓存——注解版与手写版各一遍，用 `redis-cli MONITOR` 观察命中/驱逐。

> 本周重点 ⭐：Demo 4-1 与 4-4；Security 文档晦涩，先看架构一节 + Baeldung JWT 篇跑通，再回头补细节。

### 4.5 第 5 周：测试与可观测性

**知识点（测试）**：

1. JUnit 5：`@Test/@BeforeEach/@ParameterizedTest`、AssertJ 断言。
2. `@SpringBootTest` 全量上下文 vs `@WebMvcTest` 只测 Controller 层（配 `MockMvc`）vs `@DataJpaTest`（内嵌库测 Repository）。
3. Mockito：`@MockBean`/`@Mock` 隔离 Service 依赖。
4. Testcontainers：集成测试时自动拉起真实 MySQL/Redis 容器（`@Testcontainers` + `@Container` + `@ServiceConnection`），替代 H2 假库。
5. 测试金字塔观念：单测多、集成测试适量、端到端少量。

**知识点（可观测性）**：

1. Actuator 端点：`/actuator/health`、`/actuator/metrics`、`/actuator/env`、`/actuator/threaddump`；生产环境端点暴露收敛与鉴权。
2. 日志：Logback 配置（`logging.pattern`、按环境分级、滚动策略）；MDC 注入 traceId 实现链路追踪入门。
3. Micrometer + Prometheus：`management.endpoints.web.exposure.include=prometheus`，Grafana 导入现成看板（ID 4701 或 12900）。
4. 优雅停机：`server.shutdown=graceful`。
5. 慢接口定位：拦截器打耗时日志 → metrics 打点 → Prometheus 查询 P99。

**实战任务**：

- 为 Todo 项目补齐测试：Service 层单测（Mockito 隔离 Repository）、Controller 层 `@WebMvcTest` + MockMvc（覆盖校验失败分支）、一个 Testcontainers 集成测试（真实 MySQL 走通"注册→登录→建 Todo→查询"全流程）。目标核心 Service 行覆盖率 ≥ 70%。
- 接入 Prometheus + Grafana：docker-compose 一键起 mysql + redis + prometheus + grafana + app 五个服务，看板能看到 JVM 内存、HTTP QPS 与 P95 耗时。

**验收**：
- [ ] `mvn test` 全绿；能说清 `@SpringBootTest` 与 `@WebMvcTest` 的启动范围差异。
- [ ] Grafana 看板上人为压测（`ab` 或 JMeter）能看到 QPS 曲线变化。
- [ ] `/actuator/health` 在 MySQL 容器停掉后变为 DOWN（健康指示器自动感知）。

**推荐学习文档 / PDF**：

| 资源 | 类型 | 说明 |
|---|---|---|
| Boot Reference → "Testing" 章节 | 官方文档 | ⭐ 重点：测试切片（`@WebMvcTest`/`@DataJpaTest`）与 `@SpringBootTest` 的区别 |
| [Baeldung: Testing in Spring Boot](https://www.baeldung.com/spring-boot-testing) | 图文教程 | 单测/切片测试/集成测试的分层写法 |
| [Baeldung: Testing REST API with MockMvc](https://www.baeldung.com/spring-boot-mockmvc) | 图文教程 | Controller 层测试标配 |
| [Testcontainers 官方文档](https://java.testcontainers.org) | 官方文档 | ⭐ 读 Modules → MySQL/Redis 两页即可上手 |
| Boot Reference → "Actuator" 章节 | 官方文档 | 端点清单与生产环境收敛策略 |
| [Micrometer 官方文档](https://micrometer.io/docs) | 官方文档 | 指标打点基础；Prometheus 一节 |
| [Prometheus 官方 Getting Started](https://prometheus.io/docs/introduction/first_steps/) | 官方文档 | 只需跑通抓取（scrape）+ 一条 PromQL |
| Grafana 看板 ID 4701 / 12900 | 现成资源 | 导入即用，不要自己从零搭看板 |

**实战 Demo**：

1. Demo 5-1（⭐ 主线）：Todo 三层测试补齐（Service 单测 + `@WebMvcTest` + Testcontainers 集成测试）。
2. Demo 5-2（⭐ 主线）：docker-compose 一键起 mysql + redis + prometheus + grafana + app，Grafana 看板看 JVM/QPS/P95。
3. Demo 5-3：MDC traceId 全链路透传（拦截器入口生成 → 日志 pattern 输出），对标你在 Android 上给请求加 EagleEye-TraceId 的经验。
4. Demo 5-4（选做）：用 `ab -n 1000 -c 50` 压测，在 Grafana 上观察 P99 拐点，再用 `/actuator/threaddump` 看线程堆栈。

> 本周重点 ⭐：Demo 5-1 与 5-2；压缩节奏下 5-3/5-4 可合并到第 6 周做。

### 4.6 第 6 周：部署与综合实战

**知识点（部署）**：

1. Dockerfile 多阶段构建（maven 构建层 + JRE 运行层）；分层 Jar（`layertools`）优化镜像缓存。
2. docker-compose 编排完整应用栈；环境变量注入配置（`SPRING_DATASOURCE_URL` 覆盖 yml）。
3. 部署到云主机：安全组、Nginx 反向代理 + HTTPS（certbot）。
4. 了解进阶方向（不必本周掌握）：K8s、Spring Cloud（注册中心/网关/配置中心）、消息队列（RocketMQ/Kafka）、分库分表。

**综合实战项目：商城迷你版（mini-mall）**

需求清单（覆盖前 5 周全部技能点）：

| 模块 | 功能 | 技术点 |
|---|---|---|
| 用户 | 注册/登录/JWT/RBAC | Security、Validation |
| 商品 | CRUD、分类、库存 | JPA 或 MP、Flyway |
| 订单 | 下单（扣库存+建订单同事务）、取消、分页查询 | @Transactional、乐观锁防超卖 |
| 缓存 | 商品详情缓存、首页热点数据 | Redis、缓存三大问题 |
| 运维 | 健康检查、指标看板、结构化日志 | Actuator、Prometheus |
| 质量 | 核心链路测试覆盖 | JUnit5、Testcontainers |
| 部署 | docker-compose 一键起全栈 | Dockerfile、Nginx |

**加分项（选做）**：接入 RabbitMQ/Kafka 做"下单成功后异步发通知"；用 OpenFeign/WebClient 调用一个外部公开 API；引入 SpringDoc（OpenAPI 3）自动生成接口文档。

**开源项目参考（写 mini-mall 时照着抄结构，不要从零发明）**：

| 项目 | 地址 | 参考什么 |
|---|---|---|
| mall（macrozheng） | [github.com/macrozheng/mall](https://github.com/macrozheng/mall) | 国内最完整的电商开源项目（Spring Boot + MyBatis + Redis + Security），参考模块划分与业务建模，不要全量读 |
| jeecg-boot | [github.com/jeecgboot/JeecgBoot](https://github.com/jeecgboot/JeecgBoot) | 低代码平台，参考 RBAC 表设计与通用 CRUD 封装 |
| spring-petclinic | [github.com/spring-projects/spring-petclinic](https://github.com/spring-projects/spring-petclinic) | 官方样例，分层结构与命名规范的"标准答案" |
| SpringDoc 示例 | [springdoc.org](https://springdoc.org) | 一个依赖接入 OpenAPI 3 接口文档 |

**验收**：
- [ ] 项目推到 Git 仓库，README 含架构图、启动步骤、接口文档地址。
- [ ] 在干净环境 `docker compose up -d` 一键可用。
- [ ] 下单接口并发压测 50 并发不出现超卖（乐观锁/分布式锁生效）。

**推荐学习文档 / PDF**：

| 资源 | 类型 | 说明 |
|---|---|---|
| Boot Reference → "Container Images"（Docker）章节 | 官方文档 | ⭐ 官方 Dockerfile 写法与 Buildpacks 方案 |
| Boot Reference → "Creating Executable Jars" + 分层 Jar（`layertools`） | 官方文档 | 镜像构建缓存优化，看一遍即可 |
| [Docker 官方 Getting Started](https://docs.docker.com/get-started/) | 官方文档 | ⭐ 若从未用过 Docker，花半天过一遍；compose 一节必读 |
| [Docker — 从入门到实践（开源中文电子书）](https://yeasy.gitbook.io/docker_practice/) | 中文 PDF/在线 | 可下载 PDF 离线读；只看基础 + compose 章节 |
| [Spring Cloud 官方文档](https://spring.io/projects/spring-cloud) | 官方文档 | 仅作进阶方向地图浏览，本周不深入 |
| [Spring Boot 4.0 Migration Guide](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-4.0-Migration-Guide) | 官方 Wiki | 结业后过渡到 Boot 4.x 时对照检查 |

**实战 Demo**：

1. Demo 6-1（⭐ 主线）：mini-mall 综合项目（本节需求清单），前 5 周所有 Demo 的集大成。
2. Demo 6-2：多阶段构建 Dockerfile + `docker compose up -d` 一键起全栈（app + mysql + redis + nginx）。
3. Demo 6-3：Nginx 反向代理 + certbot 免费 HTTPS，部署到一台云主机（学生机/轻量应用服务器即可），用手机访问自己的域名——对 Android 开发者来说，这是第一次"自己写的接口自己在 App 外也能调通"，成就感拉满。

> 本周重点 ⭐：Demo 6-1～6-3 全部完成；mini-mall 直接作为简历项目打磨（README 架构图 + 接口文档 + 压测报告）。

---

## 5. 学习资源清单

### 5.1 通用资源（全程使用）

| 类型 | 资源 | 说明 |
|---|---|---|
| 官方文档 | [docs.spring.io/spring-boot](https://docs.spring.io/spring-boot/index.html) | 第一权威；Guide 区有大量 15 分钟小任务；右上角可下载全量 Reference PDF 当离线字典 |
| 官方指南 | [spring.io/guides](https://spring.io/guides) | 按主题（REST、Security、Messaging）逐个跟做 |
| 脚手架 | [start.spring.io](https://start.spring.io) | 工程初始化 |
| 书籍 | 《Spring Boot 实战》《Spring 实战（第 6 版）》 | 建立体系；注意版本差异以官方文档为准 |
| 电子书/PDF | 《Docker — 从入门到实践》（[yeasy.gitbook.io/docker_practice](https://yeasy.gitbook.io/docker_practice/)） | 开源免费、可下载 PDF；第 5～6 周配套 |
| 电子书/PDF | Manning 官网购书附赠无 DRM PDF（《Spring in Action 6th》等） | 正版渠道；只建议为常翻的书付费 |
| 视频 | B 站搜"Spring Boot 3 黑马/尚硅谷" | 国内生态（MyBatis-Plus、Redis）覆盖较好 |
| 源码 | GitHub `spring-projects/spring-boot` | 第 3 周后读 `spring-boot-autoconfigure` 模块 |
| 开源代码 | [eugenp/tutorials](https://github.com/eugenp/tutorials) | Baeldung 全站文章对应的可运行代码；网页偶尔报 403/限流时，直接来这个仓库找对应主题的模块 |
| 开源代码 | [szerhusenBC/jwt-spring-security-demo](https://github.com/szerhusenBC/jwt-spring-security-demo) | 第 4 周 Security + JWT 无状态登录的最小完整示例 |
| 本地代码 | [`springboot-learning-demo/`](file:///Users/xy/workfile/springboot-learning-demo) | 本教程第 1～2 周配套可运行工程（已编译 + 实跑验证） |
| 社区 | spring.io/blog、Baeldung.com | Baeldung 的 how-to 文章质量极高，遇具体问题优先搜它 |
| 练手 | 每周实战任务 + 第 6 周综合项目 | 以写代码为主，视频为辅（建议视频:动手 = 3:7） |

### 5.2 各周专属资源索引

每周的「推荐学习文档 / PDF + 实战 Demo」小节已就近给出当周资源，汇总入口：

- 第 0 天：官方 Getting Started + REST Guide + Reference PDF（§4.0）
- 第 1 周：Spring Framework IoC 文档 + spring-petclinic + 手写迷你 IoC（§4.1）
- 第 2 周：MVC 章 + Baeldung REST/异常处理两篇（§4.2）
- 第 3 周：Spring Data JPA Reference + MyBatis-Plus 中文文档 + 事务自调用失效篇（§4.3）
- 第 4 周：Security 架构节 + Baeldung JWT 篇 + Boot Caching 章（§4.4）
- 第 5 周：Boot Testing/Actuator 章 + Testcontainers + Micrometer/Prometheus（§4.5）
- 第 6 周：Container Images 章 + Docker 中文电子书 + mall/jeecg-boot 参考（§4.6）

> 链接说明：以上均为官方文档或长期维护的知名教程站（spring.io Guides、baomidou、Testcontainers）；Baeldung 网页对自动化脚本偶尔返回 403（反爬），浏览器手动访问正常，若网页打不开就直接看其官方代码仓库 [eugenp/tutorials](https://github.com/eugenp/tutorials)；其他社区链接若失效，用标题关键词搜索即可找到替代。本文所有外链已于 2026-11 逐条核实存活。

---

## 6. 总验收清单（结业自测）

**原理层**：
- [ ] 白板画出 Boot 启动流程：`SpringApplication.run` → 环境准备 → 容器创建 → 自动装配 → 内嵌 Tomcat 启动。
- [ ] 解释 Starter 与自动装配如何配合实现"引入依赖即生效"。
- [ ] 解释 AOP 代理（JDK 动态代理 vs CGLIB）与事务/缓存注解失效的常见场景。

**编码层**：
- [ ] 30 分钟内从零搭出一个含"校验 + 统一响应 + 全局异常 + JPA CRUD"的骨架工程。
- [ ] 独立完成 JWT 登录鉴权全流程配置。
- [ ] 为一个业务方法正确设置事务边界并验证回滚。

**工程层**：
- [ ] 综合项目 mini-mall 完成全部验收项。
- [ ] 能用 Actuator + 日志 + thread dump 定位一次人为制造的"接口变慢"问题。
- [ ] 能写出多阶段构建的生产级 Dockerfile。

---

## 7. 常见坑排查表

| 现象 | 根因 | 解决 |
|---|---|---|
| 启动报 `Port 8080 was already in use` | 端口被占 | `lsof -i :8080` 找到进程 kill，或改 `server.port` |
| `@Transactional` 不回滚 | ①方法非 public ②同类自调用 ③抛的是检查异常 | 改公有方法；拆类或注入自身代理；`rollbackFor = Exception.class` |
| 注入的 Bean 报 `NoSuchBeanDefinitionException` | 类不在启动类包扫描范围内，或没加注解 | 调整包结构，或 `@ComponentScan` 显式指定 |
| 字段注入拿到 null | 对象是自己 `new` 出来的，不受容器管理 | 交给容器管理，或改用 `ApplicationContext.getBean` |
| 前端收到的 Long 精度丢失 | JS Number 精度上限 2^53 | Jackson 全局配置 Long → String 序列化 |
| 日期返回成时间戳/格式乱 | Jackson 默认行为 | `spring.jackson.date-format` + `time-zone: GMT+8`，或字段 `@JsonFormat` |
| 校验注解不生效 | 忘加 `spring-boot-starter-validation`，或参数没写 `@Valid` | 补依赖、补注解 |
| JPA 查关联对象报 `LazyInitializationException` | 事务外访问懒加载属性 | `JOIN FETCH` 查询，或在事务边界内组装 DTO |
| Redis 存的中文变 `\xac\xed\x00\x05...` | 默认 JDK 序列化 | RedisTemplate 配置 StringRedisSerializer + GenericJackson2JsonRedisSerializer |
| Security 配置后所有接口 403 | 忘了放行，或 CSRF 拦截了 POST | `authorizeHttpRequests` 放行公开路径；无状态 API `csrf(csrf -> csrf.disable())` |
| `mvn test` 起不来，连不上数据库 | 集成测试试图连真实中间件 | 用 Testcontainers，或 `@ActiveProfiles("test")` + H2 |
| 打成 Jar 后静态资源/配置文件找不到 | 用 `File` 路径读 classpath 资源 | 改用 `ClassPathResource` / `getResourceAsStream` |
| Boot 3 下 `javax.*` 导入报错 | Boot 3 起迁移到 Jakarta EE 9+ | 全局替换 `javax.servlet` → `jakarta.servlet` 等 |
| 升级到 Boot 4 后部分依赖不兼容 | Spring Framework 7 / Jakarta 基线变化 | 对照官方 [Migration Guide](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-4.0-Migration-Guide)，先用 `spring-boot-properties-migrator` 排查废弃配置 |

---

> 学习建议：每周先花 30% 时间过知识点，70% 时间敲实战任务；所有 Demo 代码建 Git 仓库按周提交，第 6 周的 mini-mall 直接作为简历项目打磨。
