# Android Binder 机制源码阅读路线

> 适用版本:Android 13/14(路径以 AOSP main 分支为准,不同版本略有差异)
> 预计周期:3 周(每天 2-3 小时)
> 配套文档:《AOSP Framework核心机制阶段学习计划.md》模块一

---

## 一、学习目标

读完本路线后,你应当能够:

1. 脱稿画出一次 Binder 跨进程调用的完整链路(Java → JNI → Native → 内核驱动)
2. 讲清楚"一次拷贝"的原理与 mmap 在其中的作用
3. 解释 Binder 线程池、死亡通知、引用计数三大机制
4. 手写 AIDL 服务并能逐层追踪到驱动

---

## 二、前置知识清单

开始前请确认已掌握:

- [ ] Linux IPC 基础:管道、Socket、共享内存、信号量,各自的优劣
- [ ] mmap 系统调用:虚拟内存与物理内存的映射关系
- [ ] Linux 字符设备驱动模型:`open / ioctl / mmap` 的作用
- [ ] Java 动态代理与反射
- [ ] C++ 基础:智能指针(sp/wp)、虚函数表

---

## 三、Binder 整体架构

```
┌─────────────────────────── 用户空间 ───────────────────────────┐
│  Client 进程                          Server 进程              │
│  ┌──────────────┐                    ┌──────────────┐         │
│  │ Stub.Proxy   │                    │ Stub (Bn)    │         │
│  │ BinderProxy  │                    │ Binder       │  Java层 │
│  ├──────────────┤                    ├──────────────┤         │
│  │android_util_ │                    │android_util_ │  JNI层  │
│  │Binder.cpp    │                    │Binder.cpp    │         │
│  ├──────────────┤   ServiceManager   ├──────────────┤         │
│  │ BpBinder     │◄────(句柄0,上下文  │ BBinder      │ Native  │
│  │IPCThreadState│     管理者)        │IPCThreadState│  层     │
│  │ ProcessState │                    │ ProcessState │         │
│  └──────┬───────┘                    └──────▲───────┘         │
│         │ open("/dev/binder") + mmap        │                 │
├─────────┼───────────────────────────────────┼─────────────────┤
│ 内核空间 ▼                                   │                 │
│              Binder Driver (binder.c)                          │
│         binder_transaction / binder_thread_read                │
└────────────────────────────────────────────────────────────────┘
```

**角色速记**:
- `BinderProxy`(Java)/ `BpBinder`(Native):Client 侧的代理
- `Binder`(Java)/ `BBinder`(Native):Server 侧的实体
- `IPCThreadState`:每个线程一个,负责与驱动 ioctl 对话
- `ProcessState`:每个进程一个,负责打开 binder 设备、mmap
- `ServiceManager`:特殊的 Server,句柄固定为 0,是服务注册中心

---

## 四、阅读总路线:自顶向下五层

| 层 | 代码位置 | 阅读深度 |
|----|---------|---------|
| L0 使用层 | AIDL 生成代码 | 精读(1 天) |
| L1 Java Framework 层 | frameworks/base/core/java/android/os/ | 精读(4 天) |
| L2 JNI 层 | frameworks/base/core/jni/ | 通读(2 天) |
| L3 Native libbinder | frameworks/native/libs/binder/ | 精读(5 天) |
| L4 内核驱动 | kernel/common/drivers/android/binder.c | 抓主线(3 天) |

---

## 五、L0 使用层:从 AIDL 生成代码入手(第 1 天)

### 5.1 动手写一个 AIDL

```aidl
// IDemoService.aidl
interface IDemoService {
    String sayHello(String name);
}
```

### 5.2 精读编译生成的 `IDemoService.java`

重点看三个内部结构:

```java
public interface IDemoService extends IInterface {
    // Server 侧实体:继承 Binder,业务代码写在这里
    public static abstract class Stub extends Binder implements IDemoService {
        public static IDemoService asInterface(IBinder obj) { ... }  // 关键入口
        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) { ... }
    }
    // Client 侧代理:持有 mRemote(BinderProxy),真正发起跨进程调用
    private static class Proxy implements IDemoService {
        public String sayHello(String name) {
            Parcel _data = Parcel.obtain();
            mRemote.transact(TRANSACTION_sayHello, _data, _reply, 0);  // 核心调用
            ...
        }
    }
}
```

### 5.3 必须想明白的问题

- `asInterface()` 做了什么?同进程与跨进程返回的对象有何不同?
  → `queryLocalInterface()` 查本地,查不到则包装成 `Proxy`
- `transact()` 的参数:code 是什么?data/reply 两个 Parcel 的角色?
- `FLAG_ONEWAY` 单向调用的语义?

---

## 六、L1 Java Framework 层(第 2-5 天)

### 6.1 阅读清单

```
frameworks/base/core/java/android/os/IBinder.java            ← Binder 接口定义
frameworks/base/core/java/android/os/Binder.java             ← Server 实体 + execTransact
frameworks/base/core/java/android/os/BinderProxy.java        ← Client 代理(Android 13+ 独立文件;
                                                               ←   旧版本是 Binder.java 内部类)
frameworks/base/core/java/android/os/Parcel.java             ← 数据序列化
frameworks/base/core/java/android/os/ServiceManager.java     ← 服务注册/查询入口
frameworks/base/core/java/android/os/IServiceManager.java    ← ServiceManager 的 AIDL
frameworks/base/core/java/com/android/internal/os/BinderInternal.java
```

### 6.2 跟读链路 1:服务注册 addService()

```
ServiceManager.addService(name, binder)
  → getIServiceManager().addService(...)
    // ServiceManager 自己的 BinderProxy 是怎么来的?
  → ServiceManager.getIServiceManager()
    → BinderInternal.getContextObject()        ← native,拿到句柄 0 的 BpBinder
    → BinderProxy 包装                          ← javaObjectForIBinder(JNI 中)
```

**关键点**:ServiceManager 是所有服务的"0 号服务",它的 BinderProxy 是原生构造的,
不需要先 getService —— 否则就成了"先有鸡还是先有蛋"的问题。

### 6.3 跟读链路 2:Client 发起调用 transact()

```
Proxy.sayHello()
  → BinderProxy.transact(code, data, reply, flags)
    → transactNative(...)                       ← native 方法,进入 JNI 层
```

### 6.4 跟读链路 3:Server 接收调用 execTransact()

```
Binder.execTransact(code, dataObj, replyObj, flags)   ← 由 JNI 层回调上来
  → onTransact(code, data, reply, flags)
    → Stub 子类的业务方法
```

### 6.5 Parcel 重点

- `writeStrongBinder()` / `readStrongBinder()`:Binder 对象如何被打包进数据流
  → 内部转成 `flat_binder_object`,驱动层会把它翻译成 handle 或实体
- Parcel 池:`obtain()` 复用机制

---

## 七、L2 JNI 层(第 6-7 天)

### 7.1 阅读清单

```
frameworks/base/core/jni/android_util_Binder.cpp   ← 核心
frameworks/base/core/jni/android_os_Parcel.cpp
```

### 7.2 关键函数与对应关系

| Java 方法 | JNI 实现 | 作用 |
|-----------|---------|------|
| `BinderProxy.transactNative` | `android_os_BinderProxy_transact` | 取 BpBinder 调 transact |
| `BinderInternal.getContextObject` | `android_os_BinderInternal_getContextObject` | `ProcessState::getContextObject(NULL)` |
| `Binder.getCallingPid/Uid` | 直接读 `IPCThreadState` | 同步读取,无需进驱动 |
| `Binder.execTransact`(回调) | `onTransact` → `JavaBBinder::onTransact` | 回调 Java 层 |

### 7.3 两个桥梁类(重点)

```cpp
// android_util_Binder.cpp

// Java BinderProxy 与 Native BpBinder 的桥:
//   BpBinder 创建后,通过 javaObjectForIBinder() 创建/复用 Java 层 BinderProxy
static jobject javaObjectForIBinder(JNIEnv* env, const sp<IBinder>& val);

// Java Binder 与 Native 层的桥:
//   JavaBBinder 继承 BBinder,其 onTransact() 回调 Java Binder.execTransact()
class JavaBBinder : public BBinder { ... };
```

**记忆模型**:Java 层对象本身不跨进程,真正跨进程的是 Native 的 BpBinder/BBinder;
Java 对象只是它们的"外壳"。对象关联通过 JNI 全局引用 + `gBinderOffsets.mObject` 字段完成。

---

## 八、L3 Native libbinder 层(第 8-12 天,本路线核心)

### 8.1 阅读清单

```
frameworks/native/libs/binder/IInterface.cpp          ← interface_cast / asBinder
frameworks/native/libs/binder/BpBinder.cpp            ← Client 代理
frameworks/native/libs/binder/Binder.cpp              ← Server 实体(BBinder)
frameworks/native/libs/binder/ProcessState.cpp        ← 进程级:打开设备、mmap、线程池启动
frameworks/native/libs/binder/IPCThreadState.cpp      ← 线程级:transact、talkWithDriver、读写循环
frameworks/native/libs/binder/Parcel.cpp              ← flat_binder_object 读写
frameworks/native/libs/binder/IServiceManager.cpp
frameworks/native/cmds/servicemanager/main.cpp        ← servicemanager 进程入口
frameworks/native/cmds/servicemanager/ServiceManager.cpp
frameworks/native/libs/binder/include/binder/*.h      ← 头文件对照
```

### 8.2 ProcessState:进程单例初始化

```cpp
// ProcessState.cpp
ProcessState::ProcessState(const char* driver) {
    mDriverFD = open_driver(driver);          // open("/dev/binder")
    mVMStart = mmap(nullptr, BINDER_VM_SIZE,  // 映射 ~1M-8K 接收缓冲区
                    PROT_READ, MAP_PRIVATE|MAP_NORESERVE, mDriverFD, 0);
}
```

**要点**:
- 每个进程只 open 一次 binder 设备
- `BINDER_VM_SIZE = 1MB - 4KB*2`,这就是 **Binder 单次传输不能超过约 1M** 的由来
- `startThreadPool()` + `spawnPooledThread(true)` 启动 Binder 主线程

### 8.3 IPCThreadState:与驱动对话的核心

跟读主链路(Client 侧):

```cpp
// IPCThreadState.cpp
status_t IPCThreadState::transact(int32_t handle, uint32_t code,
                                  const Parcel& data, Parcel* reply, uint32_t flags) {
    err = writeTransactionData(BC_TRANSACTION, flags, handle, code, data, nullptr);
    err = waitForResponse(reply);              // 等待驱动回包
}

status_t IPCThreadState::waitForResponse(Parcel* reply, status_t* acquireResult) {
    talkWithDriver();                          // ioctl(BINDER_WRITE_READ)
    // 循环处理 BR_TRANSACTION_COMPLETE / BR_REPLY / BR_DEAD_REPLY ...
}
```

跟读主链路(Server 侧):

```cpp
void IPCThreadState::joinThreadPool(bool isMain) {
    mOut.writeInt32(isMain ? BC_ENTER_LOOPER : BC_REGISTER_LOOPER);
    do {
        processPendingDerefs();
        result = getAndExecuteCommand();       // 读循环
    } while (...);
}

status_t IPCThreadState::executeCommand(int32_t cmd) {
    case BR_TRANSACTION:
        BBinder* b = tr.cookie;                // 驱动直接给出目标 BBinder 指针!
        b->transact(tr.code, buffer, &reply, tr.flags);   // → onTransact()
}
```

### 8.4 BpBinder 与 BBinder

```cpp
// BpBinder.cpp —— Client 代理,只认识一个 handle 数字
status_t BpBinder::transact(uint32_t code, const Parcel& data,
                            Parcel* reply, uint32_t flags) {
    status_t status = IPCThreadState::self()->transact(binderHandle(), code, data, reply, flags);
    if (status == DEAD_OBJECT) { /* 触发死亡通知 */ }
}

// Binder.cpp —— BBinder::transact 默认实现就是调 onTransact
```

**关键认知**:Client 侧自始至终只持有一个 **handle(句柄数字)**,真正的 Server 对象地址
由驱动在 `binder_transaction` 中翻译。这正是 Binder 安全性高于共享内存的原因——
用户空间进程永远拿不到对方进程的真实指针。

### 8.5 Parcel 中的 Binder 序列化

```cpp
// Parcel.cpp
status_t Parcel::writeStrongBinder(const sp<IBinder>& val) {
    return flattenObject(val);   // 写 flat_binder_object{type=BINDER_TYPE_BINDER, hdr...}
}
const sp<IBinder> Parcel::readStrongBinder() const {
    return unflattenObject(...); // 读 flat_binder_object,查/建 BpBinder 或 BBinder
}
```

驱动会在传输过程中**改写** `flat_binder_object` 的 type:
- `BINDER_TYPE_BINDER`(实体)经过驱动 → 对端变成 `BINDER_TYPE_HANDLE`(句柄)
- 这就是"同一个 Binder 对象,Server 侧是实体、Client 侧是引用"的实现细节

### 8.6 servicemanager 进程

```cpp
// cmds/servicemanager/main.cpp
int main() {
    sp<ProcessState> ps = ProcessState::initWithDriver("/dev/binder");
    ps->becomeContextManager();        // ioctl(BINDER_SET_CONTEXT_MGR) 注册为 0 号
    sp<ServiceManager> manager = sp<ServiceManager>::make(...);
    IPCThreadState::self()->joinThreadPool();
}
```

跟读 `ServiceManager::addService` / `getService` 中对服务表的增查逻辑即可。

---

## 九、L4 内核驱动层(第 13-15 天,抓主线即可)

### 9.1 阅读清单

```
kernel/common/drivers/android/binder.c
kernel/common/drivers/android/binder_alloc.c      ← 内存分配(新版拆出)
kernel/common/include/uapi/linux/android/binder.h ← 用户态协议结构体
```

### 9.2 驱动主链路

```c
binder_open()      // 创建 binder_proc(进程在内核的档案)
binder_mmap()      // 分配内核接收缓冲区,映射到用户空间 ← 一次拷贝的基础!
binder_ioctl()
  └─ BINDER_WRITE_READ
       ├─ binder_thread_write()  // 解析 BC_TRANSACTION
       │    └─ binder_transaction()
       │         // 1. 根据 handle 找到目标 binder_node( Server 实体)
       │         // 2. 分配 binder_transaction 结构
       │         // 3. 从发送进程用户空间 copy_from_user(仅一次!)
       │         // 4. 翻译 flat_binder_object(实体↔句柄)
       │         // 5. 挂到目标线程/进程的 todo 队列,wake_up
       └─ binder_thread_read()   // 目标线程读到 BR_TRANSACTION
```

### 9.3 核心数据结构(对照阅读)

| 结构体 | 含义 |
|--------|------|
| `binder_proc` | 一个使用 Binder 的进程 |
| `binder_thread` | 一个 Binder 线程 |
| `binder_node` | Server 实体(BBinder)在内核中的档案 |
| `binder_ref` | Client 侧对 binder_node 的引用(handle 就是它) |
| `binder_transaction` | 一次事务的完整上下文 |
| `binder_buffer` | 目标进程接收缓冲区中的一块 |
| `flat_binder_object` | 在 Parcel 中传输的 Binder 对象描述 |

### 9.4 一次拷贝的本质

```
传统 IPC:  Client 用户空间 ──copy──▶ 内核缓冲区 ──copy──▶ Server 用户空间   (2 次拷贝)
Binder:    Client 用户空间 ──copy_from_user──▶ Server 的接收缓冲区           (1 次拷贝)
                                                  ▲
                    Server 用户空间通过 mmap 直接读这块内核内存
```

mmap 在 `binder_mmap` 中把**目标进程的内核接收缓冲区**映射到它的用户空间,
数据落地点天然对 Server 可读,省掉第二次拷贝。

---

## 十、三大机制专题

### 10.1 Binder 线程池

- 默认上限:`ProcessState` 中 `DEFAULT_MAX_BINDER_THREADS = 15`(+1 主线程)
- 动态扩容:驱动发现进程忙不过来时,回发 `BR_SPAWN_LOOPER` 请求新线程
- `BC_REGISTER_LOOPER`(动态)vs `BC_ENTER_LOOPER`(主线程)

### 10.2 死亡通知(Death Recipient)

```
Client: linkToDeath(recipient)  → BC_REQUEST_DEATH_NOTIFICATION
驱动监测 Server 进程退出        → 向所有订阅者回 BR_DEAD_BINDER
Client 收到后回调                → IBinder.DeathRecipient.binderDied()
```

典型应用:Service 断开时客户端收到 `onServiceDisconnected()`。

### 10.3 引用计数

- Native 层:`sp`/`wp` 强/弱智能指针
- 跨进程层:`BC_ACQUIRE / BC_RELEASE / BC_INCREFS / BC_DECREFS` 指令
  维护内核 `binder_ref` 的计数,归零时驱动释放 `binder_node`

---

## 十一、动手实践任务

| # | 任务 | 验证目标 |
|---|------|---------|
| 1 | 手写 AIDL 服务并跨进程调用,断点观察 Stub/Proxy | L0 层理解 |
| 2 | 在 `BinderProxy.transact` / `Binder.execTransact` 加日志,验证调用顺序 | Java 层链路 |
| 3 | 在 `IPCThreadState::transact` / `executeCommand` 加日志(需重编 libbinder) | Native 层链路 |
| 4 | `adb shell cat /proc/binder/transactions` 观察实时事务 | 驱动侧视角 |
| 5 | 用 `adb shell service list` + `dumpsys` 枚举系统服务,找 3 个服务的 AIDL 定义 | 理论联系实际 |
| 6 | 传输一个 2MB 的 Bitmap,观察 `TransactionTooLargeException`,解释原因 | 1M 限制 |
| 7 | 实现 linkToDeath 监听,杀掉 Server 进程观察回调 | 死亡通知 |
| 8 | 写一个纯 Native 的 C++ Binder 服务(继承 BnInterface),不用 Java | libbinder 独立使用 |

---

## 十二、自测问题清单(检验是否真正理解)

**基础概念**
1. Binder 相对 Socket / 共享内存的优势是什么?(性能、安全、易用性三个维度)
2. 为什么 Binder 传输有 1M-8K 限制?这个限制在哪个文件的哪个常量定义?
3. handle(句柄)是什么?为什么 Client 拿不到 Server 的真实对象地址?

**Java / JNI 层**
4. `Stub.asInterface()` 在同进程与跨进程时分别返回什么?
5. `BinderProxy` 与 `BpBinder` 如何一一对应?重复 getService 会创建多个 BinderProxy 吗?
6. `JavaBBinder` 类的作用是什么?它的 `onTransact` 回调到哪里?
7. `getCallingPid()` 为什么不需要进驱动就能拿到?

**Native 层**
8. `ProcessState` 与 `IPCThreadState` 的分工?为什么一个是进程单例、一个是线程单例?
9. `transact()` 调用后,Client 线程阻塞在哪里?(`waitForResponse` → `talkWithDriver` → `waitFor` 驱动)
10. Server 侧 `executeCommand` 收到 `BR_TRANSACTION` 后,如何找到目标对象?(tr.cookie 直接是 BBinder 指针)
11. `flat_binder_object` 的 type 经过驱动后如何被改写?为什么?
12. `talkWithDriver()` 为什么是"写+读"一次 ioctl 完成,而不是两次?

**驱动层**
13. `binder_mmap` 映射的是谁的内核内存?为什么这能实现一次拷贝?
14. `binder_transaction()` 函数大致做了哪 5 件事?
15. `binder_node` 与 `binder_ref` 的关系?handle 数字对应哪个结构?
16. ServiceManager 为什么句柄是 0?它在哪一步被设定为 0 的?

**机制专题**
17. Binder 线程池默认多少线程?`BR_SPAWN_LOOPER` 在什么时机下发?
18. 死亡通知的完整链路?内核如何感知 Server 进程死亡?(binder_release → 遍历 ref)
19. oneway(FLAG_ONEWAY)调用与普通调用在驱动层处理上有何区别?(异步事务队列)
20. 为什么 AIDL 里 in/out/inout 参数需要 Parcel 定向?底层 reply Parcel 的角色?

> 合格线:能不看资料回答 16/20 以上,并能在源码中指出对应位置。

---

## 十三、推荐资料

**书籍**
- 《Android 系统源代码情景分析》第 5 章(罗升阳)—— Binder 讲解最深,配合源码食用
- 《深入理解 Android 内核设计思想》第 3、9 章(林学森)

**优质专栏**
- Gityuan《Binder 系列》(gityuan.com)—— 与本文路线高度互补
- 老罗的 Android 之旅《Android 进程间通信(IPC)机制 Binder 简要介绍和学习计划》

**官方**
- https://source.android.com/docs/core/architecture/hidl/binder-ipc
- kernel/common 仓库 `Documentation/` 下 binder 相关文档

**视频**
- 阿里云大学 / 扔物线等 Binder 专题可作入门热身,但最终必须回归源码

---

## 十四、常见踩坑提醒

1. **版本差异**:Android 8 引入 vndbinder、多 binder 节点(`/dev/binder`、`/dev/vndbinder`、`/dev/hwbinder`);
   Android 10+ `BinderProxy` 拆成独立文件;笔记务必标注版本
2. **不要陷在驱动细节**:第一遍读驱动只看 `binder_transaction` 主线,内存红黑树等数据结构第二遍再看
3. **ServiceManager 有两个**:Native 的 servicemanager 进程(本路线)与 Java 层 `ServiceManager` 类(只是个 Proxy 封装),别混淆
4. **调试 libbinder 需要刷机**:Native 层加日志后要重编并替换 `libbinder.so`,建议直接用 eng 版本模拟器
5. **AIDL 生成代码位置**:在 `out/soong/.intermediates/` 下,搜 `IDemoService.java` 可看真实生成物
