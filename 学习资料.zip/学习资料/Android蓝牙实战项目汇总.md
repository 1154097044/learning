# Android 蓝牙实战项目汇总

## 一、官方示例（最推荐）

| 项目 | 说明 |
|------|------|
| [BluetoothChat](https://github.com/android/connectivity-samples/tree/main/BluetoothChat) | Google 官方经典蓝牙聊天 Demo，两台手机通过蓝牙互发文字消息，涵盖扫描、配对、连接、收发数据全流程 |
| [BluetoothLeChat](https://github.com/android/connectivity-samples/tree/main/BluetoothLeChat) | Google 官方 BLE 聊天 Demo，基于 GATT 实现双向通信 |
| [connectivity-samples](https://github.com/android/connectivity-samples) | Google 蓝牙/Wi-Fi/NFC 官方示例合集 |

---

## 二、BLE 数据传输

| 项目 | 说明 |
|------|------|
| [Android-BLE-Library](https://github.com/NordicSemiconductor/Android-BLE-Library) | Nordic 生产级 BLE 库，自带多个 Demo 工程 |
| [nRF Blinky](https://github.com/NordicSemiconductor/Android-nRF-Blinky) | 最简 BLE 控制示例：手机控制 LED + 读取按钮状态，代码精简易懂 |
| [RxAndroidBle](https://github.com/dariuszseber/RxAndroidBle) | RxJava 风格 BLE 库，sample 模块有完整扫描/连接/读写示例 |
| [BLE-starter-android](https://github.com/niclasmora/ble-starter-android) | 极简 BLE 入门 Demo |

---

## 三、经典蓝牙通信 / 文件传输

| 项目 | 说明 |
|------|------|
| [Bluetooth-Chat](https://github.com/niclasmora/bluetooth-chat) | Kotlin 实现的蓝牙聊天 APP，UI 现代 |
| [BluetoothFileTransfer](https://github.com/niclasmora/bluetooth-file-transfer) | 蓝牙文件传输 Demo，支持发送图片、文档 |
| [android-bluetooth-serial](https://github.com/niclasmora/android-bluetooth-serial) | SPP 串口通信封装，可对接打印机/单片机等设备 |

---

## 四、蓝牙 + 硬件联动

| 项目 | 说明 |
|------|------|
| [ESCPOS-ThermalPrinter-Android](https://github.com/DantSu/ESCPOS-ThermalPrinter-Android) | 蓝牙热敏打印机库，支持文本/图片/条码 |
| [Android-nRF-Toolbox](https://github.com/NordicSemiconductor/Android-nRF-Toolbox) | 心率计、温度计、血压计等 BLE Profile 完整实现 |
| [nRF Mesh for Android](https://github.com/NordicSemiconductor/Android-nRF-Mesh-Library) | 蓝牙 Mesh 组网示例 |

---

## 五、快速上手建议

| 步骤 | 方向 | 推荐项目 | 理由 |
|------|------|----------|------|
| 1 | 经典蓝牙 | [BluetoothChat](https://github.com/android/connectivity-samples/tree/main/BluetoothChat) | 官方示例，两台手机即可互发消息，全流程覆盖 |
| 2 | BLE | [nRF Blinky](https://github.com/NordicSemiconductor/Android-nRF-Blinky) | 代码量最小，结构清晰，适合理解 BLE 工作原理 |
| 3 | 库开发 | [Android-BLE-Library](https://github.com/NordicSemiconductor/Android-BLE-Library) | 生产级封装，参考 sample 工程快速开发 |
