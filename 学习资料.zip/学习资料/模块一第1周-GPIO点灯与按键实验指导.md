# 模块一 · 第 1 周手把手实验:GPIO 点灯与按键

> 配套主文档:《Android开发转硬件学习计划.md》第六章 模块一 第 1 周
> 适用设备:树莓派 4B(Raspberry Pi OS)+ 面包板 + LED + 按键 + 电阻
> 预计时长:每天 2-3 小时 × 5-7 天
> 本周目标:用 **gpiozero(Python)→ lgpio(C)→ sysfs(裸操作)** 三级抽象点亮同一颗 LED、读同一个按键,再用逻辑分析仪亲眼看到电平波形与按键抖动
> 前置知识:会用 SSH 连树莓派(见《树莓派4B搭建个人服务器》教程 L2)

---

## 零、本周你将获得什么

一周之内,你会完整走通"硬件思维"的第一课,并拿到四样东西:

| # | 产出 | 验收方式 |
|---|------|----------|
| 1 | 一套能跑的 GPIO 电路(LED + 按键) | 万用表量到 3.3V/0V 电平变化 |
| 2 | 三段等价代码(Python/C/Shell) | 三种实现行为一致 |
| 3 | 逻辑分析仪抓到的方波 + 按键抖动波形 | PulseView 里能看到并测量周期 |
| 4 | "抽象阶梯"的体感 | 能讲清 gpiozero / lgpio / sysfs 分别在哪一层 |

> 贯穿本周的核心认知:**同一颗 LED,从 Python 到裸寄存器,你调用的层次越来越低,但硬件上做的事完全一样——都是把某个引脚拉到高电平。** 这条"抽象阶梯"正是你从 Android 应用层下探到硬件的第一级台阶。

---

## 一、硬件清单与引脚规划

### 1.1 需要的元件

| 元件 | 数量 | 说明 |
|------|------|------|
| 树莓派 4B | 1 | 已装系统、能 SSH |
| 面包板 | 1 | 半尺寸即可 |
| LED(任意颜色) | 1 | 注意正负极:长脚=阳极(+),短脚=阴极(-) |
| 轻触按键(4 脚) | 1 | 常见的 6×6mm  tact switch |
| 电阻 220Ω ~ 330Ω | 1 | LED 限流用 |
| 电阻 10kΩ | 1 | 按键上拉用 |
| 杜邦线(公对公/公对母) | 若干 | 连接 Pi 排针与面包板 |
| 万用表 | 1 | 排错第一手(强烈建议) |
| 8 通道 USB 逻辑分析仪 | 1 | 第六节抓波形用(可稍后买) |

### 1.2 关键概念:GPIO 编号有两套,别搞混!

这是新手**最容易踩的坑**:树莓派有两种引脚编号方式,`gpiozero` 和 `lgpio` 默认都用 **BCM 编号**(即 GPIO 号),而不是排针的物理序号。

```
        ┌─────────────────────┐
   3V3 ─┤ 1                 2 ├─ 5V
        │ 3                 4 │
    GND ┤ 5                 6 ├─ GND      ← 供电/地
        │ 7                 8 │
    GND ┤ 9                10 │           ← 我们用 9 号做 LED 的地
 GPIO17 ┤11                12 │           ← 【LED 信号:BCM 17 = 物理 11】
 GPIO27 ┤13                14 ├─ GND      ← 【按键信号:BCM 27 = 物理 13】【按键地:14】
        │15                16 │
   3V3 ─┤17                18 │           ← 【按键上拉:17 号 3.3V】
        │19                20 │
        │21                22 │
        │ ......(其余省略)   │
        └─────────────────────┘
         奇数排在左,偶数排在右
```

### 1.3 本周引脚分配表(照着接就行)

| 功能 | BCM 编号(代码里用) | 物理引脚(接线用) | 电平逻辑 |
|------|---------------------|---------------------|----------|
| LED 信号 | GPIO 17 | 物理 11 | 高电平点亮(Active-High) |
| LED 地 | GND | 物理 9 | — |
| 按键信号 | GPIO 27 | 物理 13 | 低电平按下(Active-Low) |
| 按键上拉 | 3.3V | 物理 17 | 经 10kΩ 上拉 |
| 按键地 | GND | 物理 14 | — |

---

## 二、面包板接线说明

### 2.1 先搞懂面包板结构

```
  红+ ─┬─┬─┬─┬─┬─ ... ← 顶部电源轨(整条横向连通)接 3.3V
  蓝- ─┬─┬─┬─┬─┬─ ... ← 顶部地轨(整条横向连通)接 GND
       ─────────────── 中间凹槽(集成电路跨骑处)
   a  ┃ ● ● ● ● ●      ← 每一"列"(a~e 五个孔)竖向连通
   b  ┃ ● ● ● ● ●
   c  ┃ ● ● ● ● ●
   d  ┃ ● ● ● ● ●
   e  ┃ ● ● ● ● ●
       ════凹槽════      ← 凹槽两侧(a~e 与 f~j)不连通!
   f  ┃ ● ● ● ● ●
   ...
```

**两条铁律**:① 边缘的红/蓝电源轨是**横向**整条连通;② 中间区域每一列(a-e 或 f-j)是**竖向** 5 孔连通,但**跨过凹槽不连通**。元件两条腿要插在**不同列**,否则会短路。

### 2.2 给面包板供电

1. Pi 物理 **17 脚(3.3V)** → 杜邦线 → 面包板**红色电源轨**
2. Pi 物理 **9 脚(GND)** → 杜邦线 → 面包板**蓝色地轨**

> ⚠️ 用 3.3V,**绝对不要接 5V(物理 2/4 脚)到 GPIO 信号线**——树莓派 GPIO 不耐 5V,会烧。

### 2.3 接 LED 电路(Active-High)

```
GPIO17(物理11) ──[ 220Ω 电阻 ]──►|── GND(物理9)
                                  LED
                        (电流方向:长脚→短脚)
```

分步:
1. 从 Pi 物理 **11 脚(GPIO17)** 拉一根线到面包板某列(如 `e10`)
2. 220Ω 电阻跨接:`e10` 这一列 → 另一列(如 `e15`)
3. LED **长脚(阳极)** 插 `e15`(和电阻同列),**短脚(阴极)** 插另一列(如 `f18`)
4. 从 `f18` 所在列 → 面包板**蓝色地轨**(或直接接 Pi 物理 9 脚 GND)

### 2.4 接按键电路(Active-Low + 外部上拉)

```
3.3V(物理17) ──[ 10kΩ ]──┬──── GPIO27(物理13)
                          │
                        [ 按键 ]
                          │
                         GND(物理14)

松开:GPIO27 被 10kΩ 上拉到 3.3V → 读到 1(高)
按下:GPIO27 直接短接到 GND       → 读到 0(低)
```

分步:
1. 面包板**红轨(3.3V)** → 10kΩ 电阻 → 某中间列(如 `c25`)
2. 从 `c25` 拉一根线到 Pi 物理 **13 脚(GPIO27)**
3. 按键一只脚插 `c25` 这一列,另一只脚插**蓝轨(GND)** 或经线接 Pi 物理 **14 脚(GND)**
4. 检查:按键没按下时,`c25` 只通过 10kΩ 连到 3.3V(读高);按下时,`c25` 被短接到 GND(读低)

> **为什么用外部上拉而不是内部上拉?** 因为外部 10kΩ 上拉能让 **gpiozero、lgpio(C)、sysfs 三种实现共用同一套接线**,不用为每种库改硬件或改代码里的偏置配置。sysfs 尤其需要外部上拉(它不方便配置内部偏置)。这是本周教学选它的原因。

### 2.5 上电前自检(万用表 30 秒排错)

| 检查项 | 万用表怎么量 | 期望值 |
|--------|--------------|--------|
| 电源轨 | 红表笔插红轨,黑表笔插蓝轨 | ≈ 3.3V |
| LED 极性 | 目视:长脚接电阻侧,短脚接地侧 | — |
| 无短路 | 断电,量 GPIO17 列与 GND 之间电阻 | 非 0Ω(应约 220Ω+LED) |

---

## 三、实现一:gpiozero(Python,最高层)

> `gpiozero` 是树莓派官方推荐的 Python 库,通常系统已预装。它把引脚封装成 `LED`、`Button` 对象,是三级抽象里最"傻瓜"的一层。

### 3.1 确认安装

```bash
# 一般已预装;若没有:
sudo apt update && sudo apt install -y python3-gpiozero
```

### 3.2 代码 `led_button_gpiozero.py`

```python
from gpiozero import LED, Button
from time import sleep
from signal import pause

led = LED(17)      # BCM GPIO 17,代码里写 BCM 号
button = Button(27)  # 默认 pull_up=True,按下为低电平

# --- 阶段 1:闪烁 5 次,验证 LED 接线 ---
print("LED 闪烁 5 次...")
led.blink(on_time=0.5, off_time=0.5, n=5, background=False)

# --- 阶段 2:事件驱动,按住点亮、松开熄灭 ---
print("按住按键点亮 LED,Ctrl+C 退出")
button.when_pressed = led.on      # 按下 → 点亮
button.when_released = led.off    # 松开 → 熄灭

pause()  # 挂起主线程,等待事件
```

### 3.3 运行

```bash
python3 led_button_gpiozero.py
```

### 3.4 验收标准

- [ ] LED 先规律闪烁 5 次(亮 0.5s、灭 0.5s)
- [ ] 按住按键 LED 亮,松开 LED 灭(注意是**事件驱动**,无需轮询)
- [ ] 能口述:`gpiozero` 帮你屏蔽了引脚方向设置、上拉配置、事件监听——这就是"高层抽象"的代价与便利

---

## 四、实现二:lgpio(C,直接操作 gpiochip)

> `lgpio` 是 joan2937(lgpio/lg 项目)提供的 C 库,直接走 Linux 的 `/dev/gpiochipN` 字符设备接口。这一层没有 `LED`/`Button` 对象,你要自己"声明引脚为输出/输入"再读写——正是驱动开发的前置体感。

### 4.1 安装开发库

```bash
sudo apt update && sudo apt install -y liblgpio-dev
# 若仓库没有,则从源码编译:
#   git clone https://github.com/joan2937/lg && cd lg && make && sudo make install
```

### 4.2 代码 `led_button_lgpio.c`

```c
#include <stdio.h>
#include <unistd.h>
#include <lgpio.h>

#define LED_GPIO    17   /* BCM 编号 */
#define BUTTON_GPIO 27

int main(void) {
    /* 打开 gpiochip0(/dev/gpiochip0),返回句柄 */
    int h = lgGpiochipOpen(0);
    if (h < 0) { printf("open gpiochip failed: %d\n", h); return 1; }

    /* 声明:LED 为输出(初始低电平);按键为输入(外部已上拉,lFlags=0) */
    lgGpioClaimOutput(h, 0, LED_GPIO, 0);
    lgGpioClaimInput(h, 0, BUTTON_GPIO);

    /* 阶段 1:闪烁 5 次 */
    for (int i = 0; i < 5; i++) {
        lgGpioWrite(h, LED_GPIO, 1); usleep(500000);  /* 亮 0.5s */
        lgGpioWrite(h, LED_GPIO, 0); usleep(500000);  /* 灭 0.5s */
    }

    /* 阶段 2:轮询按键,按住点亮、松开熄灭 */
    printf("按住按键点亮 LED,Ctrl+C 退出\n");
    while (1) {
        int level = lgGpioRead(h, BUTTON_GPIO);   /* 按下=0,松开=1 */
        lgGpioWrite(h, LED_GPIO, level ? 0 : 1);  /* 低电平(按下)→点亮 */
        usleep(20000);                            /* 20ms 轮询,兼作软件消抖 */
    }

    lgGpiochipClose(h);  /* 实际到不了这里,Ctrl+C 退出 */
    return 0;
}
```

### 4.3 编译与运行

```bash
gcc led_button_lgpio.c -o led_button -llgpio
sudo ./led_button          # 访问 /dev/gpiochip0 需要 root 或 gpio 组权限
```

> 免 sudo 做法:把自己加入 `gpio` 组后重新登录
> `sudo usermod -aG gpio $USER && newgrp gpio`

### 4.4 验收标准

- [ ] `gcc ... -llgpio` 编译通过,无报错
- [ ] 运行后行为与 gpiozero 版本**完全一致**(闪 5 次 + 按住点亮)
- [ ] 能口述 C 版本比 Python 多做了哪两件事:**显式声明引脚方向**(`lgGpioClaimOutput/Input`)、**自己轮询消抖**(`usleep`)

---

## 五、实现三:sysfs 裸操作(/sys/class/gpio)

> 这是最"裸"的一层:直接把引脚号写进内核暴露的虚拟文件,不依赖任何库。**教学价值极高**——你会看清"用户态写文件 → 内核改寄存器"的本质,这正是驱动的世界观。

### 5.1 手动逐步操作(先理解机制)

```bash
# 1) 导出引脚:内核会在 /sys/class/gpio/ 下创建 gpio17、gpio27 目录
echo 17 | sudo tee /sys/class/gpio/export
echo 27 | sudo tee /sys/class/gpio/export

# 2) 设置方向
echo out | sudo tee /sys/class/gpio/gpio17/direction   # LED 输出
echo in  | sudo tee /sys/class/gpio/gpio27/direction   # 按键输入

# 3) 点亮 / 熄灭 LED
echo 1 | sudo tee /sys/class/gpio/gpio17/value         # 亮
echo 0 | sudo tee /sys/class/gpio/gpio17/value         # 灭

# 4) 读按键(松开=1,按下=0)
cat /sys/class/gpio/gpio27/value

# 5) 用完释放引脚
echo 17 | sudo tee /sys/class/gpio/unexport
echo 27 | sudo tee /sys/class/gpio/unexport
```

### 5.2 脚本版 `led_button_sysfs.sh`(等价于前两段程序)

```bash
#!/bin/bash
# 导出并配置引脚
for g in 17 27; do echo $g | sudo tee /sys/class/gpio/export >/dev/null 2>&1; done
echo out | sudo tee /sys/class/gpio/gpio17/direction >/dev/null
echo in  | sudo tee /sys/class/gpio/gpio27/direction >/dev/null

LED=/sys/class/gpio/gpio17/value
BTN=/sys/class/gpio/gpio27/value

# 阶段 1:闪烁 5 次
for i in $(seq 5); do
  echo 1 | sudo tee $LED >/dev/null; sleep 0.5
  echo 0 | sudo tee $LED >/dev/null; sleep 0.5
done

# 阶段 2:按住点亮、松开熄灭
echo "按住按键点亮 LED,Ctrl+C 退出"
while true; do
  [ "$(cat $BTN)" = "0" ] && echo 1 | sudo tee $LED >/dev/null \
                          || echo 0 | sudo tee $LED >/dev/null
  sleep 0.02
done
```

```bash
chmod +x led_button_sysfs.sh && ./led_button_sysfs.sh
```

### 5.3 重要说明:sysfs 已废弃,现代替代是 libgpiod

`/sys/class/gpio`(sysfs GPIO 接口)自 Linux **4.8(2016)** 起被官方标记为 **deprecated**,新代码推荐用 **GPIO 字符设备 `/dev/gpiochipN` + libgpiod** 工具集:

```bash
gpioinfo                    # 列出所有 gpiochip 及引脚状态
gpioset gpiochip0 17=1      # 把 GPIO17 拉高(点亮)
gpioget gpiochip0 27        # 读 GPIO27(按键)
gpiomon gpiochip0 27        # 实时监听 GPIO27 跳变——能直接看到按键抖动!
```

> `gpioset/gpioget/gpiomon` 的语法随 libgpiod 版本(v1/v2)略有差异,用 `gpioset --help` 确认。**`gpiomon` 是下一节逻辑分析仪的软件平替**——没有硬件时,用它也能看到按键抖动事件流。

### 5.4 验收标准

- [ ] 手动 `echo` 能点亮/熄灭 LED,`cat` 能读到按键 0/1
- [ ] 脚本版行为与前两段程序一致
- [ ] 能口述:sysfs 的本质是"**用户态写虚拟文件 → 内核驱动改 GPIO 寄存器**",以及它为什么被 libgpiod 取代(不支持事件通知、只能轮询、无按引脚加锁)

---

## 六、逻辑分析仪抓波形(本周的高光时刻)

> 软件跑通了不算完——**用逻辑分析仪亲眼看到电平波形和按键抖动,才是从"写代码"到"懂硬件"的分水岭。** 你会第一次"看见"电。
>
> 📖 分析仪的**选购 / 安装 / 连接 / 通用抓波五步**见独立手册:《逻辑分析仪抓波形操作手册.md》;本节只列本周配方。

### 6.1 硬件连接(务必共地!)

| 逻辑分析仪通道 | 接到 | 说明 |
|----------------|------|------|
| **GND 夹子** | Pi 物理 6 或 9 脚(GND) | **必须接!不共地全是噪声** |
| CH0 | GPIO17(LED 信号,物理 11) | 抓 LED 方波 |
| CH1 | GPIO27(按键信号,物理 13) | 抓按键跳变 |

### 6.2 软件选择

| 软件 | 适用 | 备注 |
|------|------|------|
| **PulseView(sigrok)** | 大多数国产克隆分析仪(蓝色 24MHz 8 通道,FX2 芯片) | 开源免费,macOS 可用,驱动选 `fx2lafw` |
| Saleae Logic 2 | 原厂 Saleae 设备 | 官方软件,体验最好(克隆件可能被拒) |

### 6.3 抓 LED 方波步骤(PulseView)

1. 连接设备,打开 PulseView,右上角选择设备驱动(克隆件选 `fx2lafw` / "Saleae Logic")
2. 设置**采样率**:GPIO 慢速翻转用 **1~4 MS/s** 足够;抓按键抖动建议 ≥ 1 MS/s
3. 设置采样点数(如 1M),勾选 CH0、CH1 两个数字通道
4. 点 **Run** 开始采集,同时在 Pi 上运行闪烁程序
5. 波形出现后,用**时间标尺(ruler)**量一个完整周期

### 6.4 抓按键抖动(debounce 教学金句)

1. 在 CH1 上设一个**下降沿触发**(Falling Edge)
2. 点 Run,然后按下按键
3. **放大按下瞬间的边缘**——你会看到电平不是干净地从高到低,而是在几毫秒内**来回抖动好几次**才稳定!

```
理想按键:  ────────┐
                    └──────────────

真实按键:  ────────┐ ┌┐┌┐
                    └─┘└┘└──────────  ← 这几毫秒的抖动就是"bounce"
                    ↑ 放大看这一段
```

> 这就是为什么所有按键代码都要**消抖(debounce)**——软件延时(我们代码里的 `usleep(20000)`)或硬件 RC 电路。**亲眼看到抖动一次,胜过读十篇文章。**

### 6.5 验收标准

- [ ] CH0 抓到规整方波,用标尺量出的**周期 ≈ 1s**(0.5s 亮 + 0.5s 灭),与代码一致
- [ ] CH1 松开时为高(3.3V)、按下时为低(0V)
- [ ] 在 CH1 按下边缘**放大后能看到多次抖动**,并能解释这就是 bounce、为什么需要消抖
- [ ] 能算出:LED 闪烁频率 = 1 / 周期 ≈ 1Hz

---

## 七、本周总验收清单

全部打勾,第 1 周才算通关:

- [ ] **接线**:独立接好 LED(限流电阻 + 极性正确)与按键(外部上拉 + 共地)电路
- [ ] **万用表**:量到 LED 引脚高电平 3.3V、低电平 0V
- [ ] **gpiozero**:LED 闪 5 次 + 事件驱动按住点亮
- [ ] **lgpio(C)**:编译通过,行为与 Python 版一致
- [ ] **sysfs**:`echo`/`cat` 手动点亮并读按键,理解"写文件改寄存器"
- [ ] **抽象阶梯**:能画出 gpiozero → lgpio → sysfs 三层的抽象高低关系
- [ ] **逻辑分析仪**:抓到方波(周期≈1s)+ 看到按键抖动
- [ ] **口述**:讲清 BCM vs 物理编号、Active-High vs Active-Low、为什么要消抖

---

## 八、常见问题排查

| 现象 | 可能原因 | 排查 |
|------|----------|------|
| LED 完全不亮 | 极性反了 / 电阻没接 / GPIO 编号写错 | 断电调 LED 方向;确认代码写 **BCM 17** 不是物理 11 |
| LED 很暗或不亮 | 电阻阻值太大 / 接了错误的引脚 | 换 220Ω;万用表量引脚是否真有 3.3V |
| **蓝/白光 LED 偏暗**(换小电阻仍暗) | 蓝/白 Vf≈3.0~3.4V,3.3V 余量仅 0.1~0.3V | 见 **8.1 专题**:换红光,或改 5V+三极管 |
| **不接电阻时爆亮** | **过流!** 仅靠 GPIO 内阻限流,不可控 | 立即串电阻;爆亮是危险状态,见 **8.1** |
| 运行报权限错误 | 访问 `/dev/gpiochip0` 需要 root | 加 `sudo`,或把用户加入 `gpio` 组 |
| 编译报 `lgpio.h: No such file` | 没装开发库 | `sudo apt install liblgpio-dev` |
| 按键读数乱跳/一直是 1 或 0 | 没接上拉电阻,引脚悬空 | 确认 10kΩ 上拉到 3.3V;**务必共地** |
| `echo export` 报 `Device or resource busy` | 引脚被其他程序或内核占用 | 先关掉 gpiozero/其他脚本;或该脚被 UART 等占用,换个脚 |
| 逻辑分析仪全是噪声/无波形 | 没接 GND | **GND 夹子必须接 Pi 的地**,共地是第一原则 |
| 逻辑分析仪识别不到设备 | 驱动/权限问题 | 克隆件用 PulseView 选 `fx2lafw`;macOS 检查 USB 权限 |

### 8.1 实战案例:蓝/白光 LED 的压降坑(以及为什么"不接电阻"是陷阱)

> 本节源自一次真实排障:同一颗蓝光 LED,"串电阻极暗、不串电阻爆亮"。两张对照照片直接锁定根因,是理解"压降余量 × 限流电阻"耦合关系的绝佳案例。

**根因:压降余量太小,电路对电阻极度敏感**

LED 要先跨过导通压降 Vf 才正常发光,电流 = (供电 − Vf) ÷ 电阻:

| LED 颜色 | Vf | 3.3V 余量 | 串 220Ω 电流 | 表现 |
|----------|-----|-----------|--------------|------|
| 红/黄/绿 | ≈1.8~2.0V | ≈1.3V | ≈5.9mA | 很亮 ✅ |
| 蓝/白 | ≈3.0~3.4V | ≈0.1~0.3V | ≈0.5~1.4mA | 偏暗 ❌ |

余量只有零点几伏时,**任何"看起来正常"的电阻(220Ω/1k/10k)都足以把电流掐到几乎为零** → 串电阻极暗;而**拿掉电阻**后只剩 GPIO 内部几十欧阻抗,电流涌上来 → 爆亮。两个现象是"余量小 × 电阻限流"相乘的结果,单独看任一个都会误判。

**⚠️ 为什么"不接电阻"是陷阱(过流警告)**

- 不接电阻时,限流的只有 GPIO 内部阻抗(非设计限流、个体差异大),电流不可控;
- 蓝光因余量小"碰巧"自我限流没烧,但**换红光 LED(Vf≈2V)不接电阻,电流≈(3.3−2)/几十欧≈30mA,超单脚 16mA 上限,可能烧 GPIO 或 LED**;
- 爆亮是**过流**不是健康状态,**永远串一个算过阻值的电阻**。

**蓝/白光的三条正路**

| 方案 | 做法 | 亮度 | 推荐 |
|------|------|------|------|
| ① 换红/黄/绿 LED | 串 220~330Ω | 很亮且安全 | ⭐ 学习期首选 |
| ② 5V + NPN 三极管开关 | GPIO 仅作控制信号,5V 经三极管供电 | 全亮 | 进阶好课 |
| ③ 蓝光硬接 3.3V | 串 47~100Ω 小电阻 | 中等 | 凑合,不稳定 |

**方案② 三极管开关电路(NPN 低边开关)**

```
GPIO(3.3V)──[1kΩ]──┐基极 B
                    │  NPN(S8050 / 2N2222)
5V(物理2/4脚)──[220Ω]──LED(+)→LED(−)──集电极 C
                    发射极 E──GND
```

GPIO 高 → 三极管导通 → 5V 经限流电阻点亮 LED(余量 = 5−3.2 ≈ 1.8V,电流充足);GPIO 低 → 截止 → 灭。**这是你的第一个"用小信号控制大电流"的开关电路**,可作为第 2 周的展开课题。

---

## 九、延伸思考(为第 2 周铺垫)

1. **内部上拉 vs 外部上拉**:Pi 内置约 50kΩ 可配置上拉/下拉。什么时候能省掉外部电阻?为什么 sysfs 场景下建议用外部上拉?
2. **消抖的三种做法**:软件延时(本周用的)、硬件 RC 电路、状态机消抖。各自的代价?
3. **mmap 裸操作**:比 sysfs 更低一层——通过 `/dev/gpiomem` 或 `/dev/mem` 用 `mmap` 直接映射 GPIO 寄存器地址读写。这是"离硅片最近"的用户态方式,学有余力可挑战。
4. **下周预告**:第 2 周接 I2C 传感器(BMP280/MPU6050)。届时逻辑分析仪加上 **I2C 协议解码器**,你能直接看到"起始位 → 器件地址 → 寄存器地址 → 数据"的完整时序——本周学的抓波形技能立刻派上用场。

---

> 一句话收尾:**这周你点亮的不是一个 LED,而是打通了"从 Python 到内核寄存器再到真实电平"的整条链路。当你在逻辑分析仪上第一次看到自己写的 `led.on()` 变成一个真实的 3.3V 方波、看到按键抖动的毛刺——你就正式踏入硬件世界了。**
