# Media3 ExoPlayer 学习路线与上手 Demo

> 目标：从能播放一个视频，逐步掌握流媒体、后台播放、缓存、埋点与 DRM，并具备落地生产播放器的能力。
>
> 建议周期：4 周；每天 1.5～2 小时。已有 Android 开发经验可压缩为 2 周。
>
> 技术基线：新项目使用 Jetpack Media3；`ExoPlayer` 是 Media3 中 `Player` 接口的默认实现。不要新建基于旧包名 `com.google.android.exoplayer2` 的代码。

---

## 1. 学习完成标准

完成本路线后，应能够：

- [ ] 使用 `ExoPlayer` 播放本地 MP4、远程 MP4、HLS（m3u8）和 DASH（mpd）。
- [ ] 正确管理 `PlayerView`、播放器生命周期、播放状态与错误。
- [ ] 支持播放列表、倍速、循环、清晰度/音轨/字幕切换与断点续播。
- [ ] 用 `MediaSessionService` 实现通知栏、锁屏、耳机按键和后台播放。
- [ ] 接入预加载/缓存、播放质量指标与常见故障诊断。
- [ ] 理解 DRM、广告、投屏及离线下载的适用边界，能基于官方 Demo 进行扩展。

---

## 2. 先建立正确的技术模型

```text
UI 层（PlayerView / Compose Player / 自定义控制器）
             │ 绑定并发送控制命令
             ▼
Player 接口 ─────────────────────────────────┐
             │                               │
             ▼                               ▼
        ExoPlayer                       MediaController
             │                               │
             ▼                               ▼
MediaItem → MediaSource → DataSource    MediaSession / MediaSessionService
             │
             ├─ Progressive / HLS / DASH / RTSP 等协议
             ├─ TrackSelector：音视频轨、字幕、清晰度
             ├─ LoadControl：缓冲策略
             ├─ Renderers：音频、视频、文本、图像渲染
             └─ AnalyticsListener：播放指标与错误采集
```

### 核心对象速查

| 对象 | 作用 | 入门阶段 |
|---|---|---|
| `Player` | 播放、暂停、跳转、播放状态等统一 API | 第 1 周 |
| `ExoPlayer` | `Player` 的默认实现，负责加载、缓冲、解码、渲染 | 第 1 周 |
| `MediaItem` | 一条媒体描述；可附加字幕、裁剪区间、DRM 配置 | 第 1 周 |
| `PlayerView` | View 体系的现成视频画面与控制器 | 第 1 周 |
| `Player.Listener` | 监听状态、媒体切换、错误、轨道变化 | 第 1 周 |
| `TrackSelectionParameters` | 指定清晰度、语言、字幕与音轨偏好 | 第 2 周 |
| `MediaSession` | 向系统及外部控制端暴露播放状态和控制命令 | 第 3 周 |
| `MediaSessionService` | 承载后台播放与媒体通知 | 第 3 周 |
| `CacheDataSource` / `SimpleCache` | 缓存网络媒体数据 | 第 3 周 |
| `AnalyticsListener` | 采集首帧、卡顿、加载、错误等播放指标 | 第 4 周 |
| `Transformer` | 媒体裁剪、合成、特效、导出；不是在线播放器的必需部分 | 第 4 周（选修） |

### 关键工程原则

1. 一个 `ExoPlayer` 实例只能从同一个应用线程访问；绝大多数业务应固定在主线程。
2. 在一个页面/播放域内复用播放器，避免每次点击都创建新实例。
3. 释放播放器以归还解码器、Surface、音频焦点等有限资源；调用 `release()` 后不要继续访问该实例。
4. 不把 `STATE_READY` 直接等同于“正在播放”。应综合 `playWhenReady`、`playbackState` 与回调处理 UI。
5. 后台音频或需要系统媒体控制时，让 `MediaSessionService` 持有播放器；不要仅把播放器放在 `Activity` 中。
6. HLS/DASH 依赖对应的 Media3 协议模块；所有 `androidx.media3` 依赖版本必须一致。

---

## 3. 环境与第一个可运行 Demo（第 0 天）

### 3.1 前置知识

- Kotlin、Activity/Fragment 生命周期、Gradle 依赖。
- 基础网络与 HTTP 概念。
- 了解视频编码、封装格式与传输协议是不同概念：例如 H.264 是视频编码，MP4 是容器，HLS/DASH 是流媒体分发协议。

### 3.2 推荐依赖

将同一个版本号定义为 Gradle Version Catalog 或常量。以下以 `<media3_version>` 表示当前稳定版本；发布前在 [Media3 Release Notes](https://developer.android.com/jetpack/androidx/releases/media3) 核对。

```kotlin
implementation("androidx.media3:media3-exoplayer:<media3_version>")
implementation("androidx.media3:media3-ui:<media3_version>")

// 按业务引入，而不是无差别全部引入。
implementation("androidx.media3:media3-exoplayer-hls:<media3_version>")
implementation("androidx.media3:media3-exoplayer-dash:<media3_version>")
implementation("androidx.media3:media3-session:<media3_version>")
```

如项目未配置 Java 8+，还需要在 Android 模块开启相应的 `compileOptions`。详见[官方快速开始](https://developer.android.com/media/media3/exoplayer/hello-world)。

### 3.3 Demo 0：播放一条 MP4 或 HLS 地址

**学习目标**：建立播放器、绑定 UI、设置 `MediaItem`、准备播放并在合适时机释放。

XML：

```xml
<androidx.media3.ui.PlayerView
    android:id="@+id/playerView"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:keepScreenOn="true" />
```

Kotlin：

```kotlin
private var player: ExoPlayer? = null

private fun initializePlayer() {
    val exoPlayer = ExoPlayer.Builder(this).build()
    binding.playerView.player = exoPlayer

    exoPlayer.setMediaItem(MediaItem.fromUri("https://example.com/video.m3u8"))
    exoPlayer.prepare()
    exoPlayer.playWhenReady = true
    player = exoPlayer
}

private fun releasePlayer() {
    binding.playerView.player = null
    player?.release()
    player = null
}
```

**验收**：能播放、暂停、拖动进度条；旋转屏幕或退到后台再回来时，不崩溃、不出现多个音频同时播放。

**注意**：实际项目中初始化/释放应结合页面是否可见与产品的后台播放需求安排；不要机械套用单一生命周期回调。若需要后台播放，直接进入第 3 周的 `MediaSessionService` 方案。

---

## 4. 四周学习路线与配套上手 Demo

### 第 1 周：稳定完成基础播放

| 日程 | 学习主题 | 上手 Demo | 验收标准 |
|---|---|---|---|
| D1 | `Player`、`ExoPlayer`、`MediaItem`、`PlayerView` | Demo 0：单视频播放 | 能完成创建、`prepare()`、播放和释放 |
| D2 | 生命周期与状态机 | Demo 1：状态面板 | 展示 `playWhenReady`、`playbackState`、缓冲与错误 |
| D3 | `Player.Listener` 与错误处理 | Demo 1：网络断开/错误提示 | 通过 `onPlayerError` 显示可理解的错误并支持重试 |
| D4 | 播放列表、跳转、循环、倍速 | Demo 2：迷你播放列表 | 可前后切换、跳转、设置倍速和循环模式 |
| D5 | `MediaItem`、外挂字幕、视频尺寸 | Demo 3：字幕播放 | 传入外置 WebVTT 字幕并验证显示 |
| D6～D7 | 复盘与重构 | 将 Demo 0～3 合并为 Player Playground | 生命周期、状态展示、错误处理职责清晰 |

#### Demo 1：播放状态与错误面板

监听的最小集合：

```kotlin
player.addListener(object : Player.Listener {
    override fun onPlaybackStateChanged(playbackState: Int) {
        // IDLE / BUFFERING / READY / ENDED
    }

    override fun onIsPlayingChanged(isPlaying: Boolean) {
        // 适合更新“播放中”UI 与埋点。
    }

    override fun onPlayerError(error: PlaybackException) {
        // 记录 errorCode、cause、当前 MediaItem，并给用户可操作的提示。
    }
})
```

**本周必读**：

- [ExoPlayer 官方快速开始](https://developer.android.com/media/media3/exoplayer/hello-world)
- [Player events 与监听模型](https://developer.android.com/media/media3/exoplayer/listening-to-player-events)
- [Media items：字幕、裁剪、DRM 等媒体描述](https://developer.android.com/media/media3/exoplayer/media-items)
- [播放列表](https://developer.android.com/media/media3/exoplayer/playlists)

---

### 第 2 周：流媒体、轨道与自定义控制

| 日程 | 学习主题 | 上手 Demo | 验收标准 |
|---|---|---|---|
| D8 | Progressive、HLS、DASH 的加载路径 | Demo 4：协议切换页 | 同页播放 MP4、m3u8、mpd，能识别对应模块缺失问题 |
| D9 | 自适应码率与轨道信息 | Demo 5：清晰度/音轨列表 | 读取 `currentTracks` 并显示可选轨道 |
| D10 | `TrackSelectionParameters` | Demo 5：手动选轨 | 可指定最高分辨率、首选音频语言、关闭/开启字幕 |
| D11 | `PlayerView` 控制器与自定义 UI | Demo 6：自定义控制栏 | 播放、暂停、快进、倍速、全屏状态与播放器一致 |
| D12 | 屏幕旋转、全屏、画中画设计 | Demo 7：沉浸与 PiP | 进入/退出全屏或 PiP 后播放状态正确 |
| D13～D14 | 流媒体故障定位 | 为 Demo 4 添加诊断日志 | 能说明协议模块、MIME 类型、网络与解码器的排查顺序 |

#### Demo 5：清晰度、音轨和字幕选择

建议先实现“自动 / 指定最高分辨率 / 指定音频语言 / 指定文本语言”四种能力，而不是直接解析与硬编码轨道索引。轨道信息随媒体、清晰度自适应和播放时机变化，业务层应基于 `Tracks` 与 `TrackSelectionParameters` 建立可恢复的用户偏好。

**本周必读**：

- [HLS](https://developer.android.com/media/media3/exoplayer/hls)
- [DASH](https://developer.android.com/media/media3/exoplayer/dash)
- [轨道选择](https://developer.android.com/media/media3/exoplayer/track-selection)
- [播放器 UI 与自定义](https://developer.android.com/media/media3/ui)
- [故障排查](https://developer.android.com/media/media3/exoplayer/troubleshooting)

---

### 第 3 周：后台播放、缓存与列表预加载

| 日程 | 学习主题 | 上手 Demo | 验收标准 |
|---|---|---|---|
| D15 | `MediaSession` 与外部控制 | Demo 8：MediaSession 基础版 | 系统媒体通知能显示标题、封面和播放状态 |
| D16 | `MediaSessionService` | Demo 9：后台音频播放 | 退到后台后仍可播放；通知栏/耳机按键可控制 |
| D17 | `MediaController`、权限与命令边界 | Demo 9：控制端页面 | UI 通过 Controller 连接 Session，并正确释放连接 |
| D18 | 网络缓存 | Demo 10：缓存命中统计 | 第二次播放相同内容可观察到缓存命中 |
| D19 | 短视频/列表预加载 | Demo 11：列表自动播放 | 当前项播放、下一项预加载，滑动中不创建过多实例 |
| D20～D21 | 架构整理 | 提炼 `PlayerRepository` 或业务播放器组件 | UI、播放控制、Session、缓存职责分离 |

#### Demo 9：后台音频播放

目标架构：

```text
Activity / Fragment
      │ MediaController
      ▼
MediaSessionService ── MediaSession ── ExoPlayer
      │
      └─ 系统通知、锁屏、蓝牙耳机、Android Auto 等媒体控制入口
```

服务中负责创建和关闭 `ExoPlayer` 与 `MediaSession`；页面侧通过 `MediaController` 控制。这样播放器的生命周期不会被单个页面销毁所中断。

#### Demo 10：缓存播放

先完成**边播边缓存**，再评估是否需要离线下载。缓存目录、最大容量、淘汰策略、鉴权 URL 过期策略与清理时机都应由产品和服务端能力共同决定。

**本周必读**：

- [后台播放与 MediaSessionService](https://developer.android.com/media/media3/session/background-playback)
- [MediaSession 概览](https://developer.android.com/media/media3/session)
- [预加载媒体](https://developer.android.com/media/media3/exoplayer/preloading-media)
- [缓存数据加载](https://developer.android.com/media/media3/exoplayer/customization#caching-data-loaded-from-the-network)
- [下载媒体以供离线播放](https://developer.android.com/media/media3/exoplayer/downloading-media)

---

### 第 4 周：质量、商业能力与进阶专题

| 日程 | 学习主题 | 上手 Demo | 验收标准 |
|---|---|---|---|
| D22 | `AnalyticsListener` 与质量指标 | Demo 12：播放埋点 | 能记录首帧、缓冲、错误、码率/分辨率变化与完播 |
| D23 | 指标建模与线上排障 | Demo 12：会话日志导出 | 一次播放有唯一会话标识，错误可关联 URL/协议/设备能力 |
| D24 | Widevine DRM 基础 | Demo 13：DRM 配置阅读 | 能解释 UUID、License URL、Multi-session 与服务端职责 |
| D25 | IMA 广告 / Cast（按业务选学） | 阅读官方 Extension 与 Demo | 能判断是否需要并估算集成边界 |
| D26 | Transformer（按业务选学） | Demo 14：裁剪后导出 | 完成一次截取/特效/导出任务 |
| D27～D28 | 毕业项目 | Demo 15：生产化播放器 | 完成下方项目验收清单 |

#### Demo 12：最小播放质量埋点

建议最少采集：

- 播放会话 ID、媒体 ID、协议类型、是否命中缓存。
- 点击播放、首次缓冲、首帧、暂停、恢复、结束、退出。
- 缓冲次数与累计时长、播放错误码与根因、当前清晰度/音轨。
- 设备型号、系统版本、网络类型；避免采集 URL 中可能含有的敏感鉴权参数。

不要只统计“播放成功”。首帧耗时、卡顿率、播放失败率、完播率和清晰度切换是更可行动的体验指标。

**本周必读**：

- [播放分析](https://developer.android.com/media/media3/exoplayer/analytics)
- [DRM](https://developer.android.com/media/media3/exoplayer/drm)
- [Transformer 媒体编辑](https://developer.android.com/media/media3/transformer)
- [Media3 官方源码仓库](https://github.com/androidx/media)

---

## 5. 毕业项目：Production Player Playground

用一个独立 Demo App 汇总所学能力，建议最小范围如下：

### 功能清单

- 一个媒体列表：至少包含 MP4、HLS、DASH 三种样例。
- 播放/暂停、进度、快进/快退、倍速、循环、播放列表切换。
- 清晰度、音轨、字幕选择与用户偏好恢复。
- 播放状态与错误提示页；可复制诊断信息。
- 后台音频播放、媒体通知与耳机控制。
- 边播边缓存与缓存命中展示。
- 基础播放质量日志。

### 验收用例

| 场景 | 预期 |
|---|---|
| 网络从 Wi-Fi 切换至移动网络 | 不崩溃；状态与错误可见；HLS/DASH 可继续自适应或给出明确失败原因 |
| 快速连续切换视频 | 旧媒体停止、没有重叠音频、最终只保留一个有效播放任务 |
| 旋转屏幕/重建 Activity | 不泄漏播放器；按设计恢复或重置播放进度 |
| 退至后台 | 音频业务保持播放并展示系统通知；纯视频业务按产品策略暂停或继续 |
| 选定字幕/音轨/清晰度 | UI 和实际轨道一致；下一条媒体无同索引误选 |
| 相同媒体二次播放 | 可观测缓存命中；缓存失效时能回源 |
| 播放 URL 不可用 | 记录 `PlaybackException`，提示用户重试，不无限重建播放器 |

---

## 6. 官方 Demo 与源码阅读顺序

### 优先级 A：先运行、再读代码

| 资源 | 建议用途 | 入口 |
|---|---|---|
| AndroidX Media3 官方仓库 | 官方 Demo、模块设计、Issue 与发布说明的唯一首选 | [androidx/media](https://github.com/androidx/media) |
| Main Demo 的 `PlayerActivity` | 对照基础 Player、Intent 参数、轨道/播放器配置 | [PlayerActivity.java](https://github.com/androidx/media/blob/release/demos/main/src/main/java/androidx/media3/demo/main/PlayerActivity.java) |
| Session Demo 的 `PlaybackService` | 学习 `MediaSessionService` 持有播放器 | [PlaybackService.kt](https://github.com/androidx/media/blob/release/demos/session/src/main/java/androidx/media3/demo/session/PlaybackService.kt) |
| Session Service Demo | 对照 Controller 与 Service 的连接模式 | [DemoPlaybackService.kt](https://github.com/androidx/media/blob/release/demos/session_service/src/main/java/androidx/media3/demo/session/DemoPlaybackService.kt) |

建议操作顺序：克隆源码仓库后先运行 Main Demo，使用不同的本地/远端媒体样例观察日志；随后只精读与当前学习主题对应的 Demo，而非一次性通读整个仓库。

### 优先级 B：官方文档索引

| 主题 | 文档 |
|---|---|
| Media3 总览与模块关系 | [Introduction to Jetpack Media3](https://developer.android.com/media/media3) |
| 基础播放器 | [Getting started](https://developer.android.com/media/media3/exoplayer/hello-world) |
| 协议、媒体源、扩展 | [Media3 ExoPlayer](https://developer.android.com/media/media3/exoplayer) |
| 协议/网络栈问题 | [Network stacks](https://developer.android.com/media/media3/exoplayer/network-stacks) |
| 后台与外部媒体控制 | [Media session](https://developer.android.com/media/media3/session) |
| 版本兼容与变更 | [Media3 Release Notes](https://developer.android.com/jetpack/androidx/releases/media3) |

### 辅助资源使用原则

- 优先阅读 Android Developers 与 `androidx/media` 仓库；第三方文章仅用于补充实现思路。
- 参考第三方代码前，先确认它使用 `androidx.media3` 而不是废弃的旧 ExoPlayer 包名。
- 遇到 API 不一致时，以当前版本的 Release Notes、Javadoc 与官方源码为准。
- 生产集成 DRM、广告、投屏、离线下载前，先确认服务端协议、鉴权、统计与版权要求；它们不是纯客户端功能。

---

## 7. 常见误区与排查清单

| 现象 | 优先排查 |
|---|---|
| m3u8/mpd 无法播放 | 是否引入 HLS/DASH 模块、URL 是否可访问、MIME 类型/重定向、清单内容是否正确 |
| 有声音无画面 | 编码/设备解码能力、Surface 生命周期、DRM 限制、视频轨是否被禁用 |
| `STATE_READY` 但没有播放 | `playWhenReady`、音频焦点、当前媒体项、是否被 Session/Controller 暂停 |
| 页面退出仍有声音 | 未解绑 `PlayerView`、未释放播放器，或后台 Service 生命周期设计错误 |
| 列表滑动卡顿/串音 | 重复创建播放器、Surface 切换频繁、未复用、预加载策略过激 |
| 缓存未命中 | Cache key、DataSource 链路、鉴权 URL 变化、缓存目录/淘汰策略 |
| DRM 播放失败 | DRM UUID、License URL、请求头、设备安全级别、媒体加密方案与服务端证书 |

排查时至少记录：Media3 版本、媒体 URL（脱敏）、协议、`PlaybackException.errorCode`、`cause`、设备型号/API、网络类型、当前轨道信息。不要仅保留“播放失败”这类不可行动的日志。

---

## 8. 建议的学习产出

每一周至少提交以下产出，避免只“看懂”但没有形成可复用能力：

1. 一个可运行 Demo 或独立功能分支。
2. 一页笔记：关键对象、遇到的问题、最终原因、验证方式。
3. 一组手工测试用例：正常播放、弱网、切后台、旋转、错误地址。
4. 一段 3 分钟口述：从 UI 点击播放到媒体首帧渲染，链路经过哪些对象。

完成毕业项目后，再按实际业务选择深入方向：短视频重点研究预加载与列表复用；长视频重点研究 DRM、清晰度切换、广告与投屏；音频重点研究媒体库、队列、后台与 Android Auto。
