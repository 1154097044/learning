# AOSP Framework 核心机制阶段详细学习计划

> 适用对象:已具备 Android 应用开发经验、能独立编译 AOSP 源码的开发者
> 阶段周期:10-12 周(每天 2-3 小时)
> 配套源码:`platform_frameworks_base`(即 frameworks/base)+ frameworks/native
> 前置条件:已完成 AOSP 源码下载、编译,并能在模拟器/真机上运行自编译镜像

---

## 一、阶段目标

完成本阶段后,你应当能够:

1. 独立跟读 Framework 任意核心流程的源码链路(Java → JNI → Native)
2. 讲清楚 Binder、Handler、AMS、WMS、PMS 五大核心机制的设计与实现
3. 在源码中加日志、重新编译、验证自己的理解
4. 绘制核心流程的时序图,达到"能给他人讲明白"的程度
5. 具备初步的 Framework 层问题定位能力(ANR、卡顿、启动慢)

---

## 二、学习方法论:五步闭环

每个模块严格遵循以下闭环,缺一不可:

| 步骤 | 动作 | 产出物 |
|------|------|--------|
| 1. API 使用 | 先以开发者视角使用该机制,写 Demo | 可运行的 Demo 代码 |
| 2. 源码跟读 | 从 API 入口逐层向下跟读,记录调用链 | 调用链笔记 |
| 3. 画时序图 | 手绘或用 PlantUML 画出完整时序图 | 时序图 |
| 4. 加日志验证 | 在关键节点加日志,重新编译验证 | logcat 验证记录 |
| 5. 输出总结 | 写一篇总结文章,能脱稿讲清楚 | 总结文档 |

> 关键原则:**不要只看不写**。看懂≠理解,能画出图、能讲出来、能改代码验证,才算掌握。

---

## 三、环境与工具准备

### 3.1 源码阅读工具(三选一)

| 工具 | 说明 | 推荐度 |
|------|------|--------|
| AIDEgen + Android Studio | Google 官方方案,支持 Java 跳转 | ★★★★★ |
| VS Code + clangd | 轻量,适合 Native 层 | ★★★★ |
| Source Insight / Understand | Windows 平台老牌工具 | ★★★ |

```bash
# AIDEgen 生成 IDE 工程(在 AOSP 源码根目录执行)
source build/envsetup.sh
lunch aosp_x86_64-eng
m aidegen
aidegen-dev frameworks/base/services   # 生成 services 模块的 AS 工程
```

### 3.2 在线源码交叉索引(辅助)

- https://cs.android.com(Google 官方代码搜索,跳转最快)
- http://aospxref.com(国内镜像,支持多版本切换)

### 3.3 调试工具

- `adb shell dumpsys <service>`:查看任意系统服务状态
- `adb shell am / pm / wm`:命令行操作 AMS/PMS/WMS
- Systrace / Perfetto:系统级 trace 分析
- logcat + 自定义 TAG:源码插入日志后验证

### 3.4 阅读顺序约定

本计划的源码路径以 `platform_frameworks_base` 为基准(即 `frameworks/base/`),涉及 Native 层时会标注 `frameworks/native/` 路径(需单独下载该仓库)。

---

## 四、模块一:Binder 机制(第 1-3 周)

> Binder 是整个 Framework 的地基,所有系统服务通信都建立在它之上。
> **本模块配套独立文档:《Android Binder源码阅读路线.md》,此处只列周计划。**

### 第 1 周:Binder 使用层与 Java 框架层

| 任务 | 内容 | 产出 |
|------|------|------|
| 使用实践 | 手写 AIDL 服务 + Client 调用;分析 SDK 生成的 Stub/Proxy 代码 | AIDL Demo |
| 源码跟读 | `Binder.java`、`BinderProxy`、`ServiceManager.java`、`Parcel.java` | 调用链笔记 |
| 时序图 | 画出 `getService()` 与 `transact()` 的 Java 层时序图 | 时序图 2 张 |

### 第 2 周:JNI 与 Native libbinder

| 任务 | 内容 | 产出 |
|------|------|------|
| JNI 跟读 | `android_util_Binder.cpp` 中 `BinderProxy.transact` 的 native 实现 | 笔记 |
| Native 跟读 | `ProcessState`、`IPCThreadState`、`BpBinder`、`BBinder` | 类关系图 |
| 专题理解 | mmap 一次拷贝原理、Binder 线程池、死亡通知 | 专题笔记 |

### 第 3 周:驱动层与全链路串讲

| 任务 | 内容 | 产出 |
|------|------|------|
| 驱动跟读 | `binder.c` 中 `binder_ioctl` → `binder_transaction` 主链路 | 笔记 |
| 全链路串讲 | 脱稿画出"一次跨进程调用"从 Client 到 Server 的完整链路 | 全链路大图 |
| 验证实践 | 在 Java/JNI/Native 三层同时加日志,验证调用顺序 | logcat 截图 |

**验收标准**:能回答《Android Binder源码阅读路线.md》附录自测清单 20 问中的 16 问以上。

---

## 五、模块二:Handler 消息机制(第 4 周)

### 核心问题清单

1. 一个线程为什么会有且只有一个 Looper?
2. MessageQueue 没有消息时线程为什么不 ANR?休眠在哪?
3. 主线程 Looper 死循环为什么不会卡死?
4. 同步屏障(SyncBarrier)是什么?VSync 消息为什么优先级更高?
5. IdleHandler 的典型应用场景?
6. 为什么子线程不能直接更新 UI?`checkThread()` 在哪里触发?

### 阅读清单

```
frameworks/base/core/java/android/os/Handler.java
frameworks/base/core/java/android/os/Looper.java
frameworks/base/core/java/android/os/MessageQueue.java
frameworks/base/core/java/android/os/Message.java
frameworks/base/core/jni/android_os_MessageQueue.cpp      ← JNI 层
system/core/libutils/Looper.cpp                            ← Native Looper(epoll)
```

### 跟读重点

- `Looper.loop()` → `queue.next()` → `nativePollOnce()` → epoll_wait 休眠链路
- Message 池(`sPool`)的复用设计
- 同步屏障:`postSyncBarrier()` 与 `Message.target == null` 的处理逻辑
- `nativeWake` 如何通过管道(pipe)唤醒 epoll

### 实践任务

1. 在 `MessageQueue.next()` 加日志,观察主线程消息流转
2. 利用 IdleHandler 实现一个"页面空闲时预加载"功能
3. 基于 Looper 原理,手写一个简化版 Handler 框架(200 行以内)

**验收标准**:讲清楚 epoll 在消息机制中的角色;解释主线程死循环不 ANR 的原因。

---

## 六、模块三:AMS / ATMS 与进程管理(第 5-8 周,本阶段最重)

> Android 10 起 Activity 管理职责从 AMS 拆分到 ATMS(ActivityTaskManagerService),
> 跟读时注意 `services/core/java/com/android/server/wm/` 目录下的新位置。

### 第 5 周:Activity 启动流程(冷启动全链路)

**跟读链路**:

```
Activity.startActivity()
  → Instrumentation.execStartActivity()
  → ActivityTaskManager.getService().startActivity()      ← Binder 到 ATMS
  → ActivityStarter.execute()
  → ActivityTaskSupervisor / RootWindowContainer
  → ActivityStack.resumeTopActivityInnerLocked()
  → ActivityTaskManagerService.startProcess()             ← 向 Zygote 请求 fork
  → Process.start() → ZygoteProcess
  → 新进程:ActivityThread.main()
  → attachApplication → bindApplication                   ← 回到 AMS
  → ActivityThread.handleLaunchActivity()
  → performLaunchActivity() → onCreate/onStart/onResume
```

**核心文件**:

```
frameworks/base/services/core/java/com/android/server/wm/ActivityTaskManagerService.java
frameworks/base/services/core/java/com/android/server/wm/ActivityStarter.java
frameworks/base/services/core/java/com/android/server/wm/ActivityRecord.java
frameworks/base/services/core/java/com/android/server/wm/Task.java
frameworks/base/services/core/java/com/android/server/am/ActivityManagerService.java
frameworks/base/services/core/java/com/android/server/am/ProcessList.java
frameworks/base/core/java/android/app/ActivityThread.java
frameworks/base/core/java/com/android/internal/os/ZygoteInit.java
```

### 第 6 周:任务栈与生命周期调度

- Task / ActivityStack / DisplayArea 层级模型
- launchMode(singleTask/singleInstance 等)在 `ActivityStarter` 中的判定逻辑
- 生命周期事务:`ClientTransaction` + `TransactionExecutor` 机制
- `onPause → onStop` 的调度时机,`IdleHandler` 与 `stop` 的关系

**实践**:加日志打印一个 Activity 从启动到退出的全部生命周期调度链,标注 Binder 调用点。

### 第 7 周:进程管理与优先级

- 进程创建:Zygote fork 流程、`ZygoteProcess`、USAP 池
- 进程优先级:`ProcessRecord.curAdj`、`oom_adj` 计算逻辑(`OomAdjuster`)
- 进程状态:cached / foreground / service 等进程等级
- LMK(Low Memory Killer)与 lmkd 的杀进程策略
- 进程保活的黑科技与系统对抗(了解即可)

**核心文件**:

```
frameworks/base/services/core/java/com/android/server/am/OomAdjuster.java
frameworks/base/services/core/java/com/android/server/am/ProcessRecord.java
frameworks/base/services/core/java/com/android/server/am/ProcessList.java
```

### 第 8 周:Service / Broadcast / Provider 管理(选读)+ 复盘

- Service 启动流程(startService / bindService)
- 广播注册与发送(`BroadcastQueue` 的串行/并行队列)
- ContentProvider 的跨进程调用模型
- **复盘**:绘制四大组件与 AMS/ATMS 的交互全景图

**验收标准**:脱稿画出 Activity 冷启动时序图(≥20 个节点);解释 adj 的计算触发时机。

---

## 七、模块四:WMS 窗口管理(第 9-10 周)

### 核心问题清单

1. 一个 View 是如何最终显示到屏幕上的?
2. `Window` 与 `ViewRootImpl`、`WindowState` 分别是什么角色?
3. `addView()` 之后发生了什么?
4. Surface 与 Window 的关系?SurfaceFlinger 在哪里参与?
5. Dialog / Toast / PopupWindow 的窗口类型有何不同?

### 跟读链路

```
WindowManager.addView()
  → WindowManagerGlobal.addView()
  → ViewRootImpl.setView()
  → IWindowSession.addToDisplay()                          ← Binder 到 WMS
  → WindowManagerService.addWindow()
  → WindowState 创建与挂载
  → relayoutWindow() → 创建 Surface
  → ViewRootImpl 接收 performTraversals() 触发绘制
```

**核心文件**:

```
frameworks/base/core/java/android/view/ViewRootImpl.java
frameworks/base/core/java/android/view/WindowManagerGlobal.java
frameworks/base/services/core/java/com/android/server/wm/WindowManagerService.java
frameworks/base/services/core/java/com/android/server/wm/WindowState.java
frameworks/base/services/core/java/com/android/server/wm/WindowToken.java
frameworks/base/services/core/java/com/android/server/wm/DisplayContent.java
```

### 实践任务

1. 加日志追踪一次 `addView()` 到首帧绘制的完整链路
2. 用 `adb shell dumpsys window windows` 分析当前窗口层级
3. 手写一个悬浮窗,观察其 WindowToken 与普通 Activity 的区别

**验收标准**:讲清楚 ViewRootImpl 与 WMS 的双向 Binder 关系(IWindowSession / IWindow)。

---

## 八、模块五:PMS 包管理(第 11 周)

### 核心问题清单

1. APK 安装时 PMS 解析了什么?结果存到哪里?
2. 四大组件是如何"注册"到系统中的?
3. Android 11 的包可见性(package visibility)如何实现?
4. 权限授予发生在哪个环节?

### 阅读清单

```
frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java
frameworks/base/services/core/java/com/android/server/pm/InstallPackageHelper.java
frameworks/base/services/core/java/com/android/server/pm/permission/PermissionManagerServiceImpl.java
frameworks/base/core/java/android/content/pm/PackageParser.java   ← 老版本;新版本在 pm/parsing
```

### 实践任务

1. `adb shell dumpsys package <包名>` 输出逐项解读
2. 加日志追踪一次 `adb install` 的完整流程

**验收标准**:讲清楚 APK 安装的三个阶段(复制 → 解析 → 扫描入库)。

---

## 九、模块六:图形系统入门(第 12 周)

### 核心问题清单

1. `measure / layout / draw` 由谁触发?
2. `requestLayout()` 与 `invalidate()` 的区别?
3. Choreographer 与 VSync 的关系?
4. SurfaceFlinger 合成的是什么?BufferQueue 里流转的是什么?

### 阅读清单

```
frameworks/base/core/java/android/view/ViewRootImpl.java      ← performTraversals
frameworks/base/core/java/android/view/Choreographer.java
frameworks/native/libs/gui/BufferQueueProducer.cpp            ← Native 层(选读)
frameworks/native/services/surfaceflinger/SurfaceFlinger.cpp  ← 选读
```

### 实践任务

1. 用 Systrace 抓取一次列表滑动的 trace,标出 VSync、doFrame、合成三个关键阶段
2. 加日志统计一次 `performTraversals()` 的耗时分布

**验收标准**:能基于 Systrace 分析一次掉帧发生在哪个阶段。

---

## 十、阶段验收总清单

完成全部模块后,用以下清单自测:

- [ ] 脱稿画出 Binder 一次跨进程调用的全链路图(Java → JNI → Native → 驱动)
- [ ] 解释主线程 Looper 死循环不 ANR 的原因
- [ ] 脱稿画出 Activity 冷启动时序图(标注所有 Binder 调用点)
- [ ] 解释 `addView()` 后 View 显示到屏幕的完整过程
- [ ] 讲清楚 oom_adj 的计算逻辑与 LMK 的杀进程策略
- [ ] 能使用 dumpsys / Systrace / Perfetto 定位一个 Framework 层问题
- [ ] 输出 ≥6 篇模块总结文档

---

## 十一、常见问题与建议

| 问题 | 建议 |
|------|------|
| 源码版本太多,跟哪一版? | 固定一个版本(建议 Android 13/14),笔记标注版本号,不要来回切换 |
| 跟丢了调用链怎么办? | 用 cs.android.com 全局搜索方法名 + 类名;从 Binder 对端反向找 |
| 要不要每行都看懂? | 不要。抓主链路,支线(异常处理、兼容性分支)先跳过 |
| Native 层 C++ 看不懂? | 先掌握 Java 层,JNI 层看懂函数对应关系即可,libbinder 精读 |
| 笔记怎么记? | 每模块固定结构:调用链 → 时序图 → 关键类 → 疑问清单 → 总结 |

> 完成本阶段后,即可进入"Native/HAL 层深入"或"图形系统专项"阶段,
> 届时建议以 SurfaceFlinger 或 AudioFlinger 为切入点继续向下探索。
